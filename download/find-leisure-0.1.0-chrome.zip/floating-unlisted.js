(function(){var e=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t,t.exports),e=null),t.exports);function t(e){return e==null||typeof e==`function`?{main:e}:e}var n=e((e=>{var t=Symbol.for(`react.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.provider`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.iterator;function p(e){return typeof e!=`object`||!e?null:(e=f&&e[f]||e[`@@iterator`],typeof e==`function`?e:null)}var m={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},h=Object.assign,g={};function _(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}_.prototype.isReactComponent={},_.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`setState(...): takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},_.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function v(){}v.prototype=_.prototype;function y(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}var b=y.prototype=new v;b.constructor=y,h(b,_.prototype),b.isPureReactComponent=!0;var ee=Array.isArray,te=Object.prototype.hasOwnProperty,x={current:null},ne={key:!0,ref:!0,__self:!0,__source:!0};function re(e,n,r){var i,a={},o=null,s=null;if(n!=null)for(i in n.ref!==void 0&&(s=n.ref),n.key!==void 0&&(o=``+n.key),n)te.call(n,i)&&!ne.hasOwnProperty(i)&&(a[i]=n[i]);var c=arguments.length-2;if(c===1)a.children=r;else if(1<c){for(var l=Array(c),u=0;u<c;u++)l[u]=arguments[u+2];a.children=l}if(e&&e.defaultProps)for(i in c=e.defaultProps,c)a[i]===void 0&&(a[i]=c[i]);return{$$typeof:t,type:e,key:o,ref:s,props:a,_owner:x.current}}function ie(e,n){return{$$typeof:t,type:e.type,key:n,ref:e.ref,props:e.props,_owner:e._owner}}function ae(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function oe(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var S=/\/+/g;function se(e,t){return typeof e==`object`&&e&&e.key!=null?oe(``+e.key):t.toString(36)}function ce(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0}}if(c)return c=e,o=o(c),e=a===``?`.`+se(c,0):a,ee(o)?(i=``,e!=null&&(i=e.replace(S,`$&/`)+`/`),ce(o,r,i,``,function(e){return e})):o!=null&&(ae(o)&&(o=ie(o,i+(!o.key||c&&c.key===o.key?``:(``+o.key).replace(S,`$&/`)+`/`)+e)),r.push(o)),1;if(c=0,a=a===``?`.`:a+`:`,ee(e))for(var l=0;l<e.length;l++){s=e[l];var u=a+se(s,l);c+=ce(s,r,i,u,o)}else if(u=p(e),typeof u==`function`)for(e=u.call(e),l=0;!(s=e.next()).done;)s=s.value,u=a+se(s,l++),c+=ce(s,r,i,u,o);else if(s===`object`)throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`);return c}function C(e,t,n){if(e==null)return e;var r=[],i=0;return ce(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function le(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t)},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var w={current:null},ue={transition:null},de={ReactCurrentDispatcher:w,ReactCurrentBatchConfig:ue,ReactCurrentOwner:x};function fe(){throw Error(`act(...) is not supported in production builds of React.`)}e.Children={map:C,forEach:function(e,t,n){C(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return C(e,function(){t++}),t},toArray:function(e){return C(e,function(e){return e})||[]},only:function(e){if(!ae(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}},e.Component=_,e.Fragment=r,e.Profiler=a,e.PureComponent=y,e.StrictMode=i,e.Suspense=l,e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=de,e.act=fe,e.cloneElement=function(e,n,r){if(e==null)throw Error(`React.cloneElement(...): The argument must be a React element, but you passed `+e+`.`);var i=h({},e.props),a=e.key,o=e.ref,s=e._owner;if(n!=null){if(n.ref!==void 0&&(o=n.ref,s=x.current),n.key!==void 0&&(a=``+n.key),e.type&&e.type.defaultProps)var c=e.type.defaultProps;for(l in n)te.call(n,l)&&!ne.hasOwnProperty(l)&&(i[l]=n[l]===void 0&&c!==void 0?c[l]:n[l])}var l=arguments.length-2;if(l===1)i.children=r;else if(1<l){c=Array(l);for(var u=0;u<l;u++)c[u]=arguments[u+2];i.children=c}return{$$typeof:t,type:e.type,key:a,ref:o,props:i,_owner:s}},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:o,_context:e},e.Consumer=e},e.createElement=re,e.createFactory=function(e){var t=re.bind(null,e);return t.type=e,t},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=ae,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:le}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=function(e){var t=ue.transition;ue.transition={};try{e()}finally{ue.transition=t}},e.unstable_act=fe,e.useCallback=function(e,t){return w.current.useCallback(e,t)},e.useContext=function(e){return w.current.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e){return w.current.useDeferredValue(e)},e.useEffect=function(e,t){return w.current.useEffect(e,t)},e.useId=function(){return w.current.useId()},e.useImperativeHandle=function(e,t,n){return w.current.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return w.current.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return w.current.useLayoutEffect(e,t)},e.useMemo=function(e,t){return w.current.useMemo(e,t)},e.useReducer=function(e,t,n){return w.current.useReducer(e,t,n)},e.useRef=function(e){return w.current.useRef(e)},e.useState=function(e){return w.current.useState(e)},e.useSyncExternalStore=function(e,t,n){return w.current.useSyncExternalStore(e,t,n)},e.useTransition=function(){return w.current.useTransition()},e.version=`18.3.1`})),r=e(((e,t)=>{t.exports=n()})),i=e((e=>{function t(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,a=e[r];if(0<i(a,t))e[r]=t,e[n]=a,n=r;else break a}}function n(e){return e.length===0?null:e[0]}function r(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,a=e.length,o=a>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>i(c,n))l<a&&0>i(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<a&&0>i(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function i(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}if(typeof performance==`object`&&typeof performance.now==`function`){var a=performance;e.unstable_now=function(){return a.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var c=[],l=[],u=1,d=null,f=3,p=!1,m=!1,h=!1,g=typeof setTimeout==`function`?setTimeout:null,_=typeof clearTimeout==`function`?clearTimeout:null,v=typeof setImmediate<`u`?setImmediate:null;typeof navigator<`u`&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function y(e){for(var i=n(l);i!==null;){if(i.callback===null)r(l);else if(i.startTime<=e)r(l),i.sortIndex=i.expirationTime,t(c,i);else break;i=n(l)}}function b(e){if(h=!1,y(e),!m){if(n(c)!==null)m=!0,C(ee);else{var t=n(l);t!==null&&le(b,t.startTime-e)}}}function ee(t,i){m=!1,h&&(h=!1,_(ne),ne=-1),p=!0;var a=f;try{for(y(i),d=n(c);d!==null&&(!(d.expirationTime>i)||t&&!ae());){var o=d.callback;if(typeof o==`function`){d.callback=null,f=d.priorityLevel;var s=o(d.expirationTime<=i);i=e.unstable_now(),typeof s==`function`?d.callback=s:d===n(c)&&r(c),y(i)}else r(c);d=n(c)}if(d!==null)var u=!0;else{var g=n(l);g!==null&&le(b,g.startTime-i),u=!1}return u}finally{d=null,f=a,p=!1}}var te=!1,x=null,ne=-1,re=5,ie=-1;function ae(){return!(e.unstable_now()-ie<re)}function oe(){if(x!==null){var t=e.unstable_now();ie=t;var n=!0;try{n=x(!0,t)}finally{n?S():(te=!1,x=null)}}else te=!1}var S;if(typeof v==`function`)S=function(){v(oe)};else if(typeof MessageChannel<`u`){var se=new MessageChannel,ce=se.port2;se.port1.onmessage=oe,S=function(){ce.postMessage(null)}}else S=function(){g(oe,0)};function C(e){x=e,te||(te=!0,S())}function le(t,n){ne=g(function(){t(e.unstable_now())},n)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_continueExecution=function(){m||p||(m=!0,C(ee))},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):re=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return f},e.unstable_getFirstCallbackNode=function(){return n(c)},e.unstable_next=function(e){switch(f){case 1:case 2:case 3:var t=3;break;default:t=f}var n=f;f=t;try{return e()}finally{f=n}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=f;f=e;try{return t()}finally{f=n}},e.unstable_scheduleCallback=function(r,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,r){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,r={id:u++,callback:i,priorityLevel:r,startTime:a,expirationTime:s,sortIndex:-1},a>o?(r.sortIndex=a,t(l,r),n(c)===null&&r===n(l)&&(h?(_(ne),ne=-1):h=!0,le(b,a-o))):(r.sortIndex=s,t(c,r),m||p||(m=!0,C(ee))),r},e.unstable_shouldYield=ae,e.unstable_wrapCallback=function(e){var t=f;return function(){var n=f;f=t;try{return e.apply(this,arguments)}finally{f=n}}}})),a=e(((e,t)=>{t.exports=i()})),o=e((e=>{var t=r(),n=a();function i(e){for(var t=`https://reactjs.org/docs/error-decoder.html?invariant=`+e,n=1;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n]);return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}var o=new Set,s={};function c(e,t){l(e,t),l(e+`Capture`,t)}function l(e,t){for(s[e]=t,e=0;e<t.length;e++)o.add(t[e])}var u=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0,d=Object.prototype.hasOwnProperty,f=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,p={},m={};function h(e){return d.call(m,e)?!0:d.call(p,e)?!1:f.test(e)?m[e]=!0:(p[e]=!0,!1)}function g(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case`function`:case`symbol`:return!0;case`boolean`:return r?!1:n===null?(e=e.toLowerCase().slice(0,5),e!==`data-`&&e!==`aria-`):!n.acceptsBooleans;default:return!1}}function _(e,t,n,r){if(t==null||g(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return!1===t;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function v(e,t,n,r,i,a,o){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=i,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=a,this.removeEmptyString=o}var y={};`children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style`.split(` `).forEach(function(e){y[e]=new v(e,0,!1,e,null,!1,!1)}),[[`acceptCharset`,`accept-charset`],[`className`,`class`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`]].forEach(function(e){var t=e[0];y[t]=new v(t,1,!1,e[1],null,!1,!1)}),[`contentEditable`,`draggable`,`spellCheck`,`value`].forEach(function(e){y[e]=new v(e,2,!1,e.toLowerCase(),null,!1,!1)}),[`autoReverse`,`externalResourcesRequired`,`focusable`,`preserveAlpha`].forEach(function(e){y[e]=new v(e,2,!1,e,null,!1,!1)}),`allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope`.split(` `).forEach(function(e){y[e]=new v(e,3,!1,e.toLowerCase(),null,!1,!1)}),[`checked`,`multiple`,`muted`,`selected`].forEach(function(e){y[e]=new v(e,3,!0,e,null,!1,!1)}),[`capture`,`download`].forEach(function(e){y[e]=new v(e,4,!1,e,null,!1,!1)}),[`cols`,`rows`,`size`,`span`].forEach(function(e){y[e]=new v(e,6,!1,e,null,!1,!1)}),[`rowSpan`,`start`].forEach(function(e){y[e]=new v(e,5,!1,e.toLowerCase(),null,!1,!1)});var b=/[\-:]([a-z])/g;function ee(e){return e[1].toUpperCase()}`accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height`.split(` `).forEach(function(e){var t=e.replace(b,ee);y[t]=new v(t,1,!1,e,null,!1,!1)}),`xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type`.split(` `).forEach(function(e){var t=e.replace(b,ee);y[t]=new v(t,1,!1,e,`http://www.w3.org/1999/xlink`,!1,!1)}),[`xml:base`,`xml:lang`,`xml:space`].forEach(function(e){var t=e.replace(b,ee);y[t]=new v(t,1,!1,e,`http://www.w3.org/XML/1998/namespace`,!1,!1)}),[`tabIndex`,`crossOrigin`].forEach(function(e){y[e]=new v(e,1,!1,e.toLowerCase(),null,!1,!1)}),y.xlinkHref=new v(`xlinkHref`,1,!1,`xlink:href`,`http://www.w3.org/1999/xlink`,!0,!1),[`src`,`href`,`action`,`formAction`].forEach(function(e){y[e]=new v(e,1,!1,e.toLowerCase(),null,!0,!0)});function te(e,t,n,r){var i=y.hasOwnProperty(t)?y[t]:null;(i===null?r||!(2<t.length)||t[0]!==`o`&&t[0]!==`O`||t[1]!==`n`&&t[1]!==`N`:i.type!==0)&&(_(t,n,i,r)&&(n=null),r||i===null?h(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,``+n)):i.mustUseProperty?e[i.propertyName]=n===null?i.type!==3&&``:n:(t=i.attributeName,r=i.attributeNamespace,n===null?e.removeAttribute(t):(i=i.type,n=i===3||i===4&&!0===n?``:``+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var x=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,ne=Symbol.for(`react.element`),re=Symbol.for(`react.portal`),ie=Symbol.for(`react.fragment`),ae=Symbol.for(`react.strict_mode`),oe=Symbol.for(`react.profiler`),S=Symbol.for(`react.provider`),se=Symbol.for(`react.context`),ce=Symbol.for(`react.forward_ref`),C=Symbol.for(`react.suspense`),le=Symbol.for(`react.suspense_list`),w=Symbol.for(`react.memo`),ue=Symbol.for(`react.lazy`),de=Symbol.for(`react.offscreen`),fe=Symbol.iterator;function pe(e){return typeof e!=`object`||!e?null:(e=fe&&e[fe]||e[`@@iterator`],typeof e==`function`?e:null)}var T=Object.assign,E;function me(e){if(E===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);E=t&&t[1]||``}return`
`+E+e}var he=!1;function ge(e,t){if(!e||he)return``;he=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t){if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(t,[])}catch(e){var r=e}Reflect.construct(e,[],t)}else{try{t.call()}catch(e){r=e}e.call(t.prototype)}}else{try{throw Error()}catch(e){r=e}e()}}catch(t){if(t&&r&&typeof t.stack==`string`){for(var i=t.stack.split(`
`),a=r.stack.split(`
`),o=i.length-1,s=a.length-1;1<=o&&0<=s&&i[o]!==a[s];)s--;for(;1<=o&&0<=s;o--,s--)if(i[o]!==a[s]){if(o!==1||s!==1)do if(o--,s--,0>s||i[o]!==a[s]){var c=`
`+i[o].replace(` at new `,` at `);return e.displayName&&c.includes(`<anonymous>`)&&(c=c.replace(`<anonymous>`,e.displayName)),c}while(1<=o&&0<=s);break}}}finally{he=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:``)?me(e):``}function _e(e){switch(e.tag){case 5:return me(e.type);case 16:return me(`Lazy`);case 13:return me(`Suspense`);case 19:return me(`SuspenseList`);case 0:case 2:case 15:return e=ge(e.type,!1),e;case 11:return e=ge(e.type.render,!1),e;case 1:return e=ge(e.type,!0),e;default:return``}}function ve(e){if(e==null)return null;if(typeof e==`function`)return e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case ie:return`Fragment`;case re:return`Portal`;case oe:return`Profiler`;case ae:return`StrictMode`;case C:return`Suspense`;case le:return`SuspenseList`}if(typeof e==`object`)switch(e.$$typeof){case se:return(e.displayName||`Context`)+`.Consumer`;case S:return(e._context.displayName||`Context`)+`.Provider`;case ce:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case w:return t=e.displayName||null,t===null?ve(e.type)||`Memo`:t;case ue:t=e._payload,e=e._init;try{return ve(e(t))}catch{}}return null}function ye(e){var t=e.type;switch(e.tag){case 24:return`Cache`;case 9:return(t.displayName||`Context`)+`.Consumer`;case 10:return(t._context.displayName||`Context`)+`.Provider`;case 18:return`DehydratedFragment`;case 11:return e=t.render,e=e.displayName||e.name||``,t.displayName||(e===``?`ForwardRef`:`ForwardRef(`+e+`)`);case 7:return`Fragment`;case 5:return t;case 4:return`Portal`;case 3:return`Root`;case 6:return`Text`;case 16:return ve(t);case 8:return t===ae?`StrictMode`:`Mode`;case 22:return`Offscreen`;case 12:return`Profiler`;case 21:return`Scope`;case 13:return`Suspense`;case 19:return`SuspenseList`;case 25:return`TracingMarker`;case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t==`function`)return t.displayName||t.name||null;if(typeof t==`string`)return t}return null}function be(e){switch(typeof e){case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return e;default:return``}}function xe(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function Se(e){var t=xe(e)?`checked`:`value`,n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=``+e[t];if(!e.hasOwnProperty(t)&&n!==void 0&&typeof n.get==`function`&&typeof n.set==`function`){var i=n.get,a=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){r=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(e){r=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Ce(e){e._valueTracker||=Se(e)}function we(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=xe(e)?e.checked?`true`:`false`:e.value),e=r,e!==n&&(t.setValue(e),!0)}function Te(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}function Ee(e,t){var n=t.checked;return T({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function De(e,t){var n=t.defaultValue==null?``:t.defaultValue,r=t.checked==null?t.defaultChecked:t.checked;n=be(t.value==null?n:t.value),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type===`checkbox`||t.type===`radio`?t.checked!=null:t.value!=null}}function Oe(e,t){t=t.checked,t!=null&&te(e,`checked`,t,!1)}function ke(e,t){Oe(e,t);var n=be(t.value),r=t.type;if(n!=null)r===`number`?(n===0&&e.value===``||e.value!=n)&&(e.value=``+n):e.value!==``+n&&(e.value=``+n);else if(r===`submit`||r===`reset`){e.removeAttribute(`value`);return}t.hasOwnProperty(`value`)?je(e,t.type,n):t.hasOwnProperty(`defaultValue`)&&je(e,t.type,be(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function Ae(e,t,n){if(t.hasOwnProperty(`value`)||t.hasOwnProperty(`defaultValue`)){var r=t.type;if(!(r!==`submit`&&r!==`reset`||t.value!==void 0&&t.value!==null))return;t=``+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==``&&(e.name=``),e.defaultChecked=!!e._wrapperState.initialChecked,n!==``&&(e.name=n)}function je(e,t,n){(t!==`number`||Te(e.ownerDocument)!==e)&&(n==null?e.defaultValue=``+e._wrapperState.initialValue:e.defaultValue!==``+n&&(e.defaultValue=``+n))}var Me=Array.isArray;function Ne(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+be(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function Pe(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(i(91));return T({},t,{value:void 0,defaultValue:void 0,children:``+e._wrapperState.initialValue})}function Fe(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(i(92));if(Me(n)){if(1<n.length)throw Error(i(93));n=n[0]}t=n}t??=``,n=t}e._wrapperState={initialValue:be(n)}}function Ie(e,t){var n=be(t.value),r=be(t.defaultValue);n!=null&&(n=``+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=``+r)}function Le(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==``&&t!==null&&(e.value=t)}function Re(e){switch(e){case`svg`:return`http://www.w3.org/2000/svg`;case`math`:return`http://www.w3.org/1998/Math/MathML`;default:return`http://www.w3.org/1999/xhtml`}}function ze(e,t){return e==null||e===`http://www.w3.org/1999/xhtml`?Re(t):e===`http://www.w3.org/2000/svg`&&t===`foreignObject`?`http://www.w3.org/1999/xhtml`:e}var Be,Ve=function(e){return typeof MSApp<`u`&&MSApp.execUnsafeLocalFunction?function(t,n,r,i){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,i)})}:e}(function(e,t){if(e.namespaceURI!==`http://www.w3.org/2000/svg`||`innerHTML`in e)e.innerHTML=t;else{for(Be||=document.createElement(`div`),Be.innerHTML=`<svg>`+t.valueOf().toString()+`</svg>`,t=Be.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function He(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var Ue={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},We=[`Webkit`,`ms`,`Moz`,`O`];Object.keys(Ue).forEach(function(e){We.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),Ue[t]=Ue[e]})});function Ge(e,t,n){return t==null||typeof t==`boolean`||t===``?``:n||typeof t!=`number`||t===0||Ue.hasOwnProperty(e)&&Ue[e]?(``+t).trim():t+`px`}function Ke(e,t){for(var n in e=e.style,t)if(t.hasOwnProperty(n)){var r=n.indexOf(`--`)===0,i=Ge(n,t[n],r);n===`float`&&(n=`cssFloat`),r?e.setProperty(n,i):e[n]=i}}var qe=T({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Je(e,t){if(t){if(qe[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(i(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(i(60));if(typeof t.dangerouslySetInnerHTML!=`object`||!(`__html`in t.dangerouslySetInnerHTML))throw Error(i(61))}if(t.style!=null&&typeof t.style!=`object`)throw Error(i(62))}}function Ye(e,t){if(e.indexOf(`-`)===-1)return typeof t.is==`string`;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}var Xe=null;function Ze(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Qe=null,$e=null,et=null;function tt(e){if(e=$i(e)){if(typeof Qe!=`function`)throw Error(i(280));var t=e.stateNode;t&&(t=ta(t),Qe(e.stateNode,e.type,t))}}function nt(e){$e?et?et.push(e):et=[e]:$e=e}function rt(){if($e){var e=$e,t=et;if(et=$e=null,tt(e),t)for(e=0;e<t.length;e++)tt(t[e])}}function it(e,t){return e(t)}function at(){}var ot=!1;function st(e,t,n){if(ot)return e(t,n);ot=!0;try{return it(e,t,n)}finally{ot=!1,($e!==null||et!==null)&&(at(),rt())}}function ct(e,t){var n=e.stateNode;if(n===null)return null;var r=ta(n);if(r===null)return null;n=r[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(r=!r.disabled)||(e=e.type,r=e!==`button`&&e!==`input`&&e!==`select`&&e!==`textarea`),e=!r;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error(i(231,t,typeof n));return n}var lt=!1;if(u)try{var ut={};Object.defineProperty(ut,"passive",{get:function(){lt=!0}}),window.addEventListener(`test`,ut,ut),window.removeEventListener(`test`,ut,ut)}catch{lt=!1}function dt(e,t,n,r,i,a,o,s,c){var l=Array.prototype.slice.call(arguments,3);try{t.apply(n,l)}catch(e){this.onError(e)}}var ft=!1,pt=null,mt=!1,ht=null,gt={onError:function(e){ft=!0,pt=e}};function _t(e,t,n,r,i,a,o,s,c){ft=!1,pt=null,dt.apply(gt,arguments)}function vt(e,t,n,r,a,o,s,c,l){if(_t.apply(this,arguments),ft){if(ft){var u=pt;ft=!1,pt=null}else throw Error(i(198));mt||(mt=!0,ht=u)}}function yt(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function bt(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function xt(e){if(yt(e)!==e)throw Error(i(188))}function St(e){var t=e.alternate;if(!t){if(t=yt(e),t===null)throw Error(i(188));return t===e?e:null}for(var n=e,r=t;;){var a=n.return;if(a===null)break;var o=a.alternate;if(o===null){if(r=a.return,r!==null){n=r;continue}break}if(a.child===o.child){for(o=a.child;o;){if(o===n)return xt(a),e;if(o===r)return xt(a),t;o=o.sibling}throw Error(i(188))}if(n.return!==r.return)n=a,r=o;else{for(var s=!1,c=a.child;c;){if(c===n){s=!0,n=a,r=o;break}if(c===r){s=!0,r=a,n=o;break}c=c.sibling}if(!s){for(c=o.child;c;){if(c===n){s=!0,n=o,r=a;break}if(c===r){s=!0,r=o,n=a;break}c=c.sibling}if(!s)throw Error(i(189))}}if(n.alternate!==r)throw Error(i(190))}if(n.tag!==3)throw Error(i(188));return n.stateNode.current===n?e:t}function Ct(e){return e=St(e),e===null?null:wt(e)}function wt(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=wt(e);if(t!==null)return t;e=e.sibling}return null}var Tt=n.unstable_scheduleCallback,Et=n.unstable_cancelCallback,Dt=n.unstable_shouldYield,Ot=n.unstable_requestPaint,D=n.unstable_now,kt=n.unstable_getCurrentPriorityLevel,At=n.unstable_ImmediatePriority,jt=n.unstable_UserBlockingPriority,Mt=n.unstable_NormalPriority,Nt=n.unstable_LowPriority,Pt=n.unstable_IdlePriority,Ft=null,It=null;function Lt(e){if(It&&typeof It.onCommitFiberRoot==`function`)try{It.onCommitFiberRoot(Ft,e,void 0,(e.current.flags&128)==128)}catch{}}var Rt=Math.clz32?Math.clz32:Vt,zt=Math.log,Bt=Math.LN2;function Vt(e){return e>>>=0,e===0?32:31-(zt(e)/Bt|0)|0}var Ht=64,Ut=4194304;function Wt(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Gt(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,i=e.suspendedLanes,a=e.pingedLanes,o=n&268435455;if(o!==0){var s=o&~i;s===0?(a&=o,a!==0&&(r=Wt(a))):r=Wt(s)}else o=n&~i,o===0?a!==0&&(r=Wt(a)):r=Wt(o);if(r===0)return 0;if(t!==0&&t!==r&&(t&i)===0&&(i=r&-r,a=t&-t,i>=a||i===16&&a&4194240))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-Rt(t),i=1<<n,r|=e[n],t&=~i;return r}function Kt(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function qt(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes;0<a;){var o=31-Rt(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=Kt(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}}function Jt(e){return e=e.pendingLanes&-1073741825,e===0?e&1073741824?1073741824:0:e}function Yt(){var e=Ht;return Ht<<=1,!(Ht&4194240)&&(Ht=64),e}function Xt(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Zt(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-Rt(t),e[t]=n}function Qt(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var i=31-Rt(n),a=1<<i;t[i]=0,r[i]=-1,e[i]=-1,n&=~a}}function $t(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Rt(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}var O=0;function en(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var tn,nn,rn,an,on,sn=!1,cn=[],ln=null,un=null,dn=null,fn=new Map,pn=new Map,mn=[],hn=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit`.split(` `);function gn(e,t){switch(e){case`focusin`:case`focusout`:ln=null;break;case`dragenter`:case`dragleave`:un=null;break;case`mouseover`:case`mouseout`:dn=null;break;case`pointerover`:case`pointerout`:fn.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:pn.delete(t.pointerId)}}function _n(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=$i(t),t!==null&&nn(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function vn(e,t,n,r,i){switch(t){case`focusin`:return ln=_n(ln,e,t,n,r,i),!0;case`dragenter`:return un=_n(un,e,t,n,r,i),!0;case`mouseover`:return dn=_n(dn,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return fn.set(a,_n(fn.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,pn.set(a,_n(pn.get(a)||null,e,t,n,r,i)),!0}return!1}function yn(e){var t=Qi(e.target);if(t!==null){var n=yt(t);if(n!==null){if(t=n.tag,t===13){if(t=bt(n),t!==null){e.blockedOn=t,on(e.priority,function(){rn(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function bn(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=jn(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);Xe=r,n.target.dispatchEvent(r),Xe=null}else return t=$i(n),t!==null&&nn(t),e.blockedOn=n,!1;t.shift()}return!0}function xn(e,t,n){bn(e)&&n.delete(t)}function Sn(){sn=!1,ln!==null&&bn(ln)&&(ln=null),un!==null&&bn(un)&&(un=null),dn!==null&&bn(dn)&&(dn=null),fn.forEach(xn),pn.forEach(xn)}function Cn(e,t){e.blockedOn===t&&(e.blockedOn=null,sn||(sn=!0,n.unstable_scheduleCallback(n.unstable_NormalPriority,Sn)))}function wn(e){function t(t){return Cn(t,e)}if(0<cn.length){Cn(cn[0],e);for(var n=1;n<cn.length;n++){var r=cn[n];r.blockedOn===e&&(r.blockedOn=null)}}for(ln!==null&&Cn(ln,e),un!==null&&Cn(un,e),dn!==null&&Cn(dn,e),fn.forEach(t),pn.forEach(t),n=0;n<mn.length;n++)r=mn[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<mn.length&&(n=mn[0],n.blockedOn===null);)yn(n),n.blockedOn===null&&mn.shift()}var Tn=x.ReactCurrentBatchConfig,En=!0;function Dn(e,t,n,r){var i=O,a=Tn.transition;Tn.transition=null;try{O=1,kn(e,t,n,r)}finally{O=i,Tn.transition=a}}function On(e,t,n,r){var i=O,a=Tn.transition;Tn.transition=null;try{O=4,kn(e,t,n,r)}finally{O=i,Tn.transition=a}}function kn(e,t,n,r){if(En){var i=jn(e,t,n,r);if(i===null)wi(e,t,r,An,n),gn(e,r);else if(vn(i,e,t,n,r))r.stopPropagation();else if(gn(e,r),t&4&&-1<hn.indexOf(e)){for(;i!==null;){var a=$i(i);if(a!==null&&tn(a),a=jn(e,t,n,r),a===null&&wi(e,t,r,An,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else wi(e,t,r,null,n)}}var An=null;function jn(e,t,n,r){if(An=null,e=Ze(r),e=Qi(e),e!==null){if(t=yt(e),t===null)e=null;else if(n=t.tag,n===13){if(e=bt(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}return An=e,null}function Mn(e){switch(e){case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`resize`:case`seeked`:case`submit`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return 1;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`scroll`:case`toggle`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return 4;case`message`:switch(kt()){case At:return 1;case jt:return 4;case Mt:case Nt:return 16;case Pt:return 536870912;default:return 16}default:return 16}}var Nn=null,Pn=null,Fn=null;function In(){if(Fn)return Fn;var e,t=Pn,n=t.length,r,i=`value`in Nn?Nn.value:Nn.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return Fn=i.slice(e,1<r?1-r:void 0)}function Ln(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Rn(){return!0}function zn(){return!1}function Bn(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?Rn:zn,this.isPropagationStopped=zn,this}return T(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=Rn)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=Rn)},persist:function(){},isPersistent:Rn}),t}var Vn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Hn=Bn(Vn),Un=T({},Vn,{view:0,detail:0}),Wn=Bn(Un),Gn,Kn,qn,Jn=T({},Un,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ar,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==qn&&(qn&&e.type===`mousemove`?(Gn=e.screenX-qn.screenX,Kn=e.screenY-qn.screenY):Kn=Gn=0,qn=e),Gn)},movementY:function(e){return`movementY`in e?e.movementY:Kn}}),Yn=Bn(Jn),Xn=Bn(T({},Jn,{dataTransfer:0})),Zn=Bn(T({},Un,{relatedTarget:0})),Qn=Bn(T({},Vn,{animationName:0,elapsedTime:0,pseudoElement:0})),$n=Bn(T({},Vn,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),er=Bn(T({},Vn,{data:0})),tr={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},nr={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},rr={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`};function ir(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=rr[e])?!!t[e]:!1}function ar(){return ir}var or=Bn(T({},Un,{key:function(e){if(e.key){var t=tr[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=Ln(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?nr[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ar,charCode:function(e){return e.type===`keypress`?Ln(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?Ln(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),sr=Bn(T({},Jn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),cr=Bn(T({},Un,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ar})),lr=Bn(T({},Vn,{propertyName:0,elapsedTime:0,pseudoElement:0})),ur=Bn(T({},Jn,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),dr=[9,13,27,32],fr=u&&`CompositionEvent`in window,pr=null;u&&`documentMode`in document&&(pr=document.documentMode);var mr=u&&`TextEvent`in window&&!pr,hr=u&&(!fr||pr&&8<pr&&11>=pr),gr=` `,_r=!1;function vr(e,t){switch(e){case`keyup`:return dr.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==229;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function yr(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}var br=!1;function xr(e,t){switch(e){case`compositionend`:return yr(t);case`keypress`:return t.which===32?(_r=!0,gr):null;case`textInput`:return e=t.data,e===gr&&_r?null:e;default:return null}}function Sr(e,t){if(br)return e===`compositionend`||!fr&&vr(e,t)?(e=In(),Fn=Pn=Nn=null,br=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return hr&&t.locale!==`ko`?null:t.data;default:return null}}var Cr={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function wr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!Cr[e.type]:t===`textarea`}function Tr(e,t,n,r){nt(r),t=Ei(t,`onChange`),0<t.length&&(n=new Hn(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}var Er=null,Dr=null;function Or(e){yi(e,0)}function kr(e){if(we(ea(e)))return e}function Ar(e,t){if(e===`change`)return t}var jr=!1;if(u){var Mr;if(u){var Nr=`oninput`in document;if(!Nr){var Pr=document.createElement(`div`);Pr.setAttribute(`oninput`,`return;`),Nr=typeof Pr.oninput==`function`}Mr=Nr}else Mr=!1;jr=Mr&&(!document.documentMode||9<document.documentMode)}function Fr(){Er&&(Er.detachEvent(`onpropertychange`,Ir),Dr=Er=null)}function Ir(e){if(e.propertyName===`value`&&kr(Dr)){var t=[];Tr(t,Dr,e,Ze(e)),st(Or,t)}}function Lr(e,t,n){e===`focusin`?(Fr(),Er=t,Dr=n,Er.attachEvent(`onpropertychange`,Ir)):e===`focusout`&&Fr()}function Rr(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return kr(Dr)}function zr(e,t){if(e===`click`)return kr(t)}function Br(e,t){if(e===`input`||e===`change`)return kr(t)}function Vr(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var Hr=typeof Object.is==`function`?Object.is:Vr;function Ur(e,t){if(Hr(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!d.call(t,i)||!Hr(e[i],t[i]))return!1}return!0}function Wr(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Gr(e,t){var n=Wr(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=Wr(n)}}function Kr(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Kr(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function qr(){for(var e=window,t=Te();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=Te(e.document)}return t}function Jr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}function Yr(e){var t=qr(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&Kr(n.ownerDocument.documentElement,n)){if(r!==null&&Jr(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),`selectionStart`in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var i=n.textContent.length,a=Math.min(r.start,i);r=r.end===void 0?a:Math.min(r.end,i),!e.extend&&a>r&&(i=r,r=a,a=i),i=Gr(n,a);var o=Gr(n,r);i&&o&&(e.rangeCount!==1||e.anchorNode!==i.node||e.anchorOffset!==i.offset||e.focusNode!==o.node||e.focusOffset!==o.offset)&&(t=t.createRange(),t.setStart(i.node,i.offset),e.removeAllRanges(),a>r?(e.addRange(t),e.extend(o.node,o.offset)):(t.setEnd(o.node,o.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus==`function`&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Xr=u&&`documentMode`in document&&11>=document.documentMode,Zr=null,Qr=null,$r=null,ei=!1;function ti(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;ei||Zr==null||Zr!==Te(r)||(r=Zr,`selectionStart`in r&&Jr(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),$r&&Ur($r,r)||($r=r,r=Ei(Qr,`onSelect`),0<r.length&&(t=new Hn(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=Zr)))}function ni(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}var ri={animationend:ni(`Animation`,`AnimationEnd`),animationiteration:ni(`Animation`,`AnimationIteration`),animationstart:ni(`Animation`,`AnimationStart`),transitionend:ni(`Transition`,`TransitionEnd`)},ii={},ai={};u&&(ai=document.createElement(`div`).style,`AnimationEvent`in window||(delete ri.animationend.animation,delete ri.animationiteration.animation,delete ri.animationstart.animation),`TransitionEvent`in window||delete ri.transitionend.transition);function oi(e){if(ii[e])return ii[e];if(!ri[e])return e;var t=ri[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in ai)return ii[e]=t[n];return e}var si=oi(`animationend`),ci=oi(`animationiteration`),li=oi(`animationstart`),ui=oi(`transitionend`),di=new Map,fi=`abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);function pi(e,t){di.set(e,t),c(t,[e])}for(var mi=0;mi<fi.length;mi++){var hi=fi[mi];pi(hi.toLowerCase(),`on`+(hi[0].toUpperCase()+hi.slice(1)))}pi(si,`onAnimationEnd`),pi(ci,`onAnimationIteration`),pi(li,`onAnimationStart`),pi(`dblclick`,`onDoubleClick`),pi(`focusin`,`onFocus`),pi(`focusout`,`onBlur`),pi(ui,`onTransitionEnd`),l(`onMouseEnter`,[`mouseout`,`mouseover`]),l(`onMouseLeave`,[`mouseout`,`mouseover`]),l(`onPointerEnter`,[`pointerout`,`pointerover`]),l(`onPointerLeave`,[`pointerout`,`pointerover`]),c(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),c(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),c(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),c(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),c(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),c(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var gi=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),_i=new Set(`cancel close invalid load scroll toggle`.split(` `).concat(gi));function vi(e,t,n){var r=e.type||`unknown-event`;e.currentTarget=n,vt(r,t,void 0,e),e.currentTarget=null}function yi(e,t){t=!!(t&4);for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;a:{var a=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==a&&i.isPropagationStopped())break a;vi(i,s,l),a=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==a&&i.isPropagationStopped())break a;vi(i,s,l),a=c}}}if(mt)throw e=ht,mt=!1,ht=null,e}function k(e,t){var n=t[Yi];n===void 0&&(n=t[Yi]=new Set);var r=e+`__bubble`;n.has(r)||(Ci(t,e,2,!1),n.add(r))}function bi(e,t,n){var r=0;t&&(r|=4),Ci(n,e,r,t)}var xi=`_reactListening`+Math.random().toString(36).slice(2);function Si(e){if(!e[xi]){e[xi]=!0,o.forEach(function(t){t!==`selectionchange`&&(_i.has(t)||bi(t,!1,e),bi(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[xi]||(t[xi]=!0,bi(`selectionchange`,!1,t))}}function Ci(e,t,n,r){switch(Mn(t)){case 1:var i=Dn;break;case 4:i=On;break;default:i=kn}n=i.bind(null,t,n,e),i=void 0,!lt||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function wi(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var o=r.tag;if(o===3||o===4){var s=r.stateNode.containerInfo;if(s===i||s.nodeType===8&&s.parentNode===i)break;if(o===4)for(o=r.return;o!==null;){var c=o.tag;if((c===3||c===4)&&(c=o.stateNode.containerInfo,c===i||c.nodeType===8&&c.parentNode===i))return;o=o.return}for(;s!==null;){if(o=Qi(s),o===null)return;if(c=o.tag,c===5||c===6){r=a=o;continue a}s=s.parentNode}}r=r.return}st(function(){var r=a,i=Ze(n),o=[];a:{var s=di.get(e);if(s!==void 0){var c=Hn,l=e;switch(e){case`keypress`:if(Ln(n)===0)break a;case`keydown`:case`keyup`:c=or;break;case`focusin`:l=`focus`,c=Zn;break;case`focusout`:l=`blur`,c=Zn;break;case`beforeblur`:case`afterblur`:c=Zn;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:c=Yn;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:c=Xn;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:c=cr;break;case si:case ci:case li:c=Qn;break;case ui:c=lr;break;case`scroll`:c=Wn;break;case`wheel`:c=ur;break;case`copy`:case`cut`:case`paste`:c=$n;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:c=sr}var u=!!(t&4),d=!u&&e===`scroll`,f=u?s===null?null:s+`Capture`:s;u=[];for(var p=r,m;p!==null;){m=p;var h=m.stateNode;if(m.tag===5&&h!==null&&(m=h,f!==null&&(h=ct(p,f),h!=null&&u.push(Ti(p,h,m)))),d)break;p=p.return}0<u.length&&(s=new c(s,l,null,n,i),o.push({event:s,listeners:u}))}}if(!(t&7)){a:{if(s=e===`mouseover`||e===`pointerover`,c=e===`mouseout`||e===`pointerout`,s&&n!==Xe&&(l=n.relatedTarget||n.fromElement)&&(Qi(l)||l[Ji]))break a;if((c||s)&&(s=i.window===i?i:(s=i.ownerDocument)?s.defaultView||s.parentWindow:window,c?(l=n.relatedTarget||n.toElement,c=r,l=l?Qi(l):null,l!==null&&(d=yt(l),l!==d||l.tag!==5&&l.tag!==6)&&(l=null)):(c=null,l=r),c!==l)){if(u=Yn,h=`onMouseLeave`,f=`onMouseEnter`,p=`mouse`,(e===`pointerout`||e===`pointerover`)&&(u=sr,h=`onPointerLeave`,f=`onPointerEnter`,p=`pointer`),d=c==null?s:ea(c),m=l==null?s:ea(l),s=new u(h,p+`leave`,c,n,i),s.target=d,s.relatedTarget=m,h=null,Qi(i)===r&&(u=new u(f,p+`enter`,l,n,i),u.target=m,u.relatedTarget=d,h=u),d=h,c&&l)b:{for(u=c,f=l,p=0,m=u;m;m=Di(m))p++;for(m=0,h=f;h;h=Di(h))m++;for(;0<p-m;)u=Di(u),p--;for(;0<m-p;)f=Di(f),m--;for(;p--;){if(u===f||f!==null&&u===f.alternate)break b;u=Di(u),f=Di(f)}u=null}else u=null;c!==null&&Oi(o,s,c,u,!1),l!==null&&d!==null&&Oi(o,d,l,u,!0)}}a:{if(s=r?ea(r):window,c=s.nodeName&&s.nodeName.toLowerCase(),c===`select`||c===`input`&&s.type===`file`)var g=Ar;else if(wr(s)){if(jr)g=Br;else{g=Rr;var _=Lr}}else(c=s.nodeName)&&c.toLowerCase()===`input`&&(s.type===`checkbox`||s.type===`radio`)&&(g=zr);if(g&&=g(e,r)){Tr(o,g,n,i);break a}_&&_(e,s,r),e===`focusout`&&(_=s._wrapperState)&&_.controlled&&s.type===`number`&&je(s,`number`,s.value)}switch(_=r?ea(r):window,e){case`focusin`:(wr(_)||_.contentEditable===`true`)&&(Zr=_,Qr=r,$r=null);break;case`focusout`:$r=Qr=Zr=null;break;case`mousedown`:ei=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:ei=!1,ti(o,n,i);break;case`selectionchange`:if(Xr)break;case`keydown`:case`keyup`:ti(o,n,i)}var v;if(fr)b:{switch(e){case`compositionstart`:var y=`onCompositionStart`;break b;case`compositionend`:y=`onCompositionEnd`;break b;case`compositionupdate`:y=`onCompositionUpdate`;break b}y=void 0}else br?vr(e,n)&&(y=`onCompositionEnd`):e===`keydown`&&n.keyCode===229&&(y=`onCompositionStart`);y&&(hr&&n.locale!==`ko`&&(br||y!==`onCompositionStart`?y===`onCompositionEnd`&&br&&(v=In()):(Nn=i,Pn=`value`in Nn?Nn.value:Nn.textContent,br=!0)),_=Ei(r,y),0<_.length&&(y=new er(y,e,null,n,i),o.push({event:y,listeners:_}),v?y.data=v:(v=yr(n),v!==null&&(y.data=v)))),(v=mr?xr(e,n):Sr(e,n))&&(r=Ei(r,`onBeforeInput`),0<r.length&&(i=new er(`onBeforeInput`,`beforeinput`,null,n,i),o.push({event:i,listeners:r}),i.data=v))}yi(o,t)})}function Ti(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Ei(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;i.tag===5&&a!==null&&(i=a,a=ct(e,n),a!=null&&r.unshift(Ti(e,a,i)),a=ct(e,t),a!=null&&r.push(Ti(e,a,i))),e=e.return}return r}function Di(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function Oi(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(c!==null&&c===r)break;s.tag===5&&l!==null&&(s=l,i?(c=ct(n,a),c!=null&&o.unshift(Ti(n,c,s))):i||(c=ct(n,a),c!=null&&o.push(Ti(n,c,s)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var ki=/\r\n?/g,Ai=/\u0000|\uFFFD/g;function ji(e){return(typeof e==`string`?e:``+e).replace(ki,`
`).replace(Ai,``)}function Mi(e,t,n){if(t=ji(t),ji(e)!==t&&n)throw Error(i(425))}function Ni(){}var Pi=null,Fi=null;function Ii(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Li=typeof setTimeout==`function`?setTimeout:void 0,Ri=typeof clearTimeout==`function`?clearTimeout:void 0,zi=typeof Promise==`function`?Promise:void 0,Bi=typeof queueMicrotask==`function`?queueMicrotask:zi===void 0?Li:function(e){return zi.resolve(null).then(e).catch(Vi)};function Vi(e){setTimeout(function(){throw e})}function Hi(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8){if(n=i.data,n===`/$`){if(r===0){e.removeChild(i),wn(t);return}r--}else n!==`$`&&n!==`$?`&&n!==`$!`||r++}n=i}while(n);wn(t)}function Ui(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===`$`||t===`$!`||t===`$?`)break;if(t===`/$`)return null}}return e}function Wi(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`$`||n===`$!`||n===`$?`){if(t===0)return e;t--}else n===`/$`&&t++}e=e.previousSibling}return null}var Gi=Math.random().toString(36).slice(2),Ki=`__reactFiber$`+Gi,qi=`__reactProps$`+Gi,Ji=`__reactContainer$`+Gi,Yi=`__reactEvents$`+Gi,Xi=`__reactListeners$`+Gi,Zi=`__reactHandles$`+Gi;function Qi(e){var t=e[Ki];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Ji]||n[Ki]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=Wi(e);e!==null;){if(n=e[Ki])return n;e=Wi(e)}return t}e=n,n=e.parentNode}return null}function $i(e){return e=e[Ki]||e[Ji],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function ea(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(i(33))}function ta(e){return e[qi]||null}var na=[],ra=-1;function ia(e){return{current:e}}function A(e){0>ra||(e.current=na[ra],na[ra]=null,ra--)}function j(e,t){ra++,na[ra]=e.current,e.current=t}var aa={},M=ia(aa),N=ia(!1),oa=aa;function sa(e,t){var n=e.type.contextTypes;if(!n)return aa;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var i={},a;for(a in n)i[a]=t[a];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=i),i}function P(e){return e=e.childContextTypes,e!=null}function ca(){A(N),A(M)}function la(e,t,n){if(M.current!==aa)throw Error(i(168));j(M,t),j(N,n)}function ua(e,t,n){var r=e.stateNode;if(t=t.childContextTypes,typeof r.getChildContext!=`function`)return n;for(var a in r=r.getChildContext(),r)if(!(a in t))throw Error(i(108,ye(e)||`Unknown`,a));return T({},n,r)}function da(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||aa,oa=M.current,j(M,e),j(N,N.current),!0}function fa(e,t,n){var r=e.stateNode;if(!r)throw Error(i(169));n?(e=ua(e,t,oa),r.__reactInternalMemoizedMergedChildContext=e,A(N),A(M),j(M,e)):A(N),j(N,n)}var pa=null,ma=!1,ha=!1;function ga(e){pa===null?pa=[e]:pa.push(e)}function _a(e){ma=!0,ga(e)}function va(){if(!ha&&pa!==null){ha=!0;var e=0,t=O;try{var n=pa;for(O=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}pa=null,ma=!1}catch(t){throw pa!==null&&(pa=pa.slice(e+1)),Tt(At,va),t}finally{O=t,ha=!1}}return null}var ya=[],ba=0,xa=null,Sa=0,Ca=[],wa=0,Ta=null,Ea=1,Da=``;function Oa(e,t){ya[ba++]=Sa,ya[ba++]=xa,xa=e,Sa=t}function ka(e,t,n){Ca[wa++]=Ea,Ca[wa++]=Da,Ca[wa++]=Ta,Ta=e;var r=Ea;e=Da;var i=32-Rt(r)-1;r&=~(1<<i),n+=1;var a=32-Rt(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,Ea=1<<32-Rt(t)+i|n<<i|r,Da=a+e}else Ea=1<<a|n<<i|r,Da=e}function Aa(e){e.return!==null&&(Oa(e,1),ka(e,1,0))}function ja(e){for(;e===xa;)xa=ya[--ba],ya[ba]=null,Sa=ya[--ba],ya[ba]=null;for(;e===Ta;)Ta=Ca[--wa],Ca[wa]=null,Da=Ca[--wa],Ca[wa]=null,Ea=Ca[--wa],Ca[wa]=null}var Ma=null,Na=null,F=!1,Pa=null;function Fa(e,t){var n=Kl(5,null,null,0);n.elementType=`DELETED`,n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function Ia(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null&&(e.stateNode=t,Ma=e,Na=Ui(t.firstChild),!0);case 6:return t=e.pendingProps===``||t.nodeType!==3?null:t,t!==null&&(e.stateNode=t,Ma=e,Na=null,!0);case 13:return t=t.nodeType===8?t:null,t!==null&&(n=Ta===null?null:{id:Ea,overflow:Da},e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=Kl(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,Ma=e,Na=null,!0);default:return!1}}function La(e){return!!(e.mode&1)&&!(e.flags&128)}function Ra(e){if(F){var t=Na;if(t){var n=t;if(!Ia(e,t)){if(La(e))throw Error(i(418));t=Ui(n.nextSibling);var r=Ma;t&&Ia(e,t)?Fa(r,n):(e.flags=e.flags&-4097|2,F=!1,Ma=e)}}else{if(La(e))throw Error(i(418));e.flags=e.flags&-4097|2,F=!1,Ma=e}}}function za(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;Ma=e}function Ba(e){if(e!==Ma)return!1;if(!F)return za(e),F=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!==`head`&&t!==`body`&&!Ii(e.type,e.memoizedProps)),t&&=Na){if(La(e))throw Va(),Error(i(418));for(;t;)Fa(e,t),t=Ui(t.nextSibling)}if(za(e),e.tag===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));a:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`/$`){if(t===0){Na=Ui(e.nextSibling);break a}t--}else n!==`$`&&n!==`$!`&&n!==`$?`||t++}e=e.nextSibling}Na=null}}else Na=Ma?Ui(e.stateNode.nextSibling):null;return!0}function Va(){for(var e=Na;e;)e=Ui(e.nextSibling)}function Ha(){Na=Ma=null,F=!1}function Ua(e){Pa===null?Pa=[e]:Pa.push(e)}var Wa=x.ReactCurrentBatchConfig;function Ga(e,t,n){if(e=n.ref,e!==null&&typeof e!=`function`&&typeof e!=`object`){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(i(309));var r=n.stateNode}if(!r)throw Error(i(147,e));var a=r,o=``+e;return t!==null&&t.ref!==null&&typeof t.ref==`function`&&t.ref._stringRef===o?t.ref:(t=function(e){var t=a.refs;e===null?delete t[o]:t[o]=e},t._stringRef=o,t)}if(typeof e!=`string`)throw Error(i(284));if(!n._owner)throw Error(i(290,e))}return e}function Ka(e,t){throw e=Object.prototype.toString.call(t),Error(i(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e))}function qa(e){var t=e._init;return t(e._payload)}function Ja(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function r(e,t){for(e=new Map;t!==null;)t.key===null?e.set(t.index,t):e.set(t.key,t),t=t.sibling;return e}function a(e,t){return e=Yl(e,t),e.index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=2,n):(r=r.index,r<n?(t.flags|=2,n):r)):(t.flags|=1048576,n)}function s(t){return e&&t.alternate===null&&(t.flags|=2),t}function c(e,t,n,r){return t===null||t.tag!==6?(t=$l(n,e.mode,r),t.return=e,t):(t=a(t,n),t.return=e,t)}function l(e,t,n,r){var i=n.type;return i===ie?d(e,t,n.props.children,r,n.key):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===ue&&qa(i)===t.type)?(r=a(t,n.props),r.ref=Ga(e,t,n),r.return=e,r):(r=Xl(n.type,n.key,n.props,null,e.mode,r),r.ref=Ga(e,t,n),r.return=e,r)}function u(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=eu(n,e.mode,r),t.return=e,t):(t=a(t,n.children||[]),t.return=e,t)}function d(e,t,n,r,i){return t===null||t.tag!==7?(t=Zl(n,e.mode,r,i),t.return=e,t):(t=a(t,n),t.return=e,t)}function f(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`)return t=$l(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case ne:return n=Xl(t.type,t.key,t.props,null,e.mode,n),n.ref=Ga(e,null,t),n.return=e,n;case re:return t=eu(t,e.mode,n),t.return=e,t;case ue:var r=t._init;return f(e,r(t._payload),n)}if(Me(t)||pe(t))return t=Zl(t,e.mode,n,null),t.return=e,t;Ka(e,t)}return null}function p(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`)return i===null?c(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case ne:return n.key===i?l(e,t,n,r):null;case re:return n.key===i?u(e,t,n,r):null;case ue:return i=n._init,p(e,t,i(n._payload),r)}if(Me(n)||pe(n))return i===null?d(e,t,n,r,null):null;Ka(e,n)}return null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`)return e=e.get(n)||null,c(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case ne:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case re:return e=e.get(r.key===null?n:r.key)||null,u(t,e,r,i);case ue:var a=r._init;return m(e,t,n,a(r._payload),i)}if(Me(r)||pe(r))return e=e.get(n)||null,d(t,e,r,i,null);Ka(t,r)}return null}function h(i,a,s,c){for(var l=null,u=null,d=a,h=a=0,g=null;d!==null&&h<s.length;h++){d.index>h?(g=d,d=null):g=d.sibling;var _=p(i,d,s[h],c);if(_===null){d===null&&(d=g);break}e&&d&&_.alternate===null&&t(i,d),a=o(_,a,h),u===null?l=_:u.sibling=_,u=_,d=g}if(h===s.length)return n(i,d),F&&Oa(i,h),l;if(d===null){for(;h<s.length;h++)d=f(i,s[h],c),d!==null&&(a=o(d,a,h),u===null?l=d:u.sibling=d,u=d);return F&&Oa(i,h),l}for(d=r(i,d);h<s.length;h++)g=m(d,i,h,s[h],c),g!==null&&(e&&g.alternate!==null&&d.delete(g.key===null?h:g.key),a=o(g,a,h),u===null?l=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(i,e)}),F&&Oa(i,h),l}function g(a,s,c,l){var u=pe(c);if(typeof u!=`function`)throw Error(i(150));if(c=u.call(c),c==null)throw Error(i(151));for(var d=u=null,h=s,g=s=0,_=null,v=c.next();h!==null&&!v.done;g++,v=c.next()){h.index>g?(_=h,h=null):_=h.sibling;var y=p(a,h,v.value,l);if(y===null){h===null&&(h=_);break}e&&h&&y.alternate===null&&t(a,h),s=o(y,s,g),d===null?u=y:d.sibling=y,d=y,h=_}if(v.done)return n(a,h),F&&Oa(a,g),u;if(h===null){for(;!v.done;g++,v=c.next())v=f(a,v.value,l),v!==null&&(s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return F&&Oa(a,g),u}for(h=r(a,h);!v.done;g++,v=c.next())v=m(h,a,g,v.value,l),v!==null&&(e&&v.alternate!==null&&h.delete(v.key===null?g:v.key),s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return e&&h.forEach(function(e){return t(a,e)}),F&&Oa(a,g),u}function _(e,r,i,o){if(typeof i==`object`&&i&&i.type===ie&&i.key===null&&(i=i.props.children),typeof i==`object`&&i){switch(i.$$typeof){case ne:a:{for(var c=i.key,l=r;l!==null;){if(l.key===c){if(c=i.type,c===ie){if(l.tag===7){n(e,l.sibling),r=a(l,i.props.children),r.return=e,e=r;break a}}else if(l.elementType===c||typeof c==`object`&&c&&c.$$typeof===ue&&qa(c)===l.type){n(e,l.sibling),r=a(l,i.props),r.ref=Ga(e,l,i),r.return=e,e=r;break a}n(e,l);break}t(e,l),l=l.sibling}i.type===ie?(r=Zl(i.props.children,e.mode,o,i.key),r.return=e,e=r):(o=Xl(i.type,i.key,i.props,null,e.mode,o),o.ref=Ga(e,r,i),o.return=e,e=o)}return s(e);case re:a:{for(l=i.key;r!==null;){if(r.key===l){if(r.tag===4&&r.stateNode.containerInfo===i.containerInfo&&r.stateNode.implementation===i.implementation){n(e,r.sibling),r=a(r,i.children||[]),r.return=e,e=r;break a}n(e,r);break}t(e,r),r=r.sibling}r=eu(i,e.mode,o),r.return=e,e=r}return s(e);case ue:return l=i._init,_(e,r,l(i._payload),o)}if(Me(i))return h(e,r,i,o);if(pe(i))return g(e,r,i,o);Ka(e,i)}return typeof i==`string`&&i!==``||typeof i==`number`?(i=``+i,r!==null&&r.tag===6?(n(e,r.sibling),r=a(r,i),r.return=e,e=r):(n(e,r),r=$l(i,e.mode,o),r.return=e,e=r),s(e)):n(e,r)}return _}var Ya=Ja(!0),Xa=Ja(!1),Za=ia(null),Qa=null,$a=null,eo=null;function to(){eo=$a=Qa=null}function no(e){var t=Za.current;A(Za),e._currentValue=t}function ro(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function io(e,t){Qa=e,eo=$a=null,e=e.dependencies,e!==null&&e.firstContext!==null&&((e.lanes&t)!==0&&(Us=!0),e.firstContext=null)}function ao(e){var t=e._currentValue;if(eo!==e){if(e={context:e,memoizedValue:t,next:null},$a===null){if(Qa===null)throw Error(i(308));$a=e,Qa.dependencies={lanes:0,firstContext:e}}else $a=$a.next=e}return t}var oo=null;function so(e){oo===null?oo=[e]:oo.push(e)}function co(e,t,n,r){var i=t.interleaved;return i===null?(n.next=n,so(t)):(n.next=i.next,i.next=n),t.interleaved=n,lo(e,r)}function lo(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var uo=!1;function fo(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function po(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function mo(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function ho(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,K&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,lo(e,n)}return i=r.interleaved,i===null?(t.next=t,so(r)):(t.next=i.next,i.next=t),r.interleaved=t,lo(e,n)}function go(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194240)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,$t(e,n)}}function _o(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,effects:r.effects},e.updateQueue=n}else e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function vo(e,t,n,r){var i=e.updateQueue;uo=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane,p=s.eventTime;if((r&f)===f){u!==null&&(u=u.next={eventTime:p,lane:0,tag:s.tag,payload:s.payload,callback:s.callback,next:null});a:{var m=e,h=s;switch(f=t,p=n,h.tag){case 1:if(m=h.payload,typeof m==`function`){d=m.call(p,d,f);break a}d=m;break a;case 3:m.flags=m.flags&-65537|128;case 0:if(m=h.payload,f=typeof m==`function`?m.call(p,d,f):m,f==null)break a;d=T({},d,f);break a;case 2:uo=!0}}s.callback!==null&&s.lane!==0&&(e.flags|=64,f=i.effects,f===null?i.effects=[s]:f.push(s))}else p={eventTime:p,lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;f=s,s=f.next,f.next=null,i.lastBaseUpdate=f,i.shared.pending=null}}while(1);if(u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,t=i.shared.interleaved,t!==null){i=t;do o|=i.lane,i=i.next;while(i!==t)}else a===null&&(i.shared.lanes=0);Zc|=o,e.lanes=o,e.memoizedState=d}}function yo(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var r=e[t],a=r.callback;if(a!==null){if(r.callback=null,r=n,typeof a!=`function`)throw Error(i(191,a));a.call(r)}}}var bo={},xo=ia(bo),So=ia(bo),Co=ia(bo);function wo(e){if(e===bo)throw Error(i(174));return e}function To(e,t){switch(j(Co,t),j(So,e),j(xo,bo),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:ze(null,``);break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=ze(t,e)}A(xo),j(xo,t)}function Eo(){A(xo),A(So),A(Co)}function Do(e){wo(Co.current);var t=wo(xo.current),n=ze(t,e.type);t!==n&&(j(So,e),j(xo,n))}function Oo(e){So.current===e&&(A(xo),A(So))}var I=ia(0);function ko(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data===`$?`||n.data===`$!`))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Ao=[];function jo(){for(var e=0;e<Ao.length;e++)Ao[e]._workInProgressVersionPrimary=null;Ao.length=0}var Mo=x.ReactCurrentDispatcher,No=x.ReactCurrentBatchConfig,Po=0,L=null,R=null,z=null,Fo=!1,Io=!1,Lo=0,Ro=0;function B(){throw Error(i(321))}function zo(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Hr(e[n],t[n]))return!1;return!0}function Bo(e,t,n,r,a,o){if(Po=o,L=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,Mo.current=e===null||e.memoizedState===null?Cs:ws,e=n(r,a),Io){o=0;do{if(Io=!1,Lo=0,25<=o)throw Error(i(301));o+=1,z=R=null,t.updateQueue=null,Mo.current=Ts,e=n(r,a)}while(Io)}if(Mo.current=Ss,t=R!==null&&R.next!==null,Po=0,z=R=L=null,Fo=!1,t)throw Error(i(300));return e}function Vo(){var e=Lo!==0;return Lo=0,e}function Ho(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return z===null?L.memoizedState=z=e:z=z.next=e,z}function Uo(){if(R===null){var e=L.alternate;e=e===null?null:e.memoizedState}else e=R.next;var t=z===null?L.memoizedState:z.next;if(t!==null)z=t,R=e;else{if(e===null)throw Error(i(310));R=e,e={memoizedState:R.memoizedState,baseState:R.baseState,baseQueue:R.baseQueue,queue:R.queue,next:null},z===null?L.memoizedState=z=e:z=z.next=e}return z}function Wo(e,t){return typeof t==`function`?t(e):t}function Go(e){var t=Uo(),n=t.queue;if(n===null)throw Error(i(311));n.lastRenderedReducer=e;var r=R,a=r.baseQueue,o=n.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}r.baseQueue=a=o,n.pending=null}if(a!==null){o=a.next,r=r.baseState;var c=s=null,l=null,u=o;do{var d=u.lane;if((Po&d)===d)l!==null&&(l=l.next={lane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),r=u.hasEagerState?u.eagerState:e(r,u.action);else{var f={lane:d,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null};l===null?(c=l=f,s=r):l=l.next=f,L.lanes|=d,Zc|=d}u=u.next}while(u!==null&&u!==o);l===null?s=r:l.next=c,Hr(r,t.memoizedState)||(Us=!0),t.memoizedState=r,t.baseState=s,t.baseQueue=l,n.lastRenderedState=r}if(e=n.interleaved,e!==null){a=e;do o=a.lane,L.lanes|=o,Zc|=o,a=a.next;while(a!==e)}else a===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function Ko(e){var t=Uo(),n=t.queue;if(n===null)throw Error(i(311));n.lastRenderedReducer=e;var r=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);Hr(o,t.memoizedState)||(Us=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function qo(){}function Jo(e,t){var n=L,r=Uo(),a=t(),o=!Hr(r.memoizedState,a);if(o&&(r.memoizedState=a,Us=!0),r=r.queue,os(Zo.bind(null,n,r,e),[e]),r.getSnapshot!==t||o||z!==null&&z.memoizedState.tag&1){if(n.flags|=2048,ts(9,Xo.bind(null,n,r,a,t),void 0,null),q===null)throw Error(i(349));Po&30||Yo(n,t,a)}return a}function Yo(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=L.updateQueue,t===null?(t={lastEffect:null,stores:null},L.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Xo(e,t,n,r){t.value=n,t.getSnapshot=r,Qo(t)&&$o(e)}function Zo(e,t,n){return n(function(){Qo(t)&&$o(e)})}function Qo(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Hr(e,n)}catch{return!0}}function $o(e){var t=lo(e,1);t!==null&&gl(t,e,1,-1)}function es(e){var t=Ho();return typeof e==`function`&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Wo,lastRenderedState:e},t.queue=e,e=e.dispatch=vs.bind(null,L,e),[t.memoizedState,e]}function ts(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=L.updateQueue,t===null?(t={lastEffect:null,stores:null},L.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function ns(){return Uo().memoizedState}function rs(e,t,n,r){var i=Ho();L.flags|=e,i.memoizedState=ts(1|t,n,void 0,r===void 0?null:r)}function is(e,t,n,r){var i=Uo();r=r===void 0?null:r;var a=void 0;if(R!==null){var o=R.memoizedState;if(a=o.destroy,r!==null&&zo(r,o.deps)){i.memoizedState=ts(t,n,a,r);return}}L.flags|=e,i.memoizedState=ts(1|t,n,a,r)}function as(e,t){return rs(8390656,8,e,t)}function os(e,t){return is(2048,8,e,t)}function ss(e,t){return is(4,2,e,t)}function cs(e,t){return is(4,4,e,t)}function ls(e,t){if(typeof t==`function`)return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function us(e,t,n){return n=n==null?null:n.concat([e]),is(4,4,ls.bind(null,t,e),n)}function ds(){}function fs(e,t){var n=Uo();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&zo(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function ps(e,t){var n=Uo();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&zo(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function ms(e,t,n){return Po&21?(Hr(n,t)||(n=Yt(),L.lanes|=n,Zc|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,Us=!0),e.memoizedState=n)}function hs(e,t){var n=O;O=n!==0&&4>n?n:4,e(!0);var r=No.transition;No.transition={};try{e(!1),t()}finally{O=n,No.transition=r}}function gs(){return Uo().memoizedState}function _s(e,t,n){var r=hl(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},ys(e))bs(t,n);else if(n=co(e,t,n,r),n!==null){var i=Z();gl(n,e,r,i),xs(n,t,r)}}function vs(e,t,n){var r=hl(e),i={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(ys(e))bs(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,Hr(s,o)){var c=t.interleaved;c===null?(i.next=i,so(t)):(i.next=c.next,c.next=i),t.interleaved=i;return}}catch{}n=co(e,t,i,r),n!==null&&(i=Z(),gl(n,e,r,i),xs(n,t,r))}}function ys(e){var t=e.alternate;return e===L||t!==null&&t===L}function bs(e,t){Io=Fo=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function xs(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,$t(e,n)}}var Ss={readContext:ao,useCallback:B,useContext:B,useEffect:B,useImperativeHandle:B,useInsertionEffect:B,useLayoutEffect:B,useMemo:B,useReducer:B,useRef:B,useState:B,useDebugValue:B,useDeferredValue:B,useTransition:B,useMutableSource:B,useSyncExternalStore:B,useId:B,unstable_isNewReconciler:!1},Cs={readContext:ao,useCallback:function(e,t){return Ho().memoizedState=[e,t===void 0?null:t],e},useContext:ao,useEffect:as,useImperativeHandle:function(e,t,n){return n=n==null?null:n.concat([e]),rs(4194308,4,ls.bind(null,t,e),n)},useLayoutEffect:function(e,t){return rs(4194308,4,e,t)},useInsertionEffect:function(e,t){return rs(4,2,e,t)},useMemo:function(e,t){var n=Ho();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=Ho();return t=n===void 0?t:n(t),r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=_s.bind(null,L,e),[r.memoizedState,e]},useRef:function(e){var t=Ho();return e={current:e},t.memoizedState=e},useState:es,useDebugValue:ds,useDeferredValue:function(e){return Ho().memoizedState=e},useTransition:function(){var e=es(!1),t=e[0];return e=hs.bind(null,e[1]),Ho().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var r=L,a=Ho();if(F){if(n===void 0)throw Error(i(407));n=n()}else{if(n=t(),q===null)throw Error(i(349));Po&30||Yo(r,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,as(Zo.bind(null,r,o,e),[e]),r.flags|=2048,ts(9,Xo.bind(null,r,o,n,t),void 0,null),n},useId:function(){var e=Ho(),t=q.identifierPrefix;if(F){var n=Da,r=Ea;n=(r&~(1<<32-Rt(r)-1)).toString(32)+n,t=`:`+t+`R`+n,n=Lo++,0<n&&(t+=`H`+n.toString(32)),t+=`:`}else n=Ro++,t=`:`+t+`r`+n.toString(32)+`:`;return e.memoizedState=t},unstable_isNewReconciler:!1},ws={readContext:ao,useCallback:fs,useContext:ao,useEffect:os,useImperativeHandle:us,useInsertionEffect:ss,useLayoutEffect:cs,useMemo:ps,useReducer:Go,useRef:ns,useState:function(){return Go(Wo)},useDebugValue:ds,useDeferredValue:function(e){return ms(Uo(),R.memoizedState,e)},useTransition:function(){return[Go(Wo)[0],Uo().memoizedState]},useMutableSource:qo,useSyncExternalStore:Jo,useId:gs,unstable_isNewReconciler:!1},Ts={readContext:ao,useCallback:fs,useContext:ao,useEffect:os,useImperativeHandle:us,useInsertionEffect:ss,useLayoutEffect:cs,useMemo:ps,useReducer:Ko,useRef:ns,useState:function(){return Ko(Wo)},useDebugValue:ds,useDeferredValue:function(e){var t=Uo();return R===null?t.memoizedState=e:ms(t,R.memoizedState,e)},useTransition:function(){return[Ko(Wo)[0],Uo().memoizedState]},useMutableSource:qo,useSyncExternalStore:Jo,useId:gs,unstable_isNewReconciler:!1};function Es(e,t){if(e&&e.defaultProps){for(var n in t=T({},t),e=e.defaultProps,e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function Ds(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:T({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var Os={isMounted:function(e){return(e=e._reactInternals)?yt(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=Z(),i=hl(e),a=mo(r,i);a.payload=t,n!=null&&(a.callback=n),t=ho(e,a,i),t!==null&&(gl(t,e,i,r),go(t,e,i))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=Z(),i=hl(e),a=mo(r,i);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=ho(e,a,i),t!==null&&(gl(t,e,i,r),go(t,e,i))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Z(),r=hl(e),i=mo(n,r);i.tag=2,t!=null&&(i.callback=t),t=ho(e,i,r),t!==null&&(gl(t,e,r,n),go(t,e,r))}};function ks(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Ur(n,r)||!Ur(i,a):!0}function As(e,t,n){var r=!1,i=aa,a=t.contextType;return typeof a==`object`&&a?a=ao(a):(i=P(t)?oa:M.current,r=t.contextTypes,a=(r=r!=null)?sa(e,i):aa),t=new t(n,a),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=Os,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=i,e.__reactInternalMemoizedMaskedChildContext=a),t}function js(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&Os.enqueueReplaceState(t,t.state,null)}function Ms(e,t,n,r){var i=e.stateNode;i.props=n,i.state=e.memoizedState,i.refs={},fo(e);var a=t.contextType;typeof a==`object`&&a?i.context=ao(a):(a=P(t)?oa:M.current,i.context=sa(e,a)),i.state=e.memoizedState,a=t.getDerivedStateFromProps,typeof a==`function`&&(Ds(e,t,a,n),i.state=e.memoizedState),typeof t.getDerivedStateFromProps==`function`||typeof i.getSnapshotBeforeUpdate==`function`||typeof i.UNSAFE_componentWillMount!=`function`&&typeof i.componentWillMount!=`function`||(t=i.state,typeof i.componentWillMount==`function`&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount==`function`&&i.UNSAFE_componentWillMount(),t!==i.state&&Os.enqueueReplaceState(i,i.state,null),vo(e,n,i,r),i.state=e.memoizedState),typeof i.componentDidMount==`function`&&(e.flags|=4194308)}function Ns(e,t){try{var n=``,r=t;do n+=_e(r),r=r.return;while(r);var i=n}catch(e){i=`
Error generating stack: `+e.message+`
`+e.stack}return{value:e,source:t,stack:i,digest:null}}function Ps(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function Fs(e,t){try{console.error(t.value)}catch(e){setTimeout(function(){throw e})}}var Is=typeof WeakMap==`function`?WeakMap:Map;function Ls(e,t,n){n=mo(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){al||(al=!0,ol=r),Fs(e,t)},n}function Rs(e,t,n){n=mo(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r==`function`){var i=t.value;n.payload=function(){return r(i)},n.callback=function(){Fs(e,t)}}var a=e.stateNode;return a!==null&&typeof a.componentDidCatch==`function`&&(n.callback=function(){Fs(e,t),typeof r!=`function`&&(sl===null?sl=new Set([this]):sl.add(this));var n=t.stack;this.componentDidCatch(t.value,{componentStack:n===null?``:n})}),n}function zs(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new Is;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(i.add(n),e=zl.bind(null,e,t,n),t.then(e,e))}function Bs(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t===null||t.dehydrated!==null),t)return e;e=e.return}while(e!==null);return null}function Vs(e,t,n,r,i){return e.mode&1?(e.flags|=65536,e.lanes=i,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=mo(-1,1),t.tag=2,ho(n,t,1))),n.lanes|=1),e)}var Hs=x.ReactCurrentOwner,Us=!1;function V(e,t,n,r){t.child=e===null?Xa(t,null,n,r):Ya(t,e.child,n,r)}function Ws(e,t,n,r,i){n=n.render;var a=t.ref;return io(t,i),r=Bo(e,t,n,r,a,i),n=Vo(),e!==null&&!Us?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,uc(e,t,i)):(F&&n&&Aa(t),t.flags|=1,V(e,t,r,i),t.child)}function Gs(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!ql(a)&&a.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=a,Ks(e,t,a,r,i)):(e=Xl(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,(e.lanes&i)===0){var o=a.memoizedProps;if(n=n.compare,n=n===null?Ur:n,n(o,r)&&e.ref===t.ref)return uc(e,t,i)}return t.flags|=1,e=Yl(a,r),e.ref=t.ref,e.return=t,t.child=e}function Ks(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Ur(a,r)&&e.ref===t.ref){if(Us=!1,t.pendingProps=r=a,(e.lanes&i)!==0)e.flags&131072&&(Us=!0);else return t.lanes=e.lanes,uc(e,t,i)}}return Ys(e,t,n,r,i)}function qs(e,t,n){var r=t.pendingProps,i=r.children,a=e===null?null:e.memoizedState;if(r.mode===`hidden`){if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},j(Yc,Jc),Jc|=n;else{if(!(n&1073741824))return e=a===null?n:a.baseLanes|n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,j(Yc,Jc),Jc|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=a===null?n:a.baseLanes,j(Yc,Jc),Jc|=r}}else a===null?r=n:(r=a.baseLanes|n,t.memoizedState=null),j(Yc,Jc),Jc|=r;return V(e,t,i,n),t.child}function Js(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function Ys(e,t,n,r,i){var a=P(n)?oa:M.current;return a=sa(t,a),io(t,i),n=Bo(e,t,n,r,a,i),r=Vo(),e!==null&&!Us?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,uc(e,t,i)):(F&&r&&Aa(t),t.flags|=1,V(e,t,n,i),t.child)}function Xs(e,t,n,r,i){if(P(n)){var a=!0;da(t)}else a=!1;if(io(t,i),t.stateNode===null)lc(e,t),As(t,n,r),Ms(t,n,r,i),r=!0;else if(e===null){var o=t.stateNode,s=t.memoizedProps;o.props=s;var c=o.context,l=n.contextType;typeof l==`object`&&l?l=ao(l):(l=P(n)?oa:M.current,l=sa(t,l));var u=n.getDerivedStateFromProps,d=typeof u==`function`||typeof o.getSnapshotBeforeUpdate==`function`;d||typeof o.UNSAFE_componentWillReceiveProps!=`function`&&typeof o.componentWillReceiveProps!=`function`||(s!==r||c!==l)&&js(t,o,r,l),uo=!1;var f=t.memoizedState;o.state=f,vo(t,r,o,i),c=t.memoizedState,s!==r||f!==c||N.current||uo?(typeof u==`function`&&(Ds(t,n,u,r),c=t.memoizedState),(s=uo||ks(t,n,s,r,f,c,l))?(d||typeof o.UNSAFE_componentWillMount!=`function`&&typeof o.componentWillMount!=`function`||(typeof o.componentWillMount==`function`&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount==`function`&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount==`function`&&(t.flags|=4194308)):(typeof o.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=c),o.props=r,o.state=c,o.context=l,r=s):(typeof o.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{o=t.stateNode,po(e,t),s=t.memoizedProps,l=t.type===t.elementType?s:Es(t.type,s),o.props=l,d=t.pendingProps,f=o.context,c=n.contextType,typeof c==`object`&&c?c=ao(c):(c=P(n)?oa:M.current,c=sa(t,c));var p=n.getDerivedStateFromProps;(u=typeof p==`function`||typeof o.getSnapshotBeforeUpdate==`function`)||typeof o.UNSAFE_componentWillReceiveProps!=`function`&&typeof o.componentWillReceiveProps!=`function`||(s!==d||f!==c)&&js(t,o,r,c),uo=!1,f=t.memoizedState,o.state=f,vo(t,r,o,i);var m=t.memoizedState;s!==d||f!==m||N.current||uo?(typeof p==`function`&&(Ds(t,n,p,r),m=t.memoizedState),(l=uo||ks(t,n,l,r,f,m,c)||!1)?(u||typeof o.UNSAFE_componentWillUpdate!=`function`&&typeof o.componentWillUpdate!=`function`||(typeof o.componentWillUpdate==`function`&&o.componentWillUpdate(r,m,c),typeof o.UNSAFE_componentWillUpdate==`function`&&o.UNSAFE_componentWillUpdate(r,m,c)),typeof o.componentDidUpdate==`function`&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof o.componentDidUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=m),o.props=r,o.state=m,o.context=c,r=l):(typeof o.componentDidUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return Zs(e,t,n,r,a,i)}function Zs(e,t,n,r,i,a){Js(e,t);var o=!!(t.flags&128);if(!r&&!o)return i&&fa(t,n,!1),uc(e,t,a);r=t.stateNode,Hs.current=t;var s=o&&typeof n.getDerivedStateFromError!=`function`?null:r.render();return t.flags|=1,e!==null&&o?(t.child=Ya(t,e.child,null,a),t.child=Ya(t,null,s,a)):V(e,t,s,a),t.memoizedState=r.state,i&&fa(t,n,!0),t.child}function Qs(e){var t=e.stateNode;t.pendingContext?la(e,t.pendingContext,t.pendingContext!==t.context):t.context&&la(e,t.context,!1),To(e,t.containerInfo)}function $s(e,t,n,r,i){return Ha(),Ua(i),t.flags|=256,V(e,t,n,r),t.child}var ec={dehydrated:null,treeContext:null,retryLane:0};function tc(e){return{baseLanes:e,cachePool:null,transitions:null}}function nc(e,t,n){var r=t.pendingProps,i=I.current,a=!1,o=!!(t.flags&128),s;if((s=o)||(s=e!==null&&e.memoizedState===null?!1:!!(i&2)),s?(a=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(i|=1),j(I,i&1),e===null)return Ra(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.lanes=t.mode&1?e.data===`$!`?8:1073741824:1,null):(o=r.children,e=r.fallback,a?(r=t.mode,a=t.child,o={mode:`hidden`,children:o},!(r&1)&&a!==null?(a.childLanes=0,a.pendingProps=o):a=Ql(o,r,0,null),e=Zl(e,r,n,null),a.return=t,e.return=t,a.sibling=e,t.child=a,t.child.memoizedState=tc(n),t.memoizedState=ec,e):rc(t,o));if(i=e.memoizedState,i!==null&&(s=i.dehydrated,s!==null))return ac(e,t,o,r,s,i,n);if(a){a=r.fallback,o=t.mode,i=e.child,s=i.sibling;var c={mode:`hidden`,children:r.children};return!(o&1)&&t.child!==i?(r=t.child,r.childLanes=0,r.pendingProps=c,t.deletions=null):(r=Yl(i,c),r.subtreeFlags=i.subtreeFlags&14680064),s===null?(a=Zl(a,o,n,null),a.flags|=2):a=Yl(s,a),a.return=t,r.return=t,r.sibling=a,t.child=r,r=a,a=t.child,o=e.child.memoizedState,o=o===null?tc(n):{baseLanes:o.baseLanes|n,cachePool:null,transitions:o.transitions},a.memoizedState=o,a.childLanes=e.childLanes&~n,t.memoizedState=ec,r}return a=e.child,e=a.sibling,r=Yl(a,{mode:`visible`,children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function rc(e,t){return t=Ql({mode:`visible`,children:t},e.mode,0,null),t.return=e,e.child=t}function ic(e,t,n,r){return r!==null&&Ua(r),Ya(t,e.child,null,n),e=rc(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function ac(e,t,n,r,a,o,s){if(n)return t.flags&256?(t.flags&=-257,r=Ps(Error(i(422))),ic(e,t,s,r)):t.memoizedState===null?(o=r.fallback,a=t.mode,r=Ql({mode:`visible`,children:r.children},a,0,null),o=Zl(o,a,s,null),o.flags|=2,r.return=t,o.return=t,r.sibling=o,t.child=r,t.mode&1&&Ya(t,e.child,null,s),t.child.memoizedState=tc(s),t.memoizedState=ec,o):(t.child=e.child,t.flags|=128,null);if(!(t.mode&1))return ic(e,t,s,null);if(a.data===`$!`){if(r=a.nextSibling&&a.nextSibling.dataset,r)var c=r.dgst;return r=c,o=Error(i(419)),r=Ps(o,r,void 0),ic(e,t,s,r)}if(c=(s&e.childLanes)!==0,Us||c){if(r=q,r!==null){switch(s&-s){case 4:a=2;break;case 16:a=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:a=32;break;case 536870912:a=268435456;break;default:a=0}a=(a&(r.suspendedLanes|s))===0?a:0,a!==0&&a!==o.retryLane&&(o.retryLane=a,lo(e,a),gl(r,e,a,-1))}return kl(),r=Ps(Error(i(421))),ic(e,t,s,r)}return a.data===`$?`?(t.flags|=128,t.child=e.child,t=Vl.bind(null,e),a._reactRetry=t,null):(e=o.treeContext,Na=Ui(a.nextSibling),Ma=t,F=!0,Pa=null,e!==null&&(Ca[wa++]=Ea,Ca[wa++]=Da,Ca[wa++]=Ta,Ea=e.id,Da=e.overflow,Ta=t),t=rc(t,r.children),t.flags|=4096,t)}function oc(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),ro(e.return,t,n)}function sc(e,t,n,r,i){var a=e.memoizedState;a===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i}:(a.isBackwards=t,a.rendering=null,a.renderingStartTime=0,a.last=r,a.tail=n,a.tailMode=i)}function cc(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;if(V(e,t,r.children,n),r=I.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&oc(e,n,t);else if(e.tag===19)oc(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(j(I,r),!(t.mode&1))t.memoizedState=null;else switch(i){case`forwards`:for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&ko(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),sc(t,!1,i,n,a);break;case`backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&ko(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}sc(t,!0,n,null,a);break;case`together`:sc(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function lc(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function uc(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Zc|=t.lanes,(n&t.childLanes)===0)return null;if(e!==null&&t.child!==e.child)throw Error(i(153));if(t.child!==null){for(e=t.child,n=Yl(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Yl(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function dc(e,t,n){switch(t.tag){case 3:Qs(t),Ha();break;case 5:Do(t);break;case 1:P(t.type)&&da(t);break;case 4:To(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,i=t.memoizedProps.value;j(Za,r._currentValue),r._currentValue=i;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated===null?(n&t.child.childLanes)===0?(j(I,I.current&1),e=uc(e,t,n),e===null?null:e.sibling):nc(e,t,n):(j(I,I.current&1),t.flags|=128,null);j(I,I.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return cc(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),j(I,I.current),r)break;return null;case 22:case 23:return t.lanes=0,qs(e,t,n)}return uc(e,t,n)}var fc=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}},pc=function(e,t,n,r){var i=e.memoizedProps;if(i!==r){e=t.stateNode,wo(xo.current);var a=null;switch(n){case`input`:i=Ee(e,i),r=Ee(e,r),a=[];break;case`select`:i=T({},i,{value:void 0}),r=T({},r,{value:void 0}),a=[];break;case`textarea`:i=Pe(e,i),r=Pe(e,r),a=[];break;default:typeof i.onClick!=`function`&&typeof r.onClick==`function`&&(e.onclick=Ni)}Je(n,r);var o;for(u in n=null,i)if(!r.hasOwnProperty(u)&&i.hasOwnProperty(u)&&i[u]!=null){if(u===`style`){var c=i[u];for(o in c)c.hasOwnProperty(o)&&(n||={},n[o]=``)}else u!==`dangerouslySetInnerHTML`&&u!==`children`&&u!==`suppressContentEditableWarning`&&u!==`suppressHydrationWarning`&&u!==`autoFocus`&&(s.hasOwnProperty(u)?a||=[]:(a||=[]).push(u,null))}for(u in r){var l=r[u];if(c=i?.[u],r.hasOwnProperty(u)&&l!==c&&(l!=null||c!=null)){if(u===`style`){if(c){for(o in c)!c.hasOwnProperty(o)||l&&l.hasOwnProperty(o)||(n||={},n[o]=``);for(o in l)l.hasOwnProperty(o)&&c[o]!==l[o]&&(n||={},n[o]=l[o])}else n||(a||=[],a.push(u,n)),n=l}else u===`dangerouslySetInnerHTML`?(l=l?l.__html:void 0,c=c?c.__html:void 0,l!=null&&c!==l&&(a||=[]).push(u,l)):u===`children`?typeof l!=`string`&&typeof l!=`number`||(a||=[]).push(u,``+l):u!==`suppressContentEditableWarning`&&u!==`suppressHydrationWarning`&&(s.hasOwnProperty(u)?(l!=null&&u===`onScroll`&&k(`scroll`,e),a||c===l||(a=[])):(a||=[]).push(u,l))}}n&&(a||=[]).push(`style`,n);var u=a;(t.updateQueue=u)&&(t.flags|=4)}},mc=function(e,t,n,r){n!==r&&(t.flags|=4)};function hc(e,t){if(!F)switch(e.tailMode){case`hidden`:t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case`collapsed`:n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function H(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&14680064,r|=i.flags&14680064,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function gc(e,t,n){var r=t.pendingProps;switch(ja(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return H(t),null;case 1:return P(t.type)&&ca(),H(t),null;case 3:return r=t.stateNode,Eo(),A(N),A(M),jo(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(Ba(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Pa!==null&&(yl(Pa),Pa=null))),H(t),null;case 5:Oo(t);var a=wo(Co.current);if(n=t.type,e!==null&&t.stateNode!=null)pc(e,t,n,r,a),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!r){if(t.stateNode===null)throw Error(i(166));return H(t),null}if(e=wo(xo.current),Ba(t)){r=t.stateNode,n=t.type;var o=t.memoizedProps;switch(r[Ki]=t,r[qi]=o,e=!!(t.mode&1),n){case`dialog`:k(`cancel`,r),k(`close`,r);break;case`iframe`:case`object`:case`embed`:k(`load`,r);break;case`video`:case`audio`:for(a=0;a<gi.length;a++)k(gi[a],r);break;case`source`:k(`error`,r);break;case`img`:case`image`:case`link`:k(`error`,r),k(`load`,r);break;case`details`:k(`toggle`,r);break;case`input`:De(r,o),k(`invalid`,r);break;case`select`:r._wrapperState={wasMultiple:!!o.multiple},k(`invalid`,r);break;case`textarea`:Fe(r,o),k(`invalid`,r)}for(var c in Je(n,o),a=null,o)if(o.hasOwnProperty(c)){var l=o[c];c===`children`?typeof l==`string`?r.textContent!==l&&(!0!==o.suppressHydrationWarning&&Mi(r.textContent,l,e),a=[`children`,l]):typeof l==`number`&&r.textContent!==``+l&&(!0!==o.suppressHydrationWarning&&Mi(r.textContent,l,e),a=[`children`,``+l]):s.hasOwnProperty(c)&&l!=null&&c===`onScroll`&&k(`scroll`,r)}switch(n){case`input`:Ce(r),Ae(r,o,!0);break;case`textarea`:Ce(r),Le(r);break;case`select`:case`option`:break;default:typeof o.onClick==`function`&&(r.onclick=Ni)}r=a,t.updateQueue=r,r!==null&&(t.flags|=4)}else{c=a.nodeType===9?a:a.ownerDocument,e===`http://www.w3.org/1999/xhtml`&&(e=Re(n)),e===`http://www.w3.org/1999/xhtml`?n===`script`?(e=c.createElement(`div`),e.innerHTML=`<script><\/script>`,e=e.removeChild(e.firstChild)):typeof r.is==`string`?e=c.createElement(n,{is:r.is}):(e=c.createElement(n),n===`select`&&(c=e,r.multiple?c.multiple=!0:r.size&&(c.size=r.size))):e=c.createElementNS(e,n),e[Ki]=t,e[qi]=r,fc(e,t,!1,!1),t.stateNode=e;a:{switch(c=Ye(n,r),n){case`dialog`:k(`cancel`,e),k(`close`,e),a=r;break;case`iframe`:case`object`:case`embed`:k(`load`,e),a=r;break;case`video`:case`audio`:for(a=0;a<gi.length;a++)k(gi[a],e);a=r;break;case`source`:k(`error`,e),a=r;break;case`img`:case`image`:case`link`:k(`error`,e),k(`load`,e),a=r;break;case`details`:k(`toggle`,e),a=r;break;case`input`:De(e,r),a=Ee(e,r),k(`invalid`,e);break;case`option`:a=r;break;case`select`:e._wrapperState={wasMultiple:!!r.multiple},a=T({},r,{value:void 0}),k(`invalid`,e);break;case`textarea`:Fe(e,r),a=Pe(e,r),k(`invalid`,e);break;default:a=r}for(o in Je(n,a),l=a,l)if(l.hasOwnProperty(o)){var u=l[o];o===`style`?Ke(e,u):o===`dangerouslySetInnerHTML`?(u=u?u.__html:void 0,u!=null&&Ve(e,u)):o===`children`?typeof u==`string`?(n!==`textarea`||u!==``)&&He(e,u):typeof u==`number`&&He(e,``+u):o!==`suppressContentEditableWarning`&&o!==`suppressHydrationWarning`&&o!==`autoFocus`&&(s.hasOwnProperty(o)?u!=null&&o===`onScroll`&&k(`scroll`,e):u!=null&&te(e,o,u,c))}switch(n){case`input`:Ce(e),Ae(e,r,!1);break;case`textarea`:Ce(e),Le(e);break;case`option`:r.value!=null&&e.setAttribute(`value`,``+be(r.value));break;case`select`:e.multiple=!!r.multiple,o=r.value,o==null?r.defaultValue!=null&&Ne(e,!!r.multiple,r.defaultValue,!0):Ne(e,!!r.multiple,o,!1);break;default:typeof a.onClick==`function`&&(e.onclick=Ni)}switch(n){case`button`:case`input`:case`select`:case`textarea`:r=!!r.autoFocus;break a;case`img`:r=!0;break a;default:r=!1}}r&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return H(t),null;case 6:if(e&&t.stateNode!=null)mc(e,t,e.memoizedProps,r);else{if(typeof r!=`string`&&t.stateNode===null)throw Error(i(166));if(n=wo(Co.current),wo(xo.current),Ba(t)){if(r=t.stateNode,n=t.memoizedProps,r[Ki]=t,(o=r.nodeValue!==n)&&(e=Ma,e!==null))switch(e.tag){case 3:Mi(r.nodeValue,n,!!(e.mode&1));break;case 5:!0!==e.memoizedProps.suppressHydrationWarning&&Mi(r.nodeValue,n,!!(e.mode&1))}o&&(t.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[Ki]=t,t.stateNode=r}return H(t),null;case 13:if(A(I),r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(F&&Na!==null&&t.mode&1&&!(t.flags&128))Va(),Ha(),t.flags|=98560,o=!1;else if(o=Ba(t),r!==null&&r.dehydrated!==null){if(e===null){if(!o)throw Error(i(318));if(o=t.memoizedState,o=o===null?null:o.dehydrated,!o)throw Error(i(317));o[Ki]=t}else Ha(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;H(t),o=!1}else Pa!==null&&(yl(Pa),Pa=null),o=!0;if(!o)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(r=r!==null,r!==(e!==null&&e.memoizedState!==null)&&r&&(t.child.flags|=8192,t.mode&1&&(e===null||I.current&1?X===0&&(X=3):kl())),t.updateQueue!==null&&(t.flags|=4),H(t),null);case 4:return Eo(),e===null&&Si(t.stateNode.containerInfo),H(t),null;case 10:return no(t.type._context),H(t),null;case 17:return P(t.type)&&ca(),H(t),null;case 19:if(A(I),o=t.memoizedState,o===null)return H(t),null;if(r=!!(t.flags&128),c=o.rendering,c===null){if(r)hc(o,!1);else{if(X!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(c=ko(e),c!==null){for(t.flags|=128,hc(o,!1),r=c.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),t.subtreeFlags=0,r=n,n=t.child;n!==null;)o=n,e=r,o.flags&=14680066,c=o.alternate,c===null?(o.childLanes=0,o.lanes=e,o.child=null,o.subtreeFlags=0,o.memoizedProps=null,o.memoizedState=null,o.updateQueue=null,o.dependencies=null,o.stateNode=null):(o.childLanes=c.childLanes,o.lanes=c.lanes,o.child=c.child,o.subtreeFlags=0,o.deletions=null,o.memoizedProps=c.memoizedProps,o.memoizedState=c.memoizedState,o.updateQueue=c.updateQueue,o.type=c.type,e=c.dependencies,o.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return j(I,I.current&1|2),t.child}e=e.sibling}o.tail!==null&&D()>rl&&(t.flags|=128,r=!0,hc(o,!1),t.lanes=4194304)}}else{if(!r){if(e=ko(c),e!==null){if(t.flags|=128,r=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),hc(o,!0),o.tail===null&&o.tailMode===`hidden`&&!c.alternate&&!F)return H(t),null}else 2*D()-o.renderingStartTime>rl&&n!==1073741824&&(t.flags|=128,r=!0,hc(o,!1),t.lanes=4194304)}o.isBackwards?(c.sibling=t.child,t.child=c):(n=o.last,n===null?t.child=c:n.sibling=c,o.last=c)}return o.tail===null?(H(t),null):(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=D(),t.sibling=null,n=I.current,j(I,r?n&1|2:n&1),t);case 22:case 23:return Tl(),r=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==r&&(t.flags|=8192),r&&t.mode&1?Jc&1073741824&&(H(t),t.subtreeFlags&6&&(t.flags|=8192)):H(t),null;case 24:return null;case 25:return null}throw Error(i(156,t.tag))}function _c(e,t){switch(ja(t),t.tag){case 1:return P(t.type)&&ca(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Eo(),A(N),A(M),jo(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return Oo(t),null;case 13:if(A(I),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(i(340));Ha()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return A(I),null;case 4:return Eo(),null;case 10:return no(t.type._context),null;case 22:case 23:return Tl(),null;case 24:return null;default:return null}}var vc=!1,U=!1,yc=typeof WeakSet==`function`?WeakSet:Set,W=null;function bc(e,t){var n=e.ref;if(n!==null){if(typeof n==`function`)try{n(null)}catch(n){$(e,t,n)}else n.current=null}}function xc(e,t,n){try{n()}catch(n){$(e,t,n)}}var Sc=!1;function Cc(e,t){if(Pi=En,e=qr(),Jr(e)){if(`selectionStart`in e)var n={start:e.selectionStart,end:e.selectionEnd};else a:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var a=r.anchorOffset,o=r.focusNode;r=r.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break a}var s=0,c=-1,l=-1,u=0,d=0,f=e,p=null;b:for(;;){for(var m;f!==n||a!==0&&f.nodeType!==3||(c=s+a),f!==o||r!==0&&f.nodeType!==3||(l=s+r),f.nodeType===3&&(s+=f.nodeValue.length),(m=f.firstChild)!==null;)p=f,f=m;for(;;){if(f===e)break b;if(p===n&&++u===a&&(c=s),p===o&&++d===r&&(l=s),(m=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=m}n=c===-1||l===-1?null:{start:c,end:l}}else n=null}n||={start:0,end:0}}else n=null;for(Fi={focusedElem:e,selectionRange:n},En=!1,W=t;W!==null;)if(t=W,e=t.child,t.subtreeFlags&1028&&e!==null)e.return=t,W=e;else for(;W!==null;){t=W;try{var h=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(h!==null){var g=h.memoizedProps,_=h.memoizedState,v=t.stateNode;v.__reactInternalSnapshotBeforeUpdate=v.getSnapshotBeforeUpdate(t.elementType===t.type?g:Es(t.type,g),_)}break;case 3:var y=t.stateNode.containerInfo;y.nodeType===1?y.textContent=``:y.nodeType===9&&y.documentElement&&y.removeChild(y.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(i(163))}}catch(e){$(t,t.return,e)}if(e=t.sibling,e!==null){e.return=t.return,W=e;break}W=t.return}return h=Sc,Sc=!1,h}function wc(e,t,n){var r=t.updateQueue;if(r=r===null?null:r.lastEffect,r!==null){var i=r=r.next;do{if((i.tag&e)===e){var a=i.destroy;i.destroy=void 0,a!==void 0&&xc(t,n,a)}i=i.next}while(i!==r)}}function Tc(e,t){if(t=t.updateQueue,t=t===null?null:t.lastEffect,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function Ec(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t==`function`?t(e):t.current=e}}function Dc(e){var t=e.alternate;t!==null&&(e.alternate=null,Dc(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[Ki],delete t[qi],delete t[Yi],delete t[Xi],delete t[Zi])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function Oc(e){return e.tag===5||e.tag===3||e.tag===4}function kc(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||Oc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ac(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Ni));else if(r!==4&&(e=e.child,e!==null))for(Ac(e,t,n),e=e.sibling;e!==null;)Ac(e,t,n),e=e.sibling}function jc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(jc(e,t,n),e=e.sibling;e!==null;)jc(e,t,n),e=e.sibling}var G=null,Mc=!1;function Nc(e,t,n){for(n=n.child;n!==null;)Pc(e,t,n),n=n.sibling}function Pc(e,t,n){if(It&&typeof It.onCommitFiberUnmount==`function`)try{It.onCommitFiberUnmount(Ft,n)}catch{}switch(n.tag){case 5:U||bc(n,t);case 6:var r=G,i=Mc;G=null,Nc(e,t,n),G=r,Mc=i,G!==null&&(Mc?(e=G,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):G.removeChild(n.stateNode));break;case 18:G!==null&&(Mc?(e=G,n=n.stateNode,e.nodeType===8?Hi(e.parentNode,n):e.nodeType===1&&Hi(e,n),wn(e)):Hi(G,n.stateNode));break;case 4:r=G,i=Mc,G=n.stateNode.containerInfo,Mc=!0,Nc(e,t,n),G=r,Mc=i;break;case 0:case 11:case 14:case 15:if(!U&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){i=r=r.next;do{var a=i,o=a.destroy;a=a.tag,o!==void 0&&(a&2||a&4)&&xc(n,t,o),i=i.next}while(i!==r)}Nc(e,t,n);break;case 1:if(!U&&(bc(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(e){$(n,t,e)}Nc(e,t,n);break;case 21:Nc(e,t,n);break;case 22:n.mode&1?(U=(r=U)||n.memoizedState!==null,Nc(e,t,n),U=r):Nc(e,t,n);break;default:Nc(e,t,n)}}function Fc(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new yc),t.forEach(function(t){var r=Hl.bind(null,e,t);n.has(t)||(n.add(t),t.then(r,r))})}}function Ic(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var a=n[r];try{var o=e,s=t,c=s;a:for(;c!==null;){switch(c.tag){case 5:G=c.stateNode,Mc=!1;break a;case 3:G=c.stateNode.containerInfo,Mc=!0;break a;case 4:G=c.stateNode.containerInfo,Mc=!0;break a}c=c.return}if(G===null)throw Error(i(160));Pc(o,s,a),G=null,Mc=!1;var l=a.alternate;l!==null&&(l.return=null),a.return=null}catch(e){$(a,t,e)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)Lc(t,e),t=t.sibling}function Lc(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(Ic(t,e),Rc(e),r&4){try{wc(3,e,e.return),Tc(3,e)}catch(t){$(e,e.return,t)}try{wc(5,e,e.return)}catch(t){$(e,e.return,t)}}break;case 1:Ic(t,e),Rc(e),r&512&&n!==null&&bc(n,n.return);break;case 5:if(Ic(t,e),Rc(e),r&512&&n!==null&&bc(n,n.return),e.flags&32){var a=e.stateNode;try{He(a,``)}catch(t){$(e,e.return,t)}}if(r&4&&(a=e.stateNode,a!=null)){var o=e.memoizedProps,s=n===null?o:n.memoizedProps,c=e.type,l=e.updateQueue;if(e.updateQueue=null,l!==null)try{c===`input`&&o.type===`radio`&&o.name!=null&&Oe(a,o),Ye(c,s);var u=Ye(c,o);for(s=0;s<l.length;s+=2){var d=l[s],f=l[s+1];d===`style`?Ke(a,f):d===`dangerouslySetInnerHTML`?Ve(a,f):d===`children`?He(a,f):te(a,d,f,u)}switch(c){case`input`:ke(a,o);break;case`textarea`:Ie(a,o);break;case`select`:var p=a._wrapperState.wasMultiple;a._wrapperState.wasMultiple=!!o.multiple;var m=o.value;m==null?p!==!!o.multiple&&(o.defaultValue==null?Ne(a,!!o.multiple,o.multiple?[]:``,!1):Ne(a,!!o.multiple,o.defaultValue,!0)):Ne(a,!!o.multiple,m,!1)}a[qi]=o}catch(t){$(e,e.return,t)}}break;case 6:if(Ic(t,e),Rc(e),r&4){if(e.stateNode===null)throw Error(i(162));a=e.stateNode,o=e.memoizedProps;try{a.nodeValue=o}catch(t){$(e,e.return,t)}}break;case 3:if(Ic(t,e),Rc(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{wn(t.containerInfo)}catch(t){$(e,e.return,t)}break;case 4:Ic(t,e),Rc(e);break;case 13:Ic(t,e),Rc(e),a=e.child,a.flags&8192&&(o=a.memoizedState!==null,a.stateNode.isHidden=o,!o||a.alternate!==null&&a.alternate.memoizedState!==null||(nl=D())),r&4&&Fc(e);break;case 22:if(d=n!==null&&n.memoizedState!==null,e.mode&1?(U=(u=U)||d,Ic(t,e),U=u):Ic(t,e),Rc(e),r&8192){if(u=e.memoizedState!==null,(e.stateNode.isHidden=u)&&!d&&e.mode&1)for(W=e,d=e.child;d!==null;){for(f=W=d;W!==null;){switch(p=W,m=p.child,p.tag){case 0:case 11:case 14:case 15:wc(4,p,p.return);break;case 1:bc(p,p.return);var h=p.stateNode;if(typeof h.componentWillUnmount==`function`){r=p,n=p.return;try{t=r,h.props=t.memoizedProps,h.state=t.memoizedState,h.componentWillUnmount()}catch(e){$(r,n,e)}}break;case 5:bc(p,p.return);break;case 22:if(p.memoizedState!==null){Hc(f);continue}}m===null?Hc(f):(m.return=p,W=m)}d=d.sibling}a:for(d=null,f=e;;){if(f.tag===5){if(d===null){d=f;try{a=f.stateNode,u?(o=a.style,typeof o.setProperty==`function`?o.setProperty(`display`,`none`,`important`):o.display=`none`):(c=f.stateNode,l=f.memoizedProps.style,s=l!=null&&l.hasOwnProperty(`display`)?l.display:null,c.style.display=Ge(`display`,s))}catch(t){$(e,e.return,t)}}}else if(f.tag===6){if(d===null)try{f.stateNode.nodeValue=u?``:f.memoizedProps}catch(t){$(e,e.return,t)}}else if((f.tag!==22&&f.tag!==23||f.memoizedState===null||f===e)&&f.child!==null){f.child.return=f,f=f.child;continue}if(f===e)break a;for(;f.sibling===null;){if(f.return===null||f.return===e)break a;d===f&&(d=null),f=f.return}d===f&&(d=null),f.sibling.return=f.return,f=f.sibling}}break;case 19:Ic(t,e),Rc(e),r&4&&Fc(e);break;case 21:break;default:Ic(t,e),Rc(e)}}function Rc(e){var t=e.flags;if(t&2){try{a:{for(var n=e.return;n!==null;){if(Oc(n)){var r=n;break a}n=n.return}throw Error(i(160))}switch(r.tag){case 5:var a=r.stateNode;r.flags&32&&(He(a,``),r.flags&=-33),jc(e,kc(e),a);break;case 3:case 4:var o=r.stateNode.containerInfo;Ac(e,kc(e),o);break;default:throw Error(i(161))}}catch(t){$(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function zc(e,t,n){W=e,Bc(e,t,n)}function Bc(e,t,n){for(var r=!!(e.mode&1);W!==null;){var i=W,a=i.child;if(i.tag===22&&r){var o=i.memoizedState!==null||vc;if(!o){var s=i.alternate,c=s!==null&&s.memoizedState!==null||U;s=vc;var l=U;if(vc=o,(U=c)&&!l)for(W=i;W!==null;)o=W,c=o.child,o.tag===22&&o.memoizedState!==null||c===null?Uc(i):(c.return=o,W=c);for(;a!==null;)W=a,Bc(a,t,n),a=a.sibling;W=i,vc=s,U=l}Vc(e,t,n)}else i.subtreeFlags&8772&&a!==null?(a.return=i,W=a):Vc(e,t,n)}}function Vc(e){for(;W!==null;){var t=W;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:U||Tc(5,t);break;case 1:var r=t.stateNode;if(t.flags&4&&!U){if(n===null)r.componentDidMount();else{var a=t.elementType===t.type?n.memoizedProps:Es(t.type,n.memoizedProps);r.componentDidUpdate(a,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}}var o=t.updateQueue;o!==null&&yo(t,o,r);break;case 3:var s=t.updateQueue;if(s!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}yo(t,s,n)}break;case 5:var c=t.stateNode;if(n===null&&t.flags&4){n=c;var l=t.memoizedProps;switch(t.type){case`button`:case`input`:case`select`:case`textarea`:l.autoFocus&&n.focus();break;case`img`:l.src&&(n.src=l.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var u=t.alternate;if(u!==null){var d=u.memoizedState;if(d!==null){var f=d.dehydrated;f!==null&&wn(f)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(i(163))}U||t.flags&512&&Ec(t)}catch(e){$(t,t.return,e)}}if(t===e){W=null;break}if(n=t.sibling,n!==null){n.return=t.return,W=n;break}W=t.return}}function Hc(e){for(;W!==null;){var t=W;if(t===e){W=null;break}var n=t.sibling;if(n!==null){n.return=t.return,W=n;break}W=t.return}}function Uc(e){for(;W!==null;){var t=W;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{Tc(4,t)}catch(e){$(t,n,e)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount==`function`){var i=t.return;try{r.componentDidMount()}catch(e){$(t,i,e)}}var a=t.return;try{Ec(t)}catch(e){$(t,a,e)}break;case 5:var o=t.return;try{Ec(t)}catch(e){$(t,o,e)}}}catch(e){$(t,t.return,e)}if(t===e){W=null;break}var s=t.sibling;if(s!==null){s.return=t.return,W=s;break}W=t.return}}var Wc=Math.ceil,Gc=x.ReactCurrentDispatcher,Kc=x.ReactCurrentOwner,qc=x.ReactCurrentBatchConfig,K=0,q=null,J=null,Y=0,Jc=0,Yc=ia(0),X=0,Xc=null,Zc=0,Qc=0,$c=0,el=null,tl=null,nl=0,rl=1/0,il=null,al=!1,ol=null,sl=null,cl=!1,ll=null,ul=0,dl=0,fl=null,pl=-1,ml=0;function Z(){return K&6?D():pl===-1?pl=D():pl}function hl(e){return e.mode&1?K&2&&Y!==0?Y&-Y:Wa.transition===null?(e=O,e===0&&(e=window.event,e=e===void 0?16:Mn(e.type)),e):(ml===0&&(ml=Yt()),ml):1}function gl(e,t,n,r){if(50<dl)throw dl=0,fl=null,Error(i(185));Zt(e,n,r),K&2&&e===q||(e===q&&(!(K&2)&&(Qc|=n),X===4&&xl(e,Y)),Q(e,r),n===1&&K===0&&!(t.mode&1)&&(rl=D()+500,ma&&va()))}function Q(e,t){var n=e.callbackNode;qt(e,t);var r=Gt(e,e===q?Y:0);if(r===0)n!==null&&Et(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&Et(n),t===1)e.tag===0?_a(Sl.bind(null,e)):ga(Sl.bind(null,e)),Bi(function(){!(K&6)&&va()}),n=null;else{switch(en(r)){case 1:n=At;break;case 4:n=jt;break;case 16:n=Mt;break;case 536870912:n=Pt;break;default:n=Mt}n=Wl(n,_l.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function _l(e,t){if(pl=-1,ml=0,K&6)throw Error(i(327));var n=e.callbackNode;if(Ll()&&e.callbackNode!==n)return null;var r=Gt(e,e===q?Y:0);if(r===0)return null;if(r&30||(r&e.expiredLanes)!==0||t)t=Al(e,r);else{t=r;var a=K;K|=2;var o=Ol();(q!==e||Y!==t)&&(il=null,rl=D()+500,El(e,t));do try{Ml();break}catch(t){Dl(e,t)}while(1);to(),Gc.current=o,K=a,J===null?(q=null,Y=0,t=X):t=0}if(t!==0){if(t===2&&(a=Jt(e),a!==0&&(r=a,t=vl(e,a))),t===1)throw n=Xc,El(e,0),xl(e,r),Q(e,D()),n;if(t===6)xl(e,r);else{if(a=e.current.alternate,!(r&30)&&!bl(a)&&(t=Al(e,r),t===2&&(o=Jt(e),o!==0&&(r=o,t=vl(e,o))),t===1))throw n=Xc,El(e,0),xl(e,r),Q(e,D()),n;switch(e.finishedWork=a,e.finishedLanes=r,t){case 0:case 1:throw Error(i(345));case 2:Fl(e,tl,il);break;case 3:if(xl(e,r),(r&130023424)===r&&(t=nl+500-D(),10<t)){if(Gt(e,0)!==0)break;if(a=e.suspendedLanes,(a&r)!==r){Z(),e.pingedLanes|=e.suspendedLanes&a;break}e.timeoutHandle=Li(Fl.bind(null,e,tl,il),t);break}Fl(e,tl,il);break;case 4:if(xl(e,r),(r&4194240)===r)break;for(t=e.eventTimes,a=-1;0<r;){var s=31-Rt(r);o=1<<s,s=t[s],s>a&&(a=s),r&=~o}if(r=a,r=D()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*Wc(r/1960))-r,10<r){e.timeoutHandle=Li(Fl.bind(null,e,tl,il),r);break}Fl(e,tl,il);break;case 5:Fl(e,tl,il);break;default:throw Error(i(329))}}}return Q(e,D()),e.callbackNode===n?_l.bind(null,e):null}function vl(e,t){var n=el;return e.current.memoizedState.isDehydrated&&(El(e,t).flags|=256),e=Al(e,t),e!==2&&(t=tl,tl=n,t!==null&&yl(t)),e}function yl(e){tl===null?tl=e:tl.push.apply(tl,e)}function bl(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!Hr(a(),i))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function xl(e,t){for(t&=~$c,t&=~Qc,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-Rt(t),r=1<<n;e[n]=-1,t&=~r}}function Sl(e){if(K&6)throw Error(i(327));Ll();var t=Gt(e,0);if(!(t&1))return Q(e,D()),null;var n=Al(e,t);if(e.tag!==0&&n===2){var r=Jt(e);r!==0&&(t=r,n=vl(e,r))}if(n===1)throw n=Xc,El(e,0),xl(e,t),Q(e,D()),n;if(n===6)throw Error(i(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,Fl(e,tl,il),Q(e,D()),null}function Cl(e,t){var n=K;K|=1;try{return e(t)}finally{K=n,K===0&&(rl=D()+500,ma&&va())}}function wl(e){ll!==null&&ll.tag===0&&!(K&6)&&Ll();var t=K;K|=1;var n=qc.transition,r=O;try{if(qc.transition=null,O=1,e)return e()}finally{O=r,qc.transition=n,K=t,!(K&6)&&va()}}function Tl(){Jc=Yc.current,A(Yc)}function El(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,Ri(n)),J!==null)for(n=J.return;n!==null;){var r=n;switch(ja(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&ca();break;case 3:Eo(),A(N),A(M),jo();break;case 5:Oo(r);break;case 4:Eo();break;case 13:A(I);break;case 19:A(I);break;case 10:no(r.type._context);break;case 22:case 23:Tl()}n=n.return}if(q=e,J=e=Yl(e.current,null),Y=Jc=t,X=0,Xc=null,$c=Qc=Zc=0,tl=el=null,oo!==null){for(t=0;t<oo.length;t++)if(n=oo[t],r=n.interleaved,r!==null){n.interleaved=null;var i=r.next,a=n.pending;if(a!==null){var o=a.next;a.next=i,r.next=o}n.pending=r}oo=null}return e}function Dl(e,t){do{var n=J;try{if(to(),Mo.current=Ss,Fo){for(var r=L.memoizedState;r!==null;){var a=r.queue;a!==null&&(a.pending=null),r=r.next}Fo=!1}if(Po=0,z=R=L=null,Io=!1,Lo=0,Kc.current=null,n===null||n.return===null){X=1,Xc=t,J=null;break}a:{var o=e,s=n.return,c=n,l=t;if(t=Y,c.flags|=32768,typeof l==`object`&&l&&typeof l.then==`function`){var u=l,d=c,f=d.tag;if(!(d.mode&1)&&(f===0||f===11||f===15)){var p=d.alternate;p?(d.updateQueue=p.updateQueue,d.memoizedState=p.memoizedState,d.lanes=p.lanes):(d.updateQueue=null,d.memoizedState=null)}var m=Bs(s);if(m!==null){m.flags&=-257,Vs(m,s,c,o,t),m.mode&1&&zs(o,u,t),t=m,l=u;var h=t.updateQueue;if(h===null){var g=new Set;g.add(l),t.updateQueue=g}else h.add(l);break a}if(!(t&1)){zs(o,u,t),kl();break a}l=Error(i(426))}else if(F&&c.mode&1){var _=Bs(s);if(_!==null){!(_.flags&65536)&&(_.flags|=256),Vs(_,s,c,o,t),Ua(Ns(l,c));break a}}o=l=Ns(l,c),X!==4&&(X=2),el===null?el=[o]:el.push(o),o=s;do{switch(o.tag){case 3:o.flags|=65536,t&=-t,o.lanes|=t;var v=Ls(o,l,t);_o(o,v);break a;case 1:c=l;var y=o.type,b=o.stateNode;if(!(o.flags&128)&&(typeof y.getDerivedStateFromError==`function`||b!==null&&typeof b.componentDidCatch==`function`&&(sl===null||!sl.has(b)))){o.flags|=65536,t&=-t,o.lanes|=t;var ee=Rs(o,c,t);_o(o,ee);break a}}o=o.return}while(o!==null)}Pl(n)}catch(e){t=e,J===n&&n!==null&&(J=n=n.return);continue}break}while(1)}function Ol(){var e=Gc.current;return Gc.current=Ss,e===null?Ss:e}function kl(){(X===0||X===3||X===2)&&(X=4),q===null||!(Zc&268435455)&&!(Qc&268435455)||xl(q,Y)}function Al(e,t){var n=K;K|=2;var r=Ol();(q!==e||Y!==t)&&(il=null,El(e,t));do try{jl();break}catch(t){Dl(e,t)}while(1);if(to(),K=n,Gc.current=r,J!==null)throw Error(i(261));return q=null,Y=0,X}function jl(){for(;J!==null;)Nl(J)}function Ml(){for(;J!==null&&!Dt();)Nl(J)}function Nl(e){var t=Ul(e.alternate,e,Jc);e.memoizedProps=e.pendingProps,t===null?Pl(e):J=t,Kc.current=null}function Pl(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=_c(n,t),n!==null){n.flags&=32767,J=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{X=6,J=null;return}}else if(n=gc(n,t,Jc),n!==null){J=n;return}if(t=t.sibling,t!==null){J=t;return}J=t=e}while(t!==null);X===0&&(X=5)}function Fl(e,t,n){var r=O,i=qc.transition;try{qc.transition=null,O=1,Il(e,t,n,r)}finally{qc.transition=i,O=r}return null}function Il(e,t,n,r){do Ll();while(ll!==null);if(K&6)throw Error(i(327));n=e.finishedWork;var a=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(i(177));e.callbackNode=null,e.callbackPriority=0;var o=n.lanes|n.childLanes;if(Qt(e,o),e===q&&(J=q=null,Y=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||cl||(cl=!0,Wl(Mt,function(){return Ll(),null})),o=!!(n.flags&15990),n.subtreeFlags&15990||o){o=qc.transition,qc.transition=null;var s=O;O=1;var c=K;K|=4,Kc.current=null,Cc(e,n),Lc(n,e),Yr(Fi),En=!!Pi,Fi=Pi=null,e.current=n,zc(n,e,a),Ot(),K=c,O=s,qc.transition=o}else e.current=n;if(cl&&(cl=!1,ll=e,ul=a),o=e.pendingLanes,o===0&&(sl=null),Lt(n.stateNode,r),Q(e,D()),t!==null)for(r=e.onRecoverableError,n=0;n<t.length;n++)a=t[n],r(a.value,{componentStack:a.stack,digest:a.digest});if(al)throw al=!1,e=ol,ol=null,e;return ul&1&&e.tag!==0&&Ll(),o=e.pendingLanes,o&1?e===fl?dl++:(dl=0,fl=e):dl=0,va(),null}function Ll(){if(ll!==null){var e=en(ul),t=qc.transition,n=O;try{if(qc.transition=null,O=16>e?16:e,ll===null)var r=!1;else{if(e=ll,ll=null,ul=0,K&6)throw Error(i(331));var a=K;for(K|=4,W=e.current;W!==null;){var o=W,s=o.child;if(W.flags&16){var c=o.deletions;if(c!==null){for(var l=0;l<c.length;l++){var u=c[l];for(W=u;W!==null;){var d=W;switch(d.tag){case 0:case 11:case 15:wc(8,d,o)}var f=d.child;if(f!==null)f.return=d,W=f;else for(;W!==null;){d=W;var p=d.sibling,m=d.return;if(Dc(d),d===u){W=null;break}if(p!==null){p.return=m,W=p;break}W=m}}}var h=o.alternate;if(h!==null){var g=h.child;if(g!==null){h.child=null;do{var _=g.sibling;g.sibling=null,g=_}while(g!==null)}}W=o}}if(o.subtreeFlags&2064&&s!==null)s.return=o,W=s;else b:for(;W!==null;){if(o=W,o.flags&2048)switch(o.tag){case 0:case 11:case 15:wc(9,o,o.return)}var v=o.sibling;if(v!==null){v.return=o.return,W=v;break b}W=o.return}}var y=e.current;for(W=y;W!==null;){s=W;var b=s.child;if(s.subtreeFlags&2064&&b!==null)b.return=s,W=b;else b:for(s=y;W!==null;){if(c=W,c.flags&2048)try{switch(c.tag){case 0:case 11:case 15:Tc(9,c)}}catch(e){$(c,c.return,e)}if(c===s){W=null;break b}var ee=c.sibling;if(ee!==null){ee.return=c.return,W=ee;break b}W=c.return}}if(K=a,va(),It&&typeof It.onPostCommitFiberRoot==`function`)try{It.onPostCommitFiberRoot(Ft,e)}catch{}r=!0}return r}finally{O=n,qc.transition=t}}return!1}function Rl(e,t,n){t=Ns(n,t),t=Ls(e,t,1),e=ho(e,t,1),t=Z(),e!==null&&(Zt(e,1,t),Q(e,t))}function $(e,t,n){if(e.tag===3)Rl(e,e,n);else for(;t!==null;){if(t.tag===3){Rl(t,e,n);break}if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(sl===null||!sl.has(r))){e=Ns(n,e),e=Rs(t,e,1),t=ho(t,e,1),e=Z(),t!==null&&(Zt(t,1,e),Q(t,e));break}}t=t.return}}function zl(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=Z(),e.pingedLanes|=e.suspendedLanes&n,q===e&&(Y&n)===n&&(X===4||X===3&&(Y&130023424)===Y&&500>D()-nl?El(e,0):$c|=n),Q(e,t)}function Bl(e,t){t===0&&(e.mode&1?(t=Ut,Ut<<=1,!(Ut&130023424)&&(Ut=4194304)):t=1);var n=Z();e=lo(e,t),e!==null&&(Zt(e,t,n),Q(e,n))}function Vl(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Bl(e,n)}function Hl(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:r=e.stateNode;break;default:throw Error(i(314))}r!==null&&r.delete(t),Bl(e,n)}var Ul=function(e,t,n){if(e!==null){if(e.memoizedProps!==t.pendingProps||N.current)Us=!0;else{if((e.lanes&n)===0&&!(t.flags&128))return Us=!1,dc(e,t,n);Us=!!(e.flags&131072)}}else Us=!1,F&&t.flags&1048576&&ka(t,Sa,t.index);switch(t.lanes=0,t.tag){case 2:var r=t.type;lc(e,t),e=t.pendingProps;var a=sa(t,M.current);io(t,n),a=Bo(null,t,r,e,a,n);var o=Vo();return t.flags|=1,typeof a==`object`&&a&&typeof a.render==`function`&&a.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,P(r)?(o=!0,da(t)):o=!1,t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,fo(t),a.updater=Os,t.stateNode=a,a._reactInternals=t,Ms(t,r,e,n),t=Zs(null,t,r,!0,o,n)):(t.tag=0,F&&o&&Aa(t),V(null,t,a,n),t=t.child),t;case 16:r=t.elementType;a:{switch(lc(e,t),e=t.pendingProps,a=r._init,r=a(r._payload),t.type=r,a=t.tag=Jl(r),e=Es(r,e),a){case 0:t=Ys(null,t,r,e,n);break a;case 1:t=Xs(null,t,r,e,n);break a;case 11:t=Ws(null,t,r,e,n);break a;case 14:t=Gs(null,t,r,Es(r.type,e),n);break a}throw Error(i(306,r,``))}return t;case 0:return r=t.type,a=t.pendingProps,a=t.elementType===r?a:Es(r,a),Ys(e,t,r,a,n);case 1:return r=t.type,a=t.pendingProps,a=t.elementType===r?a:Es(r,a),Xs(e,t,r,a,n);case 3:a:{if(Qs(t),e===null)throw Error(i(387));r=t.pendingProps,o=t.memoizedState,a=o.element,po(e,t),vo(t,r,null,n);var s=t.memoizedState;if(r=s.element,o.isDehydrated){if(o={element:r,isDehydrated:!1,cache:s.cache,pendingSuspenseBoundaries:s.pendingSuspenseBoundaries,transitions:s.transitions},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){a=Ns(Error(i(423)),t),t=$s(e,t,r,n,a);break a}if(r!==a){a=Ns(Error(i(424)),t),t=$s(e,t,r,n,a);break a}for(Na=Ui(t.stateNode.containerInfo.firstChild),Ma=t,F=!0,Pa=null,n=Xa(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling}else{if(Ha(),r===a){t=uc(e,t,n);break a}V(e,t,r,n)}t=t.child}return t;case 5:return Do(t),e===null&&Ra(t),r=t.type,a=t.pendingProps,o=e===null?null:e.memoizedProps,s=a.children,Ii(r,a)?s=null:o!==null&&Ii(r,o)&&(t.flags|=32),Js(e,t),V(e,t,s,n),t.child;case 6:return e===null&&Ra(t),null;case 13:return nc(e,t,n);case 4:return To(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=Ya(t,null,r,n):V(e,t,r,n),t.child;case 11:return r=t.type,a=t.pendingProps,a=t.elementType===r?a:Es(r,a),Ws(e,t,r,a,n);case 7:return V(e,t,t.pendingProps,n),t.child;case 8:return V(e,t,t.pendingProps.children,n),t.child;case 12:return V(e,t,t.pendingProps.children,n),t.child;case 10:a:{if(r=t.type._context,a=t.pendingProps,o=t.memoizedProps,s=a.value,j(Za,r._currentValue),r._currentValue=s,o!==null){if(Hr(o.value,s)){if(o.children===a.children&&!N.current){t=uc(e,t,n);break a}}else for(o=t.child,o!==null&&(o.return=t);o!==null;){var c=o.dependencies;if(c!==null){s=o.child;for(var l=c.firstContext;l!==null;){if(l.context===r){if(o.tag===1){l=mo(-1,n&-n),l.tag=2;var u=o.updateQueue;if(u!==null){u=u.shared;var d=u.pending;d===null?l.next=l:(l.next=d.next,d.next=l),u.pending=l}}o.lanes|=n,l=o.alternate,l!==null&&(l.lanes|=n),ro(o.return,n,t),c.lanes|=n;break}l=l.next}}else if(o.tag===10)s=o.type===t.type?null:o.child;else if(o.tag===18){if(s=o.return,s===null)throw Error(i(341));s.lanes|=n,c=s.alternate,c!==null&&(c.lanes|=n),ro(s,n,t),s=o.sibling}else s=o.child;if(s!==null)s.return=o;else for(s=o;s!==null;){if(s===t){s=null;break}if(o=s.sibling,o!==null){o.return=s.return,s=o;break}s=s.return}o=s}}V(e,t,a.children,n),t=t.child}return t;case 9:return a=t.type,r=t.pendingProps.children,io(t,n),a=ao(a),r=r(a),t.flags|=1,V(e,t,r,n),t.child;case 14:return r=t.type,a=Es(r,t.pendingProps),a=Es(r.type,a),Gs(e,t,r,a,n);case 15:return Ks(e,t,t.type,t.pendingProps,n);case 17:return r=t.type,a=t.pendingProps,a=t.elementType===r?a:Es(r,a),lc(e,t),t.tag=1,P(r)?(e=!0,da(t)):e=!1,io(t,n),As(t,r,a),Ms(t,r,a,n),Zs(null,t,r,!0,e,n);case 19:return cc(e,t,n);case 22:return qs(e,t,n)}throw Error(i(156,t.tag))};function Wl(e,t){return Tt(e,t)}function Gl(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Kl(e,t,n,r){return new Gl(e,t,n,r)}function ql(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Jl(e){if(typeof e==`function`)return+!!ql(e);if(e!=null){if(e=e.$$typeof,e===ce)return 11;if(e===w)return 14}return 2}function Yl(e,t){var n=e.alternate;return n===null?(n=Kl(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function Xl(e,t,n,r,a,o){var s=2;if(r=e,typeof e==`function`)ql(e)&&(s=1);else if(typeof e==`string`)s=5;else a:switch(e){case ie:return Zl(n.children,a,o,t);case ae:s=8,a|=8;break;case oe:return e=Kl(12,n,t,a|2),e.elementType=oe,e.lanes=o,e;case C:return e=Kl(13,n,t,a),e.elementType=C,e.lanes=o,e;case le:return e=Kl(19,n,t,a),e.elementType=le,e.lanes=o,e;case de:return Ql(n,a,o,t);default:if(typeof e==`object`&&e)switch(e.$$typeof){case S:s=10;break a;case se:s=9;break a;case ce:s=11;break a;case w:s=14;break a;case ue:s=16,r=null;break a}throw Error(i(130,e==null?e:typeof e,``))}return t=Kl(s,n,t,a),t.elementType=e,t.type=r,t.lanes=o,t}function Zl(e,t,n,r){return e=Kl(7,e,r,t),e.lanes=n,e}function Ql(e,t,n,r){return e=Kl(22,e,r,t),e.elementType=de,e.lanes=n,e.stateNode={isHidden:!1},e}function $l(e,t,n){return e=Kl(6,e,null,t),e.lanes=n,e}function eu(e,t,n){return t=Kl(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function tu(e,t,n,r,i){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Xt(0),this.expirationTimes=Xt(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Xt(0),this.identifierPrefix=r,this.onRecoverableError=i,this.mutableSourceEagerHydrationData=null}function nu(e,t,n,r,i,a,o,s,c){return e=new tu(e,t,n,s,c),t===1?(t=1,!0===a&&(t|=8)):t=0,a=Kl(3,null,null,t),e.current=a,a.stateNode=e,a.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},fo(a),e}function ru(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:re,key:r==null?null:``+r,children:e,containerInfo:t,implementation:n}}function iu(e){if(!e)return aa;e=e._reactInternals;a:{if(yt(e)!==e||e.tag!==1)throw Error(i(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break a;case 1:if(P(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break a}}t=t.return}while(t!==null);throw Error(i(171))}if(e.tag===1){var n=e.type;if(P(n))return ua(e,n,t)}return t}function au(e,t,n,r,i,a,o,s,c){return e=nu(n,r,!0,e,i,a,o,s,c),e.context=iu(null),n=e.current,r=Z(),i=hl(n),a=mo(r,i),a.callback=t??null,ho(n,a,i),e.current.lanes=i,Zt(e,i,r),Q(e,r),e}function ou(e,t,n,r){var i=t.current,a=Z(),o=hl(i);return n=iu(n),t.context===null?t.context=n:t.pendingContext=n,t=mo(a,o),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=ho(i,t,o),e!==null&&(gl(e,i,o,a),go(e,i,o)),o}function su(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function cu(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function lu(e,t){cu(e,t),(e=e.alternate)&&cu(e,t)}function uu(){return null}var du=typeof reportError==`function`?reportError:function(e){console.error(e)};function fu(e){this._internalRoot=e}pu.prototype.render=fu.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(i(409));ou(e,t,null,null)},pu.prototype.unmount=fu.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;wl(function(){ou(null,e,null,null)}),t[Ji]=null}};function pu(e){this._internalRoot=e}pu.prototype.unstable_scheduleHydration=function(e){if(e){var t=an();e={blockedOn:null,target:e,priority:t};for(var n=0;n<mn.length&&t!==0&&t<mn[n].priority;n++);mn.splice(n,0,e),n===0&&yn(e)}};function mu(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function hu(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==` react-mount-point-unstable `))}function gu(){}function _u(e,t,n,r,i){if(i){if(typeof r==`function`){var a=r;r=function(){var e=su(o);a.call(e)}}var o=au(t,r,e,0,null,!1,!1,``,gu);return e._reactRootContainer=o,e[Ji]=o.current,Si(e.nodeType===8?e.parentNode:e),wl(),o}for(;i=e.lastChild;)e.removeChild(i);if(typeof r==`function`){var s=r;r=function(){var e=su(c);s.call(e)}}var c=nu(e,0,!1,null,null,!1,!1,``,gu);return e._reactRootContainer=c,e[Ji]=c.current,Si(e.nodeType===8?e.parentNode:e),wl(function(){ou(t,c,n,r)}),c}function vu(e,t,n,r,i){var a=n._reactRootContainer;if(a){var o=a;if(typeof i==`function`){var s=i;i=function(){var e=su(o);s.call(e)}}ou(t,o,e,i)}else o=_u(n,t,e,i,r);return su(o)}tn=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=Wt(t.pendingLanes);n!==0&&($t(t,n|1),Q(t,D()),!(K&6)&&(rl=D()+500,va()))}break;case 13:wl(function(){var t=lo(e,1);t!==null&&gl(t,e,1,Z())}),lu(e,1)}},nn=function(e){if(e.tag===13){var t=lo(e,134217728);t!==null&&gl(t,e,134217728,Z()),lu(e,134217728)}},rn=function(e){if(e.tag===13){var t=hl(e),n=lo(e,t);n!==null&&gl(n,e,t,Z()),lu(e,t)}},an=function(){return O},on=function(e,t){var n=O;try{return O=e,t()}finally{O=n}},Qe=function(e,t,n){switch(t){case`input`:if(ke(e,n),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll(`input[name=`+JSON.stringify(``+t)+`][type="radio"]`),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var a=ta(r);if(!a)throw Error(i(90));we(r),ke(r,a)}}}break;case`textarea`:Ie(e,n);break;case`select`:t=n.value,t!=null&&Ne(e,!!n.multiple,t,!1)}},it=Cl,at=wl;var yu={usingClientEntryPoint:!1,Events:[$i,ea,ta,nt,rt,Cl]},bu={findFiberByHostInstance:Qi,bundleType:0,version:`18.3.1`,rendererPackageName:`react-dom`},xu={bundleType:bu.bundleType,version:bu.version,rendererPackageName:bu.rendererPackageName,rendererConfig:bu.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:x.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=Ct(e),e===null?null:e.stateNode},findFiberByHostInstance:bu.findFiberByHostInstance||uu,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:`18.3.1-next-f1338f8080-20240426`};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`){var Su=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Su.isDisabled&&Su.supportsFiber)try{Ft=Su.inject(xu),It=Su}catch{}}e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=yu,e.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!mu(t))throw Error(i(200));return ru(e,t,null,n)},e.createRoot=function(e,t){if(!mu(e))throw Error(i(299));var n=!1,r=``,a=du;return t!=null&&(!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onRecoverableError!==void 0&&(a=t.onRecoverableError)),t=nu(e,1,!1,null,null,n,!1,r,a),e[Ji]=t.current,Si(e.nodeType===8?e.parentNode:e),new fu(t)},e.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(i(188)):(e=Object.keys(e).join(`,`),Error(i(268,e)));return e=Ct(t),e=e===null?null:e.stateNode,e},e.flushSync=function(e){return wl(e)},e.hydrate=function(e,t,n){if(!hu(t))throw Error(i(200));return vu(null,e,t,!0,n)},e.hydrateRoot=function(e,t,n){if(!mu(e))throw Error(i(405));var r=n!=null&&n.hydratedSources||null,a=!1,o=``,s=du;if(n!=null&&(!0===n.unstable_strictMode&&(a=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onRecoverableError!==void 0&&(s=n.onRecoverableError)),t=au(t,null,e,1,n??null,a,!1,o,s),e[Ji]=t.current,Si(e),r)for(e=0;e<r.length;e++)n=r[e],a=n._getVersion,a=a(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,a]:t.mutableSourceEagerHydrationData.push(n,a);return new pu(t)},e.render=function(e,t,n){if(!hu(t))throw Error(i(200));return vu(null,e,t,!1,n)},e.unmountComponentAtNode=function(e){if(!hu(e))throw Error(i(40));return e._reactRootContainer?(wl(function(){vu(null,null,e,!1,function(){e._reactRootContainer=null,e[Ji]=null})}),!0):!1},e.unstable_batchedUpdates=Cl,e.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!hu(n))throw Error(i(200));if(e==null||e._reactInternals===void 0)throw Error(i(38));return vu(e,t,n,!1,r)},e.version=`18.3.1-next-f1338f8080-20240426`})),s=e(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=o()})),c=e((e=>{var t=s();e.createRoot=t.createRoot,e.hydrateRoot=t.hydrateRoot})),l=r(),u=c(),d={sessions:`sessions`,progress:e=>`progress:${e}`,lastSessionId:`lastSessionId`,windowBounds:`windowBounds`,installationId:`installationId`,license:`licenseRecord`,sessionNames:`sessionNames`,sessionPreviews:`sessionPreviews`,sessionAvatar:e=>`sessionAvatar:${e}`,readingPreferences:`readingPreferences`,profileAvatar:`profileAvatar`,profileName:`profileName`,homeWindowId:`homeWindowId`,homeWindowRestoreState:`homeWindowRestoreState`,settingsTabId:`settingsTabId`};async function f(){return(await chrome.storage.local.get(d.sessions))[d.sessions]??[]}var p;async function m(){p??=h();try{return await p}finally{p=void 0}}async function h(){let e=(await chrome.storage.local.get(d.installationId))[d.installationId];if(typeof e==`string`&&e.length>0)return e;let t=crypto.randomUUID();return await chrome.storage.local.set({[d.installationId]:t}),t}async function g(){return(await chrome.storage.local.get(d.license))[d.license]}async function _(e){await chrome.storage.local.set({[d.license]:e})}async function v(){return(await chrome.storage.local.get(d.sessionNames))[d.sessionNames]??{}}async function y(){return(await chrome.storage.local.get(d.sessionPreviews))[d.sessionPreviews]??{}}async function b(e,t){let n=t.trim();if(!n||n.length>200)throw Error(`会话记录须为 1–200 个字符`);let r=await y();await chrome.storage.local.set({[d.sessionPreviews]:{...r,[e]:n}})}async function ee(){return(await chrome.storage.local.get(d.readingPreferences))[d.readingPreferences]??{fontSize:14}}async function te(){let e=(await chrome.storage.local.get(d.profileAvatar))[d.profileAvatar];return typeof e==`string`?e:void 0}async function x(e){if(e.length===0)return{};let t=await chrome.storage.local.get(e.map(d.sessionAvatar));return Object.fromEntries(e.flatMap(e=>{let n=t[d.sessionAvatar(e)];return typeof n==`string`?[[e,n]]:[]}))}var ne=`本地用户`;async function re(){let e=(await chrome.storage.local.get(d.profileName))[d.profileName];return typeof e==`string`&&e.trim()?e.trim().slice(0,24):ne}var ie=`profile-avatar-default.png`;function ae(e){return typeof e==`string`&&e.length<=2e5&&/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(e)}var oe=e((e=>{var t=r(),n=Symbol.for(`react.element`),i=Object.prototype.hasOwnProperty,a=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,o={key:!0,ref:!0,__self:!0,__source:!0};function s(e,t,r){var s,c={},l=null,u=null;for(s in r!==void 0&&(l=``+r),t.key!==void 0&&(l=``+t.key),t.ref!==void 0&&(u=t.ref),t)i.call(t,s)&&!o.hasOwnProperty(s)&&(c[s]=t[s]);if(e&&e.defaultProps)for(s in t=e.defaultProps,t)c[s]===void 0&&(c[s]=t[s]);return{$$typeof:n,type:e,key:l,ref:u,props:c,_owner:a.current}}e.jsx=s,e.jsxs=s})),S=e(((e,t)=>{t.exports=oe()}))();function se({recipient:e=`会话`,disabled:t,onSend:n}){let r=(0,l.useId)(),[i,a]=(0,l.useState)(``),[o,s]=(0,l.useState)(!1),c=(0,l.useRef)(null),u=t??!n,d=!!n&&!u&&!!i.trim();(0,l.useEffect)(()=>{let e=c.current;if(!e)return;e.style.height=`auto`;let t=e.closest(`.conversation-composer`)?.getBoundingClientRect().height??0,n=t>0?34/98*t:34,r=t>0?t*(o?1:66/98):o?98:66;e.style.height=`${Math.max(n,Math.min(e.scrollHeight||n,r))}px`,e.style.overflowY=e.scrollHeight>r?`auto`:`hidden`},[i,o]);let f=()=>{let e=i.trim();e&&!u&&n&&(n(e),a(``))};return(0,S.jsx)(`form`,{className:`conversation-composer${o?` is-expanded`:``}`,"aria-label":`消息输入`,onSubmit:e=>{e.preventDefault(),f()},children:(0,S.jsxs)(`div`,{className:`composer-input-row`,children:[(0,S.jsxs)(`div`,{className:`composer-entry${i?` has-draft`:``}`,onClick:()=>{u||c.current?.focus()},children:[(0,S.jsx)(`textarea`,{id:r,ref:c,className:`composer-field`,"aria-label":`消息输入框`,autoComplete:`off`,disabled:u,rows:1,value:i,onChange:e=>a(e.target.value),onInput:e=>a(e.currentTarget.value),onKeyDown:e=>{e.stopPropagation(),e.key!==`Enter`||e.shiftKey||e.nativeEvent.isComposing||(e.preventDefault(),f())}}),!i&&(0,S.jsxs)(`div`,{className:`composer-placeholder`,"aria-hidden":`true`,children:[(0,S.jsx)(`label`,{className:`composer-voice-hint`,htmlFor:r,children:`按住 右 Alt 说话`}),(0,S.jsx)(`label`,{className:`composer-recipient-placeholder`,htmlFor:r,children:u?`选择一个会话开始阅读`:`发送给 ${e}`})]})]}),(0,S.jsxs)(`div`,{className:`composer-tools`,children:[(0,S.jsx)(`span`,{className:`composer-format`,"aria-hidden":`true`,children:`Aa`}),(0,S.jsx)(`span`,{className:`composer-tool-decoration composer-tool-optional`,"aria-hidden":`true`,children:(0,S.jsxs)(`svg`,{className:`composer-icon`,viewBox:`0 0 24 24`,children:[(0,S.jsx)(`circle`,{cx:`12`,cy:`12`,r:`9`}),(0,S.jsx)(`circle`,{cx:`9`,cy:`10`,r:`1`,fill:`currentColor`,stroke:`none`}),(0,S.jsx)(`circle`,{cx:`15`,cy:`10`,r:`1`,fill:`currentColor`,stroke:`none`}),(0,S.jsx)(`path`,{d:`M8 15q4 4 8 0`})]})}),(0,S.jsx)(`span`,{className:`composer-mention composer-tool-optional`,"aria-hidden":`true`,children:`@`}),(0,S.jsxs)(`span`,{className:`composer-clip composer-tool-optional`,"aria-hidden":`true`,children:[(0,S.jsxs)(`svg`,{className:`composer-icon`,viewBox:`0 0 24 24`,children:[(0,S.jsx)(`circle`,{cx:`5`,cy:`18`,r:`2.5`}),(0,S.jsx)(`circle`,{cx:`18`,cy:`18`,r:`2.5`}),(0,S.jsx)(`path`,{d:`M7 16 18 4M16 16 6 4`})]}),(0,S.jsx)(`svg`,{className:`composer-caret`,viewBox:`0 0 12 12`,children:(0,S.jsx)(`path`,{d:`m3 4 3 3 3-3`})})]}),(0,S.jsx)(`span`,{className:`composer-tool-decoration`,"aria-hidden":`true`,children:(0,S.jsxs)(`svg`,{className:`composer-icon`,viewBox:`0 0 24 24`,children:[(0,S.jsx)(`circle`,{cx:`12`,cy:`12`,r:`9`}),(0,S.jsx)(`path`,{d:`M12 7v10M7 12h10`})]})}),(0,S.jsx)(`button`,{type:`button`,className:`composer-tool-button composer-expand-button composer-tool-optional`,"aria-label":o?`收起输入框`:`展开输入框`,"aria-expanded":o,onClick:()=>s(e=>!e),children:(0,S.jsx)(`svg`,{className:`composer-icon`,viewBox:`0 0 24 24`,"aria-hidden":`true`,children:(0,S.jsx)(`path`,{d:`M8 3H3v5m0-5 7 7m6 11h5v-5m0 5-7-7`})})}),(0,S.jsxs)(`div`,{className:`composer-send-group`,children:[(0,S.jsx)(`button`,{type:`submit`,className:`composer-tool-button composer-send-button${d?` is-active`:``}`,"aria-label":`发送消息`,disabled:!d,children:(0,S.jsx)(`svg`,{className:`composer-icon composer-send`,viewBox:`0 0 24 24`,"aria-hidden":`true`,children:(0,S.jsx)(`path`,{d:`m3 2 19 10L3 22l2.7-8 9-2-9-2z`})})}),(0,S.jsx)(`span`,{className:`composer-divider`,"aria-hidden":`true`}),(0,S.jsx)(`svg`,{className:`composer-caret`,viewBox:`0 0 12 12`,"aria-hidden":`true`,children:(0,S.jsx)(`path`,{d:`m3 4 3 3 3-3`})})]})]})]})})}var ce=[{label:`AI 工作`,icon:`assistant`},{label:`云文档`,icon:`documents`},{label:`推荐`,icon:`recommend`},{label:`多维表格`,icon:`table`},{label:`视频会议`,icon:`video`},{label:`工作台`,icon:`workspace`},{label:`应用中心`,icon:`apps`},{label:`通讯录`,icon:`contacts`},{label:`日历`,icon:`calendar`},{label:`团队空间`,icon:`team`},{label:`权益升级`,icon:`benefits`},{label:`更多`,icon:`more`}];function C({name:e}){let t={className:`nav-icon nav-icon-${e}`,viewBox:`0 0 24 24`,"aria-hidden":!0};switch(e){case`messages`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`M3 5.8A5.8 5.8 0 0 1 8.8 0h7.1a5.8 5.8 0 0 1 5.8 5.8v4.5a5.8 5.8 0 0 1-5.8 5.8h-5.2l-4.6 3v-3.4A5.8 5.8 0 0 1 3 10.3z`,fill:`#3c78f4`}),(0,S.jsx)(`path`,{d:`M13.2 9.5a4.6 4.6 0 0 1 4.6 4.6v1.2a4.6 4.6 0 0 1-4.6 4.6h-1.8L8.2 23v-4.5a4.6 4.6 0 0 1 .4-9z`,fill:`#31c8b3`})]});case`assistant`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`M12 2.2c-5.4 0-9.8 4.1-9.8 9.2 0 4.6 3.1 8 7.5 8.8l8.1-4.6a4.5 4.5 0 0 0 3.9-4.5c0-4.9-4.3-8.9-9.7-8.9Z`,fill:`currentColor`,opacity:`.62`}),(0,S.jsx)(`path`,{d:`M4.5 13.4c2.5-3.6 6.9-4.4 10.3-1.6 2.4 2 4.3 1.8 6.2.2`,fill:`none`,stroke:`#fcfcfc`,strokeWidth:`2`,strokeLinecap:`round`})]});case`documents`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`M5 2.5h10l4 4V21H5z`,fill:`currentColor`,opacity:`.72`}),(0,S.jsx)(`path`,{d:`M15 2.5v4h4M8 10h7M8 13h6`,fill:`none`,stroke:`#fcfcfc`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,S.jsx)(`path`,{d:`M14.5 20.5a3.5 3.5 0 0 1 7 0`,fill:`#a8b4c5`}),(0,S.jsx)(`circle`,{cx:`18`,cy:`16.6`,r:`1.9`,fill:`#a8b4c5`})]});case`recommend`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`m5 4 13-1.5 2.5 13L7.5 18z`,fill:`currentColor`,opacity:`.56`}),(0,S.jsx)(`path`,{d:`M4 7h14v14H4z`,fill:`currentColor`,opacity:`.78`}),(0,S.jsx)(`path`,{d:`m11 9 1.3 2.4 2.7.4-2 1.9.5 2.7-2.5-1.3-2.4 1.3.4-2.7-2-1.9 2.8-.4z`,fill:`#fcfcfc`})]});case`table`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`rect`,{x:`3`,y:`3`,width:`18`,height:`18`,rx:`2`,fill:`currentColor`,opacity:`.72`}),(0,S.jsx)(`path`,{d:`M3 9h18M3 15h18M9 3v18m6-18v18`,stroke:`#fcfcfc`,strokeWidth:`1.2`}),(0,S.jsx)(`path`,{d:`m7 7 2-2m6 0 2 2m-10 8 2 2m6 0 2-2`,stroke:`#fcfcfc`,strokeWidth:`1`})]});case`video`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`rect`,{x:`2.5`,y:`5`,width:`14`,height:`14`,rx:`3`,fill:`currentColor`,opacity:`.7`}),(0,S.jsx)(`path`,{d:`m16.5 9 5-3v12l-5-3z`,fill:`currentColor`,opacity:`.85`}),(0,S.jsx)(`circle`,{cx:`7`,cy:`9`,r:`1.4`,fill:`#fcfcfc`})]});case`workspace`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`rect`,{x:`3`,y:`3`,width:`8`,height:`8`,rx:`3.2`,fill:`currentColor`,opacity:`.7`}),(0,S.jsx)(`rect`,{x:`13`,y:`3`,width:`8`,height:`8`,rx:`3.2`,fill:`currentColor`,opacity:`.7`}),(0,S.jsx)(`rect`,{x:`3`,y:`13`,width:`8`,height:`8`,rx:`3.2`,fill:`currentColor`,opacity:`.7`}),(0,S.jsx)(`rect`,{x:`13`,y:`13`,width:`8`,height:`8`,rx:`3.2`,fill:`currentColor`,opacity:`.7`})]});case`apps`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`M4 8h16l-1.2 12H5.2z`,fill:`currentColor`,opacity:`.72`}),(0,S.jsx)(`path`,{d:`M8 8V6a4 4 0 0 1 8 0v2`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`}),(0,S.jsx)(`path`,{d:`m12 11 1 2h2l-1.6 1.5.5 2.2-1.9-1.2-2 1.2.6-2.2L9 13h2z`,fill:`#fcfcfc`})]});case`contacts`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`circle`,{cx:`9`,cy:`7`,r:`4`,fill:`currentColor`,opacity:`.7`}),(0,S.jsx)(`path`,{d:`M2.5 21v-2a6.5 6.5 0 0 1 13 0v2z`,fill:`currentColor`,opacity:`.7`}),(0,S.jsx)(`path`,{d:`M18 7h4M18 11h4M18 15h3`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`})]});case`calendar`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`rect`,{x:`3`,y:`4.5`,width:`18`,height:`17`,rx:`2`,fill:`currentColor`,opacity:`.72`}),(0,S.jsx)(`path`,{d:`M7 2.5v4m10-4v4M3 9h18`,stroke:`#fcfcfc`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,S.jsx)(`text`,{x:`12`,y:`18`,fill:`#fcfcfc`,fontSize:`9`,fontWeight:`700`,textAnchor:`middle`,children:`5`})]});case`team`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`M4 5h6v15H4zM14 3h6v17h-6z`,fill:`currentColor`,opacity:`.68`}),(0,S.jsx)(`path`,{d:`M10 7h4v13h-4z`,fill:`currentColor`,opacity:`.9`})]});case`benefits`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`m12 1.8 10 4.1v5.4c0 5.7-4.2 9.2-10 11.5C6.2 20.5 2 17 2 11.3V5.9z`,fill:`#3978f8`}),(0,S.jsx)(`path`,{d:`m7.2 11.8 3.1 3.1 6.6-6.5`,fill:`none`,stroke:`#fff`,strokeWidth:`2.1`,strokeLinecap:`round`,strokeLinejoin:`round`})]});case`more`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`rect`,{x:`2`,y:`2`,width:`20`,height:`20`,rx:`6`,fill:`#edf4ff`}),(0,S.jsx)(`path`,{d:`m7 6 1.2 2.4L11 9l-2.8.8L7 12l-.9-2.2L3.5 9l2.6-.6zM16.5 4.5l.8 1.7 1.8.5-1.8.6-.8 1.7-.7-1.7-1.8-.6 1.8-.5zM14 13h5v6h-5z`,fill:`#3978f8`}),(0,S.jsx)(`circle`,{cx:`12`,cy:`18`,r:`1.7`,fill:`#31c8b3`})]});case`settings`:return(0,S.jsxs)(`svg`,{...t,children:[(0,S.jsx)(`path`,{d:`M9.7 2.8h4.6l.7 2.5 2 .9 2.2-1.1 2.3 4-2 1.7v2.3l2 1.7-2.3 4-2.2-1.1-2 .9-.7 2.5H9.7L9 18.6l-2-.9-2.2 1.1-2.3-4 2-1.7v-2.3l-2-1.7 2.3-4L7 6.2l2-.9z`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinejoin:`round`}),(0,S.jsx)(`circle`,{cx:`12`,cy:`11.9`,r:`3`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`})]})}}function le({query:e,onQueryChange:t,onOpenMessages:n,onOpenSettings:r}){return(0,S.jsxs)(`aside`,{className:`nav-rail`,"aria-label":`主导航`,children:[(0,S.jsxs)(`label`,{className:`nav-search`,children:[(0,S.jsxs)(`svg`,{className:`nav-search-icon`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,S.jsx)(`circle`,{cx:`10.5`,cy:`10.5`,r:`8`}),(0,S.jsx)(`path`,{d:`m15.5 15.5 5 5`})]}),(0,S.jsx)(`input`,{value:e,onChange:e=>t(e.target.value),placeholder:`搜索 (Ctrl + K)`,"aria-label":`搜索会话`})]}),(0,S.jsxs)(`nav`,{className:`nav-functions`,"aria-label":`功能导航`,children:[(0,S.jsxs)(`button`,{type:`button`,className:`nav-item nav-item-active`,onClick:n,children:[(0,S.jsx)(C,{name:`messages`}),(0,S.jsx)(`span`,{children:`消息`})]}),ce.map(e=>(0,S.jsxs)(`div`,{className:`nav-item nav-item-static`,"aria-label":e.label,children:[(0,S.jsx)(C,{name:e.icon}),(0,S.jsx)(`span`,{children:e.label})]},e.label))]}),(0,S.jsxs)(`button`,{type:`button`,className:`nav-item nav-settings`,onClick:r,"aria-label":`设置`,children:[(0,S.jsx)(C,{name:`settings`}),(0,S.jsx)(`span`,{children:`设置`})]})]})}function w({value:e,min:t,max:n,label:r,onChange:i,onReset:a}){let[o,s]=(0,l.useState)(!1),c=(0,l.useRef)(0),u=(0,l.useRef)(e),d=e=>Math.max(t,Math.min(n,e));return(0,S.jsx)(`div`,{className:`splitter${o?` is-dragging`:``}`,role:`separator`,"aria-orientation":`vertical`,"aria-label":r,"aria-valuenow":e,"aria-valuemin":t,"aria-valuemax":n,tabIndex:0,onDoubleClick:a,onPointerDown:t=>{c.current=t.clientX,u.current=e,s(!0),t.currentTarget.setPointerCapture(t.pointerId)},onPointerMove:e=>{o&&i(d(u.current+e.clientX-c.current))},onPointerUp:e=>{s(!1),e.currentTarget.releasePointerCapture(e.pointerId)},onPointerCancel:()=>s(!1),onKeyDown:t=>{t.key===`ArrowLeft`?(t.preventDefault(),i(d(e-16))):t.key===`ArrowRight`?(t.preventDefault(),i(d(e+16))):t.key===`Home`&&(t.preventDefault(),a())}})}function ue(e){let t=``;for(let n of e)t+=String.fromCharCode(n);return btoa(t).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}async function de(e){let t=JSON.stringify({architecture:e.architecture,installationId:e.installationId,platform:e.platform,screen:e.screen,timeZone:e.timeZone}),n=await crypto.subtle.digest(`SHA-256`,new TextEncoder().encode(t));return ue(new Uint8Array(n))}async function fe(){let e=await m(),t=navigator.userAgentData,n=await t?.getHighEntropyValues?.([`architecture`]);return de({installationId:e,platform:t?.platform??navigator.platform??`unknown`,architecture:n?.architecture??`unknown`,screen:`${window.screen.width}x${window.screen.height}@${window.devicePixelRatio}`,timeZone:Intl.DateTimeFormat().resolvedOptions().timeZone||`unknown`})}var pe=/^FL(1|3)-([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/,T=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;function E(e){let t=e.replace(/-/g,`+`).replace(/_/g,`/`),n=t.padEnd(Math.ceil(t.length/4)*4,`=`),r=atob(n),i=new Uint8Array(r.length);for(let e=0;e<r.length;e++)i[e]=r.charCodeAt(e);return i}function me(e){try{let t=new TextDecoder().decode(E(e)),n=JSON.parse(t);return n?.v===3?typeof n.j!=`string`||!T.test(n.j)||typeof n.i!=`number`||!Number.isSafeInteger(n.i)||n.i<0?void 0:{v:3,j:n.j,i:n.i}:n?.v!==1||typeof n.d!=`string`||n.d.length===0||typeof n.i!=`number`||!Number.isFinite(n.i)||n.i<0?void 0:{v:1,d:n.d,i:n.i}}catch{return}}function he(e){if(e.length>2048)return{ok:!1,reason:`FORMAT`};let t=pe.exec(e.trim());if(t==null)return{ok:!1,reason:`FORMAT`};let n=me(t[2]);if(n==null||n.v!==Number(t[1]))return{ok:!1,reason:`FORMAT`};try{let e=E(t[3]);return e.byteLength===64?{ok:!0,payload:n,signature:e}:{ok:!1,reason:`FORMAT`}}catch{return{ok:!1,reason:`FORMAT`}}}async function ge(e,t,n){let r=he(e);if(!r.ok)return r;let i=new TextEncoder().encode(JSON.stringify(r.payload)),a=!1;try{a=await crypto.subtle.verify({name:`ECDSA`,hash:`SHA-256`},t,r.signature,i)}catch{a=!1}return a?r.payload.v===1&&r.payload.d!==n?{ok:!1,reason:`DEVICE`}:{ok:!0,payload:r.payload}:{ok:!1,reason:`SIGN`}}var _e=2592e5;function ve(e,t){let n=Number.isFinite(t)?Math.max(0,t):e.lastSeenAt,r=Math.max(0,n-e.lastSeenAt),i=Math.min(_e,e.trialElapsedMs+r);return{...e,trialElapsedMs:i,lastSeenAt:Math.max(e.lastSeenAt,n)}}function ye(e){if(e.kind===`owned`)return{mode:`OWNED`,activatedAt:e.activatedAt??e.lastSeenAt};let t=Math.max(0,_e-e.trialElapsedMs);return t>0?{mode:`TRIAL`,trialRemainMs:t}:{mode:`LOCKED`,trialRemainMs:0}}async function be(e=Date.now()){let t=ve(await g()??{kind:`trial`,trialStartedAt:e,trialElapsedMs:0,lastSeenAt:e},e);return await _(t),ye(t)}async function xe(e,t,n=Date.now()){if(e.v===1&&e.d!==t)throw Error(`激活码设备不匹配`);let r={...ve(await g()??{kind:`trial`,trialStartedAt:n,trialElapsedMs:0,lastSeenAt:n},n),kind:`owned`,activatedAt:n,issuedAt:e.i,boundDeviceCode:e.v===1?t:void 0};return await _(r),ye(r)}async function Se(e,t,n,r=Date.now()){let i=await ge(e,t,n);return i.ok?{ok:!0,status:await xe(i.payload,n,r)}:i}var Ce=`MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEQ96CCVqO57VFLQvYv7aCK0QZ0B5uukyBc0W/Bmy+rznWKebElGTQJgiQ2lYETOWGHqHIUNd5ZzHv2TRS6clG2w==`;function we(e){let t=atob(e),n=new Uint8Array(t.length);for(let e=0;e<t.length;e++)n[e]=t.charCodeAt(e);return n}async function Te(){return crypto.subtle.importKey(`spki`,we(Ce),{name:`ECDSA`,namedCurve:`P-256`},!0,[`verify`])}async function Ee(e,t=Date.now()){let n=e.trim();if(n.startsWith(`FL3-`))return Se(n,await Te(),``,t);if(!n.startsWith(`FL1-`))return{ok:!1,reason:`FORMAT`};let[r,i]=await Promise.all([Te(),fe()]);return Se(n,r,i,t)}var De=`analyticsEnabled`,Oe=`analyticsCounts`,ke=Promise.resolve();function Ae(e){let t=ke.then(e);return ke=t.then(()=>void 0,()=>void 0),t}async function je(){let e=await chrome.storage.local.get([De,Oe]);return{enabled:e[De]!==!1,counts:e[Oe]??{}}}async function Me(e){await Ae(async()=>{let t=await je();t.enabled&&await chrome.storage.local.set({[Oe]:{...t.counts,[e]:(t.counts[e]??0)+1}})})}function Ne(e){return e===`FORMAT`?`激活码格式错误，请检查后重试`:e===`DEVICE`?`旧激活码与当前设备不匹配，请联系好友获取新版离线激活码`:`激活码验证失败，请检查后重试`}function Pe({qrCodeSrc:e,activateCode:t,onActivated:n,onOpenSettings:r,expired:i=!1}){let a=(0,l.useRef)(null),o=(0,l.useRef)(!1),[s,c]=(0,l.useState)(``),[u,d]=(0,l.useState)(``),[f,p]=(0,l.useState)(!1),m=e??chrome.runtime.getURL(`wechat-friend-qr.jpg`);(0,l.useEffect)(()=>{Me(`purchase_view`).catch(()=>{}),i&&a.current?.focus()},[]);let h=async()=>{if(!o.current){if(t==null)d(`激活服务尚未配置`);else if(s.trim().length===0)d(`请输入激活码`);else{o.current=!0,p(!0),d(``);try{let e=await t(s.trim());if(!e.ok){d(Ne(e.reason));return}c(``),d(`激活成功`),Me(`activate_ok`).catch(()=>{}),n?.(e.status)}catch{d(`密钥验证失败，请重试`)}finally{o.current=!1,p(!1)}}}};return(0,S.jsxs)(`section`,{className:`payment-panel`,"aria-label":i?`输入密钥解锁`:`支付与激活`,children:[!i&&(0,S.jsx)(`h2`,{children:`授权过期，请购买使用`}),!i&&(0,S.jsx)(`p`,{className:`payment-copy`,children:`试用到期，添加好友，支付9.9元即可永久解锁全部功能`}),(0,S.jsx)(`img`,{className:`payment-qr`,src:m,alt:`微信好友二维码`}),(0,S.jsx)(`p`,{className:`payment-copy`,children:`使用微信扫码添加好友，获取永久解锁密钥。`}),(0,S.jsx)(`p`,{className:`payment-copy`,children:`只需输入激活码，无需提供设备号。激活与使用均无需联网，授权仅保存在本机。`}),(0,S.jsxs)(`label`,{className:`activation-field`,children:[(0,S.jsx)(`span`,{children:i?`密钥`:`激活码`}),(0,S.jsx)(`input`,{ref:a,value:s,onChange:e=>c(e.target.value),onKeyDown:e=>{e.stopPropagation(),e.key===`Enter`&&!e.nativeEvent.isComposing&&(e.preventDefault(),h())},placeholder:i?`请输入好友提供的解锁密钥`:`请输入卖家提供的激活码`,disabled:f,autoComplete:`off`})]}),(0,S.jsxs)(`div`,{className:`payment-actions`,children:[r!=null&&(0,S.jsx)(`button`,{type:`button`,className:`plain-btn`,onClick:r,children:`打开设置`}),(0,S.jsx)(`button`,{type:`button`,className:`primary-btn`,onClick:()=>void h(),disabled:f,children:f?`正在验证…`:`激活`})]}),u&&(0,S.jsx)(`p`,{className:u===`激活成功`?`payment-message success`:`payment-message`,role:`status`,children:u})]})}function Fe(e){let t=Math.ceil(e.trialRemainMs/36e5);return t>=24?`试用剩余 ${Math.ceil(t/24)} 天`:`试用剩余 ${t} 小时`}function Ie({children:e,onOpenSettings:t,showTrialBadge:n=!0}){let r=(0,l.useId)(),[i,a]=(0,l.useState)(null),[o,s]=(0,l.useState)(``),c=(0,l.useRef)(0),u=(0,l.useRef)(!1),d=(0,l.useCallback)(async()=>{let e=++c.current;try{let t=await be();u.current&&e===c.current&&(a(t),s(``))}catch{u.current&&e===c.current&&(a(null),s(`授权检查失败，请重试`))}},[]);(0,l.useEffect)(()=>{u.current=!0;let e=()=>{d()},t=(e,t)=>{let n=e.licenseRecord,r=n?.newValue,i=n?.oldValue;t===`local`&&n&&(r?.kind!==i?.kind||r?.activatedAt!==i?.activatedAt)&&d()};return d(),window.addEventListener(`focus`,e),chrome.storage.onChanged?.addListener(t),()=>{u.current=!1,c.current+=1,window.removeEventListener(`focus`,e),chrome.storage.onChanged?.removeListener(t)}},[d]),(0,l.useEffect)(()=>{if(i?.mode!==`TRIAL`)return;let e=window.setTimeout(()=>{d()},Math.max(1,Math.min(i.trialRemainMs,6e4)));return()=>window.clearTimeout(e)},[i,d]);let f=i==null||i.mode===`LOCKED`;return(0,S.jsxs)(`div`,{className:`license-gate${f?` is-locked`:``}`,children:[(0,S.jsx)(`div`,{className:`license-gate-content`,"aria-hidden":f?!0:void 0,...f?{inert:``}:{},children:e}),n&&i?.mode===`TRIAL`&&(0,S.jsx)(`div`,{className:`trial-badge`,children:Fe(i)}),f&&(0,S.jsx)(`div`,{className:`license-lock-layer`,children:i?.mode===`LOCKED`?(0,S.jsxs)(`div`,{className:`license-expired-dialog`,role:`dialog`,"aria-modal":`true`,"aria-labelledby":r,children:[(0,S.jsx)(`h2`,{id:r,children:`试用期结束`}),(0,S.jsx)(`p`,{className:`license-expired-copy`,children:`试用期结束，请添加好友，9.9即可永久解锁全部功能`}),(0,S.jsx)(Pe,{expired:!0,activateCode:Ee,onActivated:e=>{c.current+=1,a(e)},onOpenSettings:t})]}):(0,S.jsxs)(`div`,{className:`license-check-state`,role:`status`,children:[o||`正在检查授权…`,o&&(0,S.jsx)(`button`,{type:`button`,className:`plain-btn`,onClick:()=>void d(),children:`重试`})]})})]})}var Le={width:1240,height:760};function Re(){let e=Math.min(Le.width,Math.max(720,window.innerWidth-72)),t=Math.min(Le.height,Math.max(520,window.innerHeight-72));return{width:e,height:t,left:Math.max(16,Math.round((window.innerWidth-e)/2)),top:Math.max(16,Math.round((window.innerHeight-t)/2))}}function ze(e){let t=new Date(e),n=e=>String(e).padStart(2,`0`),r=new Date;return t.toDateString()===r.toDateString()?`${n(t.getHours())}:${n(t.getMinutes())}`:t.getFullYear()===r.getFullYear()?`${t.getMonth()+1}月${t.getDate()}日`:`${t.getFullYear()}年${t.getMonth()+1}月${t.getDate()}日`}function Be(e){let t=(e??``).replace(/\s+/g,` `).trim();if(!t)return``;let n=t.search(/[。！？!?；;]/u);return n>=0?t.slice(0,n+1):t}function Ve({name:e}){return(0,S.jsxs)(`svg`,{viewBox:`0 0 16 16`,"aria-hidden":`true`,children:[e===`hide`&&(0,S.jsx)(`path`,{d:`M3 8h10`}),e===`maximize`&&(0,S.jsx)(`path`,{d:`M3 6V3h3m4 0h3v3m0 4v3h-3m-4 0H3v-3`}),e===`close`&&(0,S.jsx)(`path`,{d:`m3 3 10 10M13 3 3 13`})]})}function He({session:e,name:t,avatar:n,preview:r,time:i,selected:a,onOpen:o,onSavePreview:s}){let[c,u]=(0,l.useState)(!1),[d,f]=(0,l.useState)(``),p=()=>{u(!1),f(``)};return(0,S.jsxs)(`div`,{className:`message-row${a?` is-selected`:``}`,children:[(0,S.jsx)(`span`,{className:`message-avatar-display`,"aria-hidden":`true`,children:n?(0,S.jsx)(`img`,{className:`message-avatar-image`,src:n,alt:``}):(0,S.jsx)(`span`,{className:`message-avatar`,"data-format":e.format,children:e.format.toUpperCase()})}),(0,S.jsxs)(`span`,{className:`message-meta`,children:[(0,S.jsx)(`button`,{type:`button`,className:`message-row-open`,onClick:()=>o(e.id),children:(0,S.jsxs)(`span`,{className:`message-heading`,children:[(0,S.jsx)(`span`,{className:`message-name`,children:t}),(0,S.jsx)(`time`,{className:`message-time`,children:i})]})}),c?(0,S.jsxs)(`form`,{className:`message-preview-editor`,onSubmit:t=>{t.preventDefault();let n=d.trim();n&&(s(e.id,n),p())},children:[(0,S.jsx)(`input`,{"aria-label":`编辑 ${t} 的会话记录`,autoFocus:!0,maxLength:200,value:d,onChange:e=>f(e.target.value),onKeyDown:e=>{e.stopPropagation(),e.key===`Escape`&&p()}}),(0,S.jsx)(`button`,{type:`submit`,disabled:!d.trim(),children:`保存`}),(0,S.jsx)(`button`,{type:`button`,onClick:p,children:`取消`})]}):(0,S.jsx)(`button`,{type:`button`,className:`message-preview-edit message-preview`,"aria-label":`修改 ${t} 的会话记录`,title:`点击修改会话记录`,onClick:()=>{f(r),u(!0)},children:r})]})]})}function Ue({onClose:e}){let[t,n]=(0,l.useState)(!1),[r,i]=(0,l.useState)(!1),[a,o]=(0,l.useState)(Re),[s,c]=(0,l.useState)(.15),[u,d]=(0,l.useState)(.344),[p,m]=(0,l.useState)([]),[h,g]=(0,l.useState)({}),[_,ne]=(0,l.useState)({}),[oe,ce]=(0,l.useState)({}),[C,ue]=(0,l.useState)(`本地用户`),[de,fe]=(0,l.useState)(chrome.runtime.getURL(ie)),[pe,T]=(0,l.useState)(14),[E,me]=(0,l.useState)(),[he,ge]=(0,l.useState)([]),[_e,ve]=(0,l.useState)({}),[ye,be]=(0,l.useState)(`idle`),[xe,Se]=(0,l.useState)(``),Ce=(0,l.useRef)(null),we=(0,l.useRef)(null),Te=(0,l.useRef)(!1),Ee=()=>{chrome.runtime.sendMessage({type:`OPEN_SETTINGS`}).catch(()=>{})};(0,l.useEffect)(()=>{let e=document.getElementById(`focus-reading-floating-host`);e&&(e.style.display=t?`none`:``)},[t]),(0,l.useEffect)(()=>{let e=e=>e?.type===`HIDE_FLOATING_PANEL`?(n(!0),!0):e?.type===`SHOW_FLOATING_PANEL`&&(n(!1),!0);return chrome.runtime.onMessage.addListener(e),()=>chrome.runtime.onMessage.removeListener(e)},[]),(0,l.useEffect)(()=>{let e=!0,t=async()=>{let[t,n,r,i,a,o]=await Promise.all([f(),v(),te(),re(),ee(),y()]),s=await x(t.map(e=>e.id)).catch(()=>({}));e&&(m(t),g(n),ce(o),ne(Object.fromEntries(Object.entries(s).filter(([,e])=>ae(e)))),fe(ae(r)?r:chrome.runtime.getURL(ie)),ue(i),T(a.fontSize))};return t().catch(()=>{}),window.addEventListener(`focus`,t),()=>{e=!1,window.removeEventListener(`focus`,t)}},[]),(0,l.useEffect)(()=>{!E&&p.length>0&&me(p[0].id)},[E,p]),(0,l.useEffect)(()=>{if(!Te.current)return;Te.current=!1;let e=we.current;e&&(e.scrollTop=e.scrollHeight)},[_e]),(0,l.useEffect)(()=>{if(!E)return;let e=`${E}:${Date.now()}`,t=t=>{if(!(`requestId`in t)||t.requestId!==e)return!1;if(t.type===`BOOK_META`)return be(`loading`),ge([]),!0;if(t.type===`BOOK_CHUNKS`){let e=t;return ge(t=>{let n=[...t];return n.splice(e.start,e.chunks.length,...e.chunks),n}),!0}if(t.type===`BOOK_DONE`)return be(`ready`),!0;if(t.type===`BOOK_ERROR`){let e=t;return be(e.code===`AUTH_REQUIRED`?`auth`:`error`),Se(e.detail??``),!0}return!1};return chrome.runtime.onMessage.addListener(t),be(`loading`),ge([]),Se(``),chrome.runtime.sendMessage({type:`REQUEST_BOOK`,requestId:e,sessionId:E}).catch(e=>{be(`error`),Se(e instanceof Error?`${e.name}: ${e.message}`:String(e))}),()=>chrome.runtime.onMessage.removeListener(t)},[E]);let De=e=>t=>{Ce.current={mode:e,x:t.clientX,y:t.clientY,...a},t.currentTarget.setPointerCapture(t.pointerId)},Oe=e=>{let t=Ce.current;if(!t)return;let n=e.clientX-t.x,r=e.clientY-t.y;t.mode===`drag`?o({...a,left:Math.max(0,Math.min(window.innerWidth-180,t.left+n)),top:Math.max(0,Math.min(window.innerHeight-80,t.top+r))}):o({...a,width:Math.max(720,Math.min(window.innerWidth-t.left,t.width+n)),height:Math.max(520,Math.min(window.innerHeight-t.top,t.height+r))})},ke=e=>{Ce.current=null,e.currentTarget.releasePointerCapture?.(e.pointerId)},Ae=r?{left:0,top:0,width:`100%`,height:`100%`}:{left:a.left,top:a.top,width:a.width,height:a.height},je=r?window.innerWidth:a.width,Me=Math.max(168,Math.min(400,Math.round(je*s))),Ne=Math.max(260,Math.min(1e3,je-Me-200)),Pe=Math.max(260,Math.min(Ne,Math.round(je*u))),Fe={"--home-nav-width":`${Me}px`,"--home-list-width":`${Pe}px`},Le=[...p].sort((e,t)=>t.lastOpenedAt-e.lastOpenedAt),Ue=p.find(e=>e.id===E),We=E?_[E]:void 0,Ge=E?_e[E]??[]:[],Ke=Be(he[0]?.text)||`点击会话查看首条记录`,qe=e=>oe[e]??(e===E?Ke:`点击会话查看首条记录`),Je=(e,t)=>{ce(n=>({...n,[e]:t})),b(e,t).catch(()=>{})};return(0,S.jsxs)(`div`,{className:`floating-panel${r?` is-maximized`:``}`,style:Ae,children:[(0,S.jsx)(`div`,{className:`floating-drag-handle`,onPointerDown:De(`drag`),onPointerMove:Oe,onPointerUp:ke}),(0,S.jsx)(`div`,{className:`floating-root`,children:(0,S.jsxs)(`div`,{className:`workspace-shell`,style:Fe,children:[(0,S.jsxs)(`div`,{className:`workspace-topbar`,children:[(0,S.jsxs)(`div`,{className:`workspace-topbar-account`,children:[(0,S.jsx)(`button`,{type:`button`,className:`profile-avatar-button`,"aria-label":`打开头像设置`,title:`头像设置`,onClick:Ee,children:(0,S.jsx)(`img`,{src:de,alt:``})}),(0,S.jsx)(`button`,{type:`button`,className:`new-session-trigger`,"aria-label":`导入文档`,title:`导入文档：前往设置页`,onClick:Ee,children:(0,S.jsxs)(`svg`,{viewBox:`0 0 24 24`,"aria-hidden":`true`,children:[(0,S.jsx)(`circle`,{cx:`12`,cy:`12`,r:`8`}),(0,S.jsx)(`path`,{d:`M12 8v8M8 12h8`})]})})]}),(0,S.jsxs)(`div`,{className:`workspace-topbar-controls`,children:[(0,S.jsx)(`button`,{type:`button`,className:`floating-panel-control`,"aria-label":`隐藏阅读面板`,title:`老板键隐藏`,onClick:()=>n(!0),children:(0,S.jsx)(Ve,{name:`hide`})}),(0,S.jsx)(`button`,{type:`button`,className:`floating-panel-control`,"aria-label":`切换面板最大化`,title:`最大化面板`,onClick:()=>i(e=>!e),children:(0,S.jsx)(Ve,{name:`maximize`})}),(0,S.jsx)(`button`,{type:`button`,className:`floating-panel-control`,"aria-label":`关闭阅读面板`,title:`关闭面板`,onClick:()=>{n(!0),e?.()},children:(0,S.jsx)(Ve,{name:`close`})})]})]}),(0,S.jsx)(Ie,{onOpenSettings:Ee,showTrialBadge:!1,children:(0,S.jsxs)(`div`,{className:`workspace-body`,children:[(0,S.jsx)(le,{query:``,onQueryChange:()=>{},onOpenMessages:()=>{},onOpenSettings:Ee}),(0,S.jsx)(w,{value:Me,min:168,max:Math.max(168,Math.min(400,je-Pe-200)),label:`调节导航栏宽度`,onChange:e=>c(e/je),onReset:()=>c(.15)}),(0,S.jsxs)(`section`,{className:`message-list-panel`,"aria-label":`消息列表`,children:[(0,S.jsx)(`header`,{className:`message-list-header`,children:(0,S.jsxs)(`h2`,{children:[(0,S.jsxs)(`svg`,{className:`message-title-icon`,viewBox:`0 0 24 24`,"aria-hidden":`true`,children:[(0,S.jsx)(`path`,{d:`M4 5h15M10 11h9M10 17h9`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`}),(0,S.jsx)(`path`,{d:`m4 10 5 4-5 4z`,fill:`currentColor`})]}),`消息`]})}),(0,S.jsxs)(`div`,{className:`message-list`,children:[Le.map(e=>(0,S.jsx)(He,{session:e,name:h[e.id]??e.name,avatar:_[e.id],preview:qe(e.id),time:ze(e.lastOpenedAt),selected:e.id===E,onOpen:me,onSavePreview:Je},e.id)),Le.length===0&&(0,S.jsxs)(`div`,{className:`message-list-empty`,children:[(0,S.jsx)(`p`,{children:`还没有会话`}),(0,S.jsx)(`p`,{className:`hint`,children:`前往设置页导入本地文档。`})]})]})]}),(0,S.jsx)(w,{value:Pe,min:260,max:Ne,label:`调节消息列表宽度`,onChange:e=>d(e/je),onReset:()=>d(.344)}),(0,S.jsx)(`main`,{className:`session-detail`,children:(0,S.jsxs)(`div`,{className:`reader`,style:{"--font-size-body":`${pe}px`},children:[(0,S.jsxs)(`header`,{className:`conversation-header`,children:[(0,S.jsxs)(`div`,{className:`conversation-header-profile`,children:[(0,S.jsx)(`button`,{type:`button`,className:`conversation-profile-avatar-button`,"aria-label":`打开会话头像设置`,title:`会话头像设置`,onClick:Ee,children:We?(0,S.jsx)(`img`,{className:`conversation-profile-avatar`,src:We,alt:``}):(0,S.jsx)(`span`,{className:`conversation-profile-avatar`,children:`◎`})}),(0,S.jsx)(`div`,{className:`conversation-header-identity`,children:(0,S.jsx)(`div`,{className:`conversation-header-name`,children:(0,S.jsx)(`button`,{type:`button`,className:`conversation-title-edit`,"aria-label":`修改会话名称`,title:`修改会话名称：前往设置页`,onClick:Ee,children:Ue?h[Ue.id]??Ue.name:`选择会话`})})})]}),(0,S.jsxs)(`div`,{className:`conversation-header-tabs`,"aria-hidden":`true`,children:[(0,S.jsxs)(`span`,{className:`conversation-tab-active`,children:[(0,S.jsxs)(`svg`,{viewBox:`0 0 20 20`,children:[(0,S.jsx)(`path`,{d:`M10 1.8c-4.6 0-8.3 3.2-8.3 7.2 0 2.1 1.1 3.9 3 5.1l-.5 3.7 4.1-2c.6.2 1.1.3 1.7.3 4.6 0 8.3-3.2 8.3-7.2s-3.7-7.1-8.3-7.1Z`,fill:`currentColor`}),(0,S.jsx)(`path`,{d:`M6.4 8h7.2M6.4 10.5h4.8`,fill:`none`,stroke:`#fff`,strokeLinecap:`round`,strokeWidth:`1.2`})]}),`消息`]}),(0,S.jsxs)(`span`,{children:[(0,S.jsxs)(`svg`,{viewBox:`0 0 20 20`,children:[(0,S.jsx)(`path`,{d:`M3 1.8h9l4 4v12.4H3z`,fill:`#3478f6`}),(0,S.jsx)(`path`,{d:`M12 1.8v4h4`,fill:`#a8c6ff`}),(0,S.jsx)(`path`,{d:`M5.4 8h5.3M5.4 10.2h4.2`,fill:`none`,stroke:`#fff`,strokeLinecap:`round`,strokeWidth:`1`}),(0,S.jsx)(`path`,{d:`M13.3 11.1c-.7 0-1.2.4-1.3 1-.6.1-1 .5-1 1.1 0 .6.5 1 1.1 1h3c.7 0 1.2-.5 1.2-1.1 0-.6-.4-1-1-1.1-.2-.5-.7-.9-1.3-.9-.3 0-.5 0-.7.1Z`,fill:`#35c58b`})]}),`云文档`]}),(0,S.jsx)(`span`,{className:`conversation-tab-add`,children:`＋`})]})]}),(0,S.jsxs)(`div`,{className:`message-stream`,ref:we,children:[ye===`loading`&&(0,S.jsx)(`div`,{className:`reader-state`,children:`正在读取本地文档…`}),ye===`auth`&&(0,S.jsxs)(`div`,{className:`reader-state`,children:[(0,S.jsx)(`p`,{children:`需要在设置页恢复文件访问权限`}),(0,S.jsx)(`button`,{type:`button`,className:`plain-btn`,onClick:Ee,children:`前往设置页`})]}),ye===`error`&&(0,S.jsxs)(`div`,{className:`reader-state`,"data-error":xe,children:[(0,S.jsx)(`p`,{children:`文档读取失败，请在设置页重新导入`}),(0,S.jsx)(`button`,{type:`button`,className:`plain-btn`,onClick:Ee,children:`前往设置页`})]}),ye===`ready`&&he.map((e,t)=>(0,S.jsxs)(`div`,{className:`msg ${t%2==0?`self`:`other`}`,children:[(0,S.jsx)(`img`,{className:`msg-avatar`,src:t%2==0?de:We||de,alt:``}),(0,S.jsx)(`div`,{className:`bubble`,children:e.text})]},`${e.start}-${t}`)),Ge.map((e,t)=>(0,S.jsxs)(`div`,{className:`msg self local-sent-message`,"data-local-message":`true`,children:[(0,S.jsx)(`img`,{className:`msg-avatar`,src:de,alt:`${C}的消息头像`}),(0,S.jsx)(`div`,{className:`bubble`,children:e})]},`${E}-local-${t}`))]}),(0,S.jsx)(se,{recipient:Ue?h[Ue.id]??Ue.name:`会话`,disabled:!Ue,onSend:e=>{E&&(Te.current=!0,ve(t=>({...t,[E]:[...t[E]??[],e]})))}},E??`no-session`)]})})]})})]})}),(0,S.jsx)(`div`,{className:`floating-resize-handle`,onPointerDown:De(`resize`),onPointerMove:Oe,onPointerUp:ke})]})}var We=`/* 原创协同文档风设计系统(技术设计 §2:CSS 变量 + 深浅色主题,素材全原创,\r
   无任何真实品牌 Logo/商标/专有色/品牌字体)。正文等效字号 ≥14px(PRD §8.2)。 */\r
\r
:host, .floating-root {\r
  --bg-app: #dee5f4;\r
  --bg-panel: #fcfcfc;\r
  --bg-chat: #fcfcfc;\r
  --bubble-left-bg: #fcfcfc;\r
  --bubble-right-bg: #dee5f4;\r
  --accent: #4e6bae;\r
  --accent-weak: #dee5f4;\r
  --text-1: #1f2329;\r
  --text-2: #51565f;\r
  --text-3: #8a9099;\r
  --border: #e4e6ea;\r
  --danger: #c45656;\r
  --success: #237a4b;\r
  --overlay: rgb(15 23 42 / 32%);\r
  --shadow: 0 18px 50px rgb(15 23 42 / 18%);\r
  --radius: 10px;\r
  --radius-sm: 6px;\r
  --font-size-body: 15px;\r
  --font-size-sub: 13px;\r
  --sidebar-width: clamp(220px, 32vw, 280px);\r
  color-scheme: light dark;\r
}\r
\r
@media (prefers-color-scheme: dark) {\r
  :host, .floating-root {\r
    --bg-app: #191b1f;\r
    --bg-panel: #202329;\r
    --bg-chat: #26292f;\r
    --bubble-left-bg: #2d3138;\r
    --bubble-right-bg: #33415c;\r
    --accent: #7c93c9;\r
    --accent-weak: #2a3142;\r
    --text-1: #e8eaed;\r
    --text-2: #b4b9c0;\r
    --text-3: #7d838c;\r
    --border: #33373e;\r
    --danger: #d98080;\r
    --success: #6fce9b;\r
    --overlay: rgb(0 0 0 / 58%);\r
    --shadow: 0 18px 50px rgb(0 0 0 / 36%);\r
  }\r
}\r
\r
* {\r
  box-sizing: border-box;\r
}\r
\r
.floating-root {\r
  height: 100%;\r
  margin: 0;\r
}\r
\r
.floating-root {\r
  font-family: 'Segoe UI', 'Microsoft YaHei', system-ui, -apple-system, sans-serif;\r
  font-size: var(--font-size-body);\r
  color: var(--text-1);\r
  background: var(--bg-app);\r
}\r
\r
button {\r
  font: inherit;\r
  color: inherit;\r
  cursor: pointer;\r
}\r
\r
/* ---- 应用骨架:左会话列表 + 右内容区(最小 720×520 不出横向滚动条) ---- */\r
\r
.app-shell {\r
  display: grid;\r
  grid-template-columns: var(--sidebar-width) minmax(0, 1fr);\r
  height: 100%;\r
  min-width: 0;\r
  overflow: hidden;\r
}\r
\r
.sidebar {\r
  display: flex;\r
  flex-direction: column;\r
  background: var(--bg-panel);\r
  border-right: 1px solid var(--border);\r
  min-height: 0;\r
}\r
\r
.sidebar-header {\r
  display: flex;\r
  align-items: center;\r
  justify-content: space-between;\r
  padding: 14px 16px 10px;\r
}\r
\r
.app-name {\r
  font-weight: 600;\r
  letter-spacing: 0;\r
}\r
\r
.icon-btn {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  width: 30px;\r
  height: 30px;\r
  border: none;\r
  border-radius: var(--radius-sm);\r
  background: transparent;\r
  color: var(--text-2);\r
}\r
\r
.icon-btn:hover {\r
  background: var(--accent-weak);\r
  color: var(--text-1);\r
}\r
\r
.local-tip {\r
  margin: 0 12px 8px;\r
  padding: 8px 10px;\r
  font-size: var(--font-size-sub);\r
  color: var(--text-2);\r
  background: var(--accent-weak);\r
  border-radius: var(--radius-sm);\r
  display: flex;\r
  align-items: center;\r
  justify-content: space-between;\r
  gap: 8px;\r
}\r
\r
.tip-close {\r
  border: none;\r
  background: transparent;\r
  color: var(--accent);\r
  font-size: var(--font-size-sub);\r
  white-space: nowrap;\r
}\r
\r
.import-error {\r
  margin: 0 12px 8px;\r
  padding: 8px 10px;\r
  font-size: var(--font-size-sub);\r
  color: var(--danger);\r
  background: color-mix(in srgb, var(--danger) 12%, transparent);\r
  border-radius: var(--radius-sm);\r
}\r
\r
.conversation-items {\r
  flex: 1;\r
  overflow-y: auto;\r
  padding: 0 8px 12px;\r
  min-height: 0;\r
}\r
\r
.sidebar-empty {\r
  padding: 24px 12px;\r
  color: var(--text-3);\r
  text-align: center;\r
}\r
\r
.sidebar-empty .hint {\r
  font-size: var(--font-size-sub);\r
  line-height: 1.6;\r
}\r
\r
.conversation-item {\r
  display: flex;\r
  align-items: center;\r
  gap: 10px;\r
  width: 100%;\r
  padding: 10px;\r
  border: none;\r
  border-radius: var(--radius-sm);\r
  background: transparent;\r
  text-align: left;\r
}\r
\r
\r
.conversation-item:hover {\r
  background: var(--accent-weak);\r
}\r
\r
.avatar {\r
  flex: none;\r
  width: 38px;\r
  height: 38px;\r
  border-radius: var(--radius-sm);\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  background: var(--accent-weak);\r
  color: var(--accent);\r
  font-size: 12px;\r
  font-weight: 600;\r
}\r
\r
.conversation-item .meta {\r
  display: flex;\r
  flex-direction: column;\r
  min-width: 0;\r
}\r
\r
.conversation-item .name {\r
  font-weight: 500;\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
\r
.conversation-item .sub {\r
  font-size: var(--font-size-sub);\r
  color: var(--text-3);\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
\r
.panel-empty {\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  background: var(--bg-chat);\r
  color: var(--text-3);\r
}\r
\r
.panel-empty .hint {\r
  font-size: var(--font-size-sub);\r
}\r
\r
.panel-empty-inner {\r
  text-align: center;\r
  line-height: 1.8;\r
}\r
\r
/* ---- 阅读对话 ---- */\r
\r
.reader {\r
  container: composer-frame / size;\r
  display: flex;\r
  flex-direction: column;\r
  height: 100%;\r
  min-width: 0;\r
  background: var(--bg-chat);\r
}\r
\r
.reader-header {\r
  display: flex;\r
  align-items: center;\r
  gap: 10px;\r
  padding: 10px 16px;\r
  background: var(--bg-panel);\r
  border-bottom: 1px solid var(--border);\r
}\r
\r
.reader-title {\r
  flex: 1;\r
  display: flex;\r
  align-items: baseline;\r
  gap: 10px;\r
  min-width: 0;\r
}\r
\r
.reader-title .name {\r
  font-weight: 600;\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
\r
.reader-title .sub {\r
  font-size: var(--font-size-sub);\r
  color: var(--text-3);\r
  white-space: nowrap;\r
}\r
\r
.chapter-select {\r
  max-width: 180px;\r
  padding: 6px 8px;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius-sm);\r
  background: var(--bg-panel);\r
  color: var(--text-1);\r
  font-size: var(--font-size-sub);\r
}\r
\r
.message-stream {\r
  flex: 1;\r
  overflow-y: auto;\r
  padding: 18px min(6%, 48px) 32px;\r
  min-height: 0;\r
}\r
\r
.msg {\r
  display: flex;\r
  margin: 10px 0;\r
}\r
\r
.msg.left {\r
  justify-content: flex-start;\r
}\r
\r
.msg.right {\r
  justify-content: flex-end;\r
}\r
\r
.bubble {\r
  max-width: min(72%, 640px);\r
  padding: 10px 14px;\r
  border-radius: var(--radius);\r
  font-size: var(--font-size-body);\r
  line-height: 1.6;\r
  text-align: left;\r
  text-indent: 0;\r
  white-space: normal;\r
  word-break: break-word;\r
}\r
\r
.msg.left .bubble {\r
  background: var(--bubble-left-bg);\r
  border-top-left-radius: 3px;\r
}\r
\r
.msg.right .bubble {\r
  background: var(--bubble-right-bg);\r
  border-top-right-radius: 3px;\r
}\r
\r
\r
\r
.guide-layer {\r
  position: fixed;\r
  inset: 0;\r
  z-index: 20;\r
  display: grid;\r
  place-items: center;\r
  padding: 20px;\r
  background: var(--overlay);\r
}\r
\r
.guide-panel {\r
  width: min(560px, 100%);\r
  padding: 24px;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius);\r
  background: var(--bg-panel);\r
  box-shadow: var(--shadow);\r
}\r
\r
.guide-heading {\r
  display: flex;\r
  align-items: flex-start;\r
  justify-content: space-between;\r
  gap: 16px;\r
}\r
\r
.guide-kicker {\r
  color: var(--accent);\r
  font-size: 13px;\r
  font-weight: 600;\r
}\r
\r
.guide-heading h2 {\r
  margin: 4px 0 0;\r
  font-size: 21px;\r
}\r
\r
.guide-steps {\r
  display: grid;\r
  gap: 14px;\r
  margin: 22px 0;\r
  padding: 0;\r
  list-style: none;\r
}\r
\r
.guide-steps li {\r
  display: flex;\r
  gap: 12px;\r
  color: var(--text-3);\r
}\r
\r
.guide-steps li > span {\r
  display: grid;\r
  width: 28px;\r
  height: 28px;\r
  flex: 0 0 28px;\r
  place-items: center;\r
  border: 1px solid var(--border);\r
  border-radius: 50%;\r
}\r
\r
.guide-steps li.active {\r
  color: var(--text-1);\r
}\r
\r
.guide-steps li.active > span,\r
.guide-steps li.done > span {\r
  border-color: var(--accent);\r
  background: var(--accent);\r
  color: #ffffff;\r
}\r
\r
.guide-steps p {\r
  margin: 3px 0 0;\r
  line-height: 1.6;\r
}\r
\r
.guide-actions {\r
  display: flex;\r
  justify-content: flex-end;\r
}\r
\r
.payment-panel {\r
  display: grid;\r
  gap: 14px;\r
  width: min(440px, 100%);\r
}\r
\r
.payment-panel h2 {\r
  margin: 0;\r
  font-size: 18px;\r
}\r
\r
.payment-copy {\r
  margin: 0;\r
  color: var(--text-2);\r
  line-height: 1.7;\r
}\r
\r
.payment-qr,\r
.payment-qr-placeholder {\r
  width: 180px;\r
  height: 180px;\r
  justify-self: center;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius-sm);\r
  object-fit: contain;\r
}\r
\r
.payment-qr-placeholder {\r
  display: grid;\r
  place-items: center;\r
  background: var(--bg-chat);\r
  color: var(--text-3);\r
  font-size: 13px;\r
}\r
\r
.activation-field {\r
  display: grid;\r
  gap: 6px;\r
  color: var(--text-2);\r
}\r
\r
.activation-field input {\r
  width: 100%;\r
  padding: 9px 10px;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius-sm);\r
  background: var(--bg-chat);\r
  color: var(--text-1);\r
}\r
\r
.payment-actions {\r
  display: flex;\r
  justify-content: flex-end;\r
  gap: 10px;\r
}\r
\r
.payment-message {\r
  margin: 0;\r
  color: var(--danger);\r
}\r
\r
.payment-message.success {\r
  color: var(--success);\r
}\r
\r
.license-gate {\r
  position: relative;\r
  display: flex;\r
  flex: 1;\r
  flex-direction: column;\r
  min-width: 0;\r
  min-height: 0;\r
  overflow: hidden;\r
}\r
\r
.license-gate-content {\r
  display: flex;\r
  flex: 1;\r
  flex-direction: column;\r
  min-width: 0;\r
  min-height: 0;\r
}\r
\r
.license-gate.is-locked .license-gate-content {\r
  filter: blur(6px);\r
  opacity: 0.55;\r
  pointer-events: none;\r
  user-select: none;\r
}\r
\r
.license-lock-layer {\r
  position: absolute;\r
  inset: 0;\r
  z-index: 40;\r
  display: grid;\r
  min-height: 0;\r
  place-items: center;\r
  padding: 24px;\r
  overflow-y: auto;\r
  background: rgba(234, 239, 247, 0.55);\r
}\r
\r
.license-expired-dialog,\r
.license-check-state {\r
  width: min(440px, 100%);\r
  max-height: 100%;\r
  overflow-y: auto;\r
  padding: 24px;\r
  border: 1px solid #dce4f0;\r
  border-radius: 16px;\r
  background: #fff;\r
  color: #1f2329;\r
  box-shadow: 0 20px 60px rgba(36, 57, 88, 0.18);\r
}\r
\r
.license-expired-dialog h2 {\r
  margin: 0 0 12px;\r
  font-size: 20px;\r
}\r
\r
.license-expired-copy {\r
  margin: 0 0 18px;\r
  color: #566176;\r
  font-size: 14px;\r
  line-height: 1.7;\r
}\r
\r
.trial-badge {\r
  position: fixed;\r
  left: 48px;\r
  bottom: 14px;\r
  z-index: 10;\r
  padding: 3px 6px;\r
  border: 0;\r
  border-radius: 999px;\r
  background: transparent;\r
  color: var(--text-2);\r
  font-size: 10px;\r
}\r
\r
/* ---- 通用状态页 ---- */\r
\r
.reader-state {\r
  flex: 1;\r
  display: flex;\r
  flex-direction: column;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 16px;\r
  height: 100%;\r
  background: var(--bg-chat);\r
  color: var(--text-2);\r
}\r
\r
.primary-btn {\r
  padding: 9px 18px;\r
  border: none;\r
  border-radius: var(--radius-sm);\r
  background: var(--accent);\r
  color: #ffffff;\r
}\r
\r
.plain-btn {\r
  padding: 9px 18px;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius-sm);\r
  background: transparent;\r
  color: var(--text-2);\r
}\r
\r
/* ---- 设置页(非伪装,普通标签页;M1 占位,M2 全量) ---- */\r
\r
.settings-page {\r
  max-width: 760px;\r
  margin: 0 auto;\r
  padding: 32px 24px 64px;\r
}\r
\r
.settings-page h1 {\r
  font-size: 20px;\r
}\r
\r
.settings-section {\r
  margin-top: 28px;\r
  padding: 18px 20px;\r
  background: var(--bg-panel);\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius);\r
}\r
\r
.settings-section h2 {\r
  font-size: 16px;\r
  margin: 0 0 8px;\r
}\r
\r
.settings-section p {\r
  color: var(--text-2);\r
  font-size: var(--font-size-sub);\r
  line-height: 1.8;\r
  margin: 0;\r
}\r
\r
kbd.code {\r
  font-family: Consolas, monospace;\r
  background: var(--accent-weak);\r
  border-radius: 4px;\r
  padding: 1px 6px;\r
  font-size: 13px;\r
}\r
\r
.privacy-list {\r
  margin: 8px 0 0;\r
  padding-left: 20px;\r
  color: var(--text-2);\r
  line-height: 1.8;\r
}\r
\r
.toggle-field {\r
  display: flex;\r
  align-items: center;\r
  gap: 8px;\r
  margin-top: 14px;\r
  color: var(--text-1);\r
}\r
\r
.toggle-field input {\r
  width: 16px;\r
  height: 16px;\r
}\r
\r
.session-management {\r
  display: grid;\r
  gap: 10px;\r
  margin: 12px 0 0;\r
  padding: 0;\r
  list-style: none;\r
}\r
\r
.session-management li {\r
  display: flex;\r
  align-items: center;\r
  gap: 8px;\r
}\r
\r
.session-management li > span {\r
  flex: 1;\r
}\r
\r
.session-management input {\r
  flex: 1;\r
  min-width: 0;\r
  padding: 7px 9px;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius-sm);\r
  background: var(--bg-chat);\r
}\r
\r
.settings-error {\r
  color: var(--danger);\r
}\r
\r
.settings-route-bar {\r
  display: flex;\r
  justify-content: flex-end;\r
  margin-bottom: 18px;\r
}\r
\r
.payment-route-btn {\r
  margin-top: 12px;\r
}\r
\r
.setting-field {\r
  display: flex;\r
  align-items: center;\r
  justify-content: space-between;\r
  gap: 16px;\r
  color: var(--text-2);\r
}\r
\r
.setting-field select {\r
  min-width: 110px;\r
  padding: 7px 9px;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius-sm);\r
  background: var(--bg-chat);\r
  color: var(--text-1);\r
}\r
\r
.profile-name-form {\r
  display: flex;\r
  align-items: center;\r
  gap: 10px;\r
  margin-bottom: 8px;\r
}\r
\r
.profile-name-form input {\r
  min-width: 0;\r
  width: min(240px, 100%);\r
  padding: 7px 9px;\r
  border: 1px solid var(--border);\r
  border-radius: var(--radius-sm);\r
  background: var(--bg-chat);\r
  color: var(--text-1);\r
  font: inherit;\r
}\r
\r
/* ---- 三栏工作区：导航 / 消息列表 / 会话详情 ---- */\r
\r
.workspace-shell {\r
  display: flex;\r
  flex-direction: column;\r
  height: 100%;\r
  min-width: 0;\r
  overflow: hidden;\r
  color-scheme: light;\r
  background:\r
    radial-gradient(ellipse 42% 48% at 52% 52%, #eff2fd 0%, transparent 72%),\r
    linear-gradient(180deg, #dee8f6 0%, #dfe7f6 52%, #dfe5f4 100%);\r
}\r
\r
.workspace-topbar {\r
  display: flex;\r
  flex: none;\r
  align-items: center;\r
  justify-content: space-between;\r
  height: 32px;\r
  padding: 0 17px;\r
  border: 0;\r
  background: transparent;\r
  color: #52627c;\r
}\r
\r
.product-brand {\r
  display: inline-flex;\r
  flex: none;\r
  align-items: center;\r
  gap: 7px;\r
  color: #425b7d;\r
  font-size: 14px;\r
  font-weight: 600;\r
  white-space: nowrap;\r
}\r
\r
.product-brand-icon {\r
  display: block;\r
  flex: none;\r
  width: 22px;\r
  height: 22px;\r
  object-fit: contain;\r
}\r
\r
.workspace-topbar-account,\r
.workspace-topbar-controls {\r
  display: flex;\r
  align-items: center;\r
  gap: 15px;\r
}\r
\r
.workspace-topbar-account {\r
  justify-content: space-between;\r
  width: calc(var(--home-nav-width) - 10px);\r
  transform: translateY(8px);\r
}\r
\r
.profile-avatar-control {\r
  position: relative;\r
  flex: none;\r
}\r
\r
.profile-avatar-button {\r
  display: grid;\r
  width: 28px;\r
  height: 28px;\r
  padding: 0;\r
  border: 0;\r
  border-radius: 50%;\r
  background: #e1f1ff;\r
  overflow: hidden;\r
}\r
\r
.profile-avatar-button img {\r
  width: 100%;\r
  height: 100%;\r
  object-fit: cover;\r
}\r
\r
.profile-avatar-button:focus-visible {\r
  outline: 2px solid #4e6bae;\r
  outline-offset: 2px;\r
}\r
\r
.profile-avatar-button:disabled { opacity: 0.6; }\r
\r
.profile-avatar-error {\r
  position: absolute;\r
  top: calc(100% + 8px);\r
  left: 0;\r
  z-index: 30;\r
  width: min(260px, calc(100% - 40px));\r
  margin: 0;\r
  padding: 8px 10px;\r
  border: 1px solid #d8dee8;\r
  border-radius: 6px;\r
  background: #fcfcfc;\r
  color: #b42318;\r
  font-size: 12px;\r
  line-height: 1.5;\r
}\r
\r
.new-session-trigger {\r
  display: grid;\r
  flex: none;\r
  place-items: center;\r
  width: 30px;\r
  height: 30px;\r
  padding: 0;\r
  border: 0;\r
  border-radius: 10px;\r
  background: transparent;\r
  color: #404b54;\r
}\r
\r
.new-session-trigger svg {\r
  width: 22px;\r
  height: 22px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-linecap: round;\r
  stroke-width: 2.2;\r
}\r
\r
.new-session-trigger:hover,\r
.new-session-trigger:focus-visible {\r
  background: rgb(213 226 243 / 60%);\r
  outline: 2px solid #9ab5e6;\r
}\r
\r
.new-session-trigger:disabled {\r
  opacity: 0.55;\r
  cursor: default;\r
}\r
\r
.workspace-topbar-controls {\r
  gap: 22px;\r
  font-size: 21px;\r
}\r
\r
.workspace-body {\r
  display: grid;\r
  grid-template-columns: minmax(168px, var(--home-nav-width)) 6px minmax(260px, var(--home-list-width)) 4px minmax(0, 1fr);\r
  flex: 1;\r
  min-height: 0;\r
  padding: 0 10px 10px 0;\r
  overflow: hidden;\r
}\r
\r
.workspace-shell > .reader-state,\r
.workspace-shell > .license-lock-layer {\r
  flex: 1;\r
  min-height: 0;\r
}\r
\r
.workspace-shell > .reader-state {\r
  height: auto;\r
}\r
\r
.nav-rail {\r
  display: flex;\r
  flex-direction: column;\r
  min-width: 0;\r
  padding: 22px 8px 10px;\r
  margin-bottom: -10px;\r
  background: transparent;\r
  color: #273044;\r
}\r
\r
.nav-account {\r
  display: flex;\r
  align-items: center;\r
  justify-content: space-between;\r
  margin: 0 2px 18px;\r
}\r
\r
.account-avatar,\r
.account-add {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  width: 34px;\r
  height: 34px;\r
  border-radius: 10px;\r
  background: #c4d6f1;\r
  color: #3c557f;\r
  font-size: 14px;\r
  font-weight: 700;\r
}\r
\r
.account-add {\r
  width: 24px;\r
  height: 24px;\r
  border: 1px solid #9db1ce;\r
  border-radius: 50%;\r
  background: transparent;\r
  font-size: 18px;\r
  font-weight: 400;\r
}\r
\r
.nav-search {\r
  display: flex;\r
  align-items: center;\r
  gap: 7px;\r
  height: 32px;\r
  width: calc(95% + 11.4px);\r
  padding: 0 5px;\r
  border: 1px solid #cbd6e1;\r
  border-radius: 9px;\r
  background: linear-gradient(100deg, #d6e0e9 0%, #d4ddea 54%, #d4deea 100%);\r
  color: #58667b;\r
}\r
\r
.nav-search-icon {\r
  flex: none;\r
  width: 16px;\r
  height: 16px;\r
  color: #41464e;\r
}\r
\r
.nav-search input {\r
  width: 100%;\r
  min-width: 0;\r
  border: 0;\r
  outline: 0;\r
  background: transparent;\r
  color: #273044;\r
  font-size: 13px;\r
}\r
\r
.nav-search input::placeholder {\r
  color: #78859a;\r
}\r
\r
.nav-functions {\r
  display: grid;\r
  gap: 5px;\r
  margin-top: 18px;\r
}\r
\r
.nav-item {\r
  display: flex;\r
  align-items: center;\r
  gap: 11px;\r
  width: 100%;\r
  min-height: 42px;\r
  padding: 0 12px;\r
  border: 0;\r
  border-radius: 9px;\r
  background: transparent;\r
  color: #344158;\r
  text-align: left;\r
}\r
\r
button.nav-item:hover,\r
button.nav-item:focus-visible {\r
  background: rgba(252, 252, 252, 0.64);\r
  outline: none;\r
}\r
\r
.nav-item-active {\r
  width: calc(95% + 11.4px);\r
  background: #fcfcfc;\r
  color: #263a62;\r
  font-weight: 650;\r
}\r
\r
.nav-item-static {\r
  color: #5b6880;\r
}\r
\r
.nav-icon {\r
  display: inline-flex;\r
  flex: none;\r
  align-items: center;\r
  justify-content: center;\r
  width: 24px;\r
  height: 24px;\r
  color: #52617a;\r
  font-family: 'Segoe UI Symbol', 'Microsoft YaHei UI', sans-serif;\r
  font-size: 19px;\r
}\r
\r
.nav-item-active .nav-icon {\r
  color: #3657a2;\r
}\r
\r
.nav-badge {\r
  min-width: 20px;\r
  height: 20px;\r
  margin-left: auto;\r
  padding: 0 5px;\r
  border-radius: 999px;\r
  background: #e35d5b;\r
  color: #fcfcfc;\r
  font-size: 11px;\r
  line-height: 20px;\r
  text-align: center;\r
}\r
\r
.nav-settings {\r
  margin-top: auto;\r
}\r
\r
.splitter {\r
  position: relative;\r
  z-index: 2;\r
  width: 10px;\r
  min-width: 0;\r
  justify-self: center;\r
  cursor: col-resize;\r
  touch-action: none;\r
  background: transparent;\r
}\r
\r
.splitter::after {\r
  content: '';\r
  position: absolute;\r
  inset: 0 3px;\r
  background: rgba(125, 145, 178, 0.34);\r
  opacity: 0;\r
  transition: opacity 120ms ease;\r
}\r
\r
.splitter:hover::after,\r
.splitter.is-dragging::after,\r
.splitter:focus-visible::after {\r
  opacity: 1;\r
}\r
\r
.message-list-panel {\r
  display: flex;\r
  flex-direction: column;\r
  min-width: 0;\r
  min-height: 0;\r
  overflow: hidden;\r
  border: 1px solid #e8edf4;\r
  background: #fcfcfd;\r
  border-radius: 16px;\r
  box-shadow: 0 8px 24px rgb(35 56 88 / 5%);\r
}\r
\r
.message-list-header {\r
  display: flex;\r
  align-items: flex-start;\r
  justify-content: space-between;\r
  gap: 12px;\r
  min-height: 48px;\r
  padding: 14px 16px 8px;\r
  border-bottom: 0;\r
}\r
\r
.message-list-kicker {\r
  margin: 0 0 3px;\r
  color: #77839a;\r
  font-size: 12px;\r
  font-weight: 700;\r
  letter-spacing: 0;\r
}\r
\r
.message-list-header h2 {\r
  display: flex;\r
  align-items: center;\r
  gap: 9px;\r
  margin: 0;\r
  color: #202938;\r
  font-size: 25px;\r
  font-weight: 500;\r
  line-height: 1.2;\r
}\r
\r
.message-title-icon,\r
.header-glyph {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  color: #4c5d76;\r
  font-family: 'Segoe UI Symbol', 'Microsoft YaHei UI', sans-serif;\r
  font-size: 23px;\r
  font-weight: 400;\r
}\r
\r
.message-list {\r
  flex: 1;\r
  min-height: 0;\r
  overflow-y: auto;\r
  padding: 0 8px 12px;\r
}\r
\r
.message-row {\r
  display: flex;\r
  align-items: center;\r
  gap: 11px;\r
  width: 100%;\r
  min-width: 0;\r
  min-height: 92px;\r
  padding: 13px 14px;\r
  border: 1px solid transparent;\r
  border-radius: 10px;\r
  background: transparent;\r
  text-align: left;\r
}\r
\r
.message-row:hover {\r
  background: #edf3fc;\r
}\r
\r
.message-row.is-selected,\r
.message-row.is-selected:hover {\r
  border-color: transparent;\r
  background: #e3edfc;\r
}\r
\r
.message-avatar-display {\r
  display: grid;\r
  flex: none;\r
  place-items: center;\r
  width: 40px;\r
  height: 40px;\r
  border-radius: 10px;\r
}\r
\r
.message-avatar-image {\r
  width: 40px;\r
  height: 40px;\r
  border-radius: 50%;\r
  object-fit: cover;\r
}\r
\r
.message-row-open:focus-visible {\r
  outline: 2px solid #316bf2;\r
  outline-offset: 2px;\r
}\r
\r
.message-row-open {\r
  display: block;\r
  width: 100%;\r
  min-width: 0;\r
  padding: 0;\r
  border: 0;\r
  background: transparent;\r
  text-align: left;\r
}\r
\r
.message-row-open:hover {\r
  background: transparent;\r
}\r
\r
.message-avatar {\r
  display: inline-flex;\r
  flex: none;\r
  align-items: center;\r
  justify-content: center;\r
  width: 58px;\r
  height: 58px;\r
  border-radius: 18px;\r
  background: #dce6f5;\r
  color: #4162a1;\r
  font-size: 13px;\r
  font-weight: 700;\r
}\r
\r
.message-meta {\r
  display: grid;\r
  flex: 1;\r
  min-width: 0;\r
  gap: 8px;\r
}\r
\r
.message-heading {\r
  display: flex;\r
  align-items: baseline;\r
  justify-content: space-between;\r
  min-width: 0;\r
  gap: 8px;\r
}\r
\r
.message-name,\r
.message-preview {\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
.message-name {\r
  min-width: 0;\r
  color: #242d3d;\r
  font-size: 16px;\r
  font-weight: 400;\r
}\r
\r
.message-time {\r
  flex: none;\r
  color: #8a9099;\r
  font-size: 16px;\r
  font-weight: 400;\r
}\r
\r
.message-preview {\r
  color: #7b8798;\r
  font-size: 16px;\r
  line-height: 1.4;\r
}\r
\r
.message-preview-edit {\r
  display: block;\r
  width: 100%;\r
  padding: 0;\r
  border: 0;\r
  background: transparent;\r
  text-align: left;\r
  cursor: text;\r
}\r
\r
.message-preview-edit:hover,\r
.message-preview-edit:focus-visible {\r
  color: #626e7d;\r
  outline: none;\r
  text-decoration: underline dotted;\r
  text-underline-offset: 2px;\r
}\r
\r
.message-preview-editor {\r
  display: flex;\r
  align-items: center;\r
  width: 100%;\r
  gap: 4px;\r
}\r
\r
.message-preview-editor input {\r
  flex: 1;\r
  min-width: 0;\r
  padding: 2px 5px;\r
  border: 1px solid #b7c5d9;\r
  border-radius: 4px;\r
  background: #fff;\r
  color: #343a44;\r
  font: inherit;\r
}\r
\r
.message-preview-editor button {\r
  flex: none;\r
  padding: 2px 4px;\r
  border: 0;\r
  border-radius: 4px;\r
  background: #edf2fa;\r
  color: #52617a;\r
  font-size: 11px;\r
}\r
\r
.message-preview-editor button:disabled {\r
  opacity: 0.5;\r
  cursor: default;\r
}\r
\r
.message-list-empty {\r
  display: grid;\r
  place-items: center;\r
  align-content: center;\r
  min-height: 220px;\r
  padding: 28px 18px;\r
  color: #7b8798;\r
  text-align: center;\r
}\r
\r
.message-list-empty p {\r
  margin: 0;\r
}\r
\r
.message-list-empty .hint {\r
  margin-top: 8px;\r
  color: #98a2b1;\r
  font-size: 12px;\r
  line-height: 1.7;\r
}\r
\r
.session-detail {\r
  min-width: 0;\r
  min-height: 0;\r
  overflow: hidden;\r
  border: 1px solid #e8edf4;\r
  background: #fcfcfd;\r
  border-radius: 16px;\r
  box-shadow: 0 8px 24px rgb(35 56 88 / 5%);\r
}\r
\r
.session-detail-empty {\r
  display: grid;\r
  height: 100%;\r
  place-content: center;\r
  justify-items: center;\r
  padding: 32px;\r
  color: #7b8798;\r
  text-align: center;\r
}\r
\r
.session-detail-empty h2 {\r
  margin: 16px 0 8px;\r
  color: #3d4b60;\r
  font-size: 22px;\r
}\r
\r
.session-detail-empty p {\r
  margin: 0;\r
  color: #98a2b1;\r
  font-size: 13px;\r
}\r
\r
.session-detail-symbol {\r
  display: grid;\r
  width: 72px;\r
  height: 72px;\r
  place-items: center;\r
  border: 1px solid #c4d3e8;\r
  border-radius: 18px;\r
  background: #edf2fb;\r
  color: #5c74a2;\r
  font-size: 12px;\r
  font-weight: 700;\r
}\r
\r
.session-detail .reader,\r
.session-detail .reader-state,\r
.conversation-empty-detail {\r
  height: 100%;\r
}\r
\r
.session-detail .reader-header {\r
  background: #fcfcfc;\r
}\r
\r
.session-detail .message-stream {\r
  background: radial-gradient(ellipse 118% 105% at 50% 45%, #fff 0%, #fafbfd 100%);\r
}\r
\r
.conversation-empty-detail {\r
  container: composer-frame / size;\r
  display: flex;\r
  flex-direction: column;\r
  min-height: 0;\r
}\r
\r
.conversation-header {\r
  position: relative;\r
  display: flex;\r
  flex: none;\r
  align-items: flex-start;\r
  gap: 8px;\r
  min-height: 60px;\r
  padding: 6px 14px 0;\r
  border-bottom: 1px solid #e9edf3;\r
  background: linear-gradient(180deg, #fff 0%, #fcfdff 100%);\r
}\r
\r
.conversation-header-profile {\r
  display: flex;\r
  flex: 1;\r
  align-items: center;\r
  gap: 9px;\r
  min-width: 0;\r
}\r
\r
.conversation-profile-avatar {\r
  flex: none;\r
  width: 36px;\r
  height: 36px;\r
  border-radius: 50%;\r
  object-fit: cover;\r
}\r
\r
.conversation-profile-avatar-button {\r
  display: grid;\r
  flex: none;\r
  place-items: center;\r
  width: 36px;\r
  height: 36px;\r
  padding: 0;\r
  overflow: hidden;\r
  border: 0;\r
  border-radius: 50%;\r
  background: transparent;\r
}\r
\r
.conversation-profile-avatar-button:focus-visible {\r
  outline: 2px solid #316bf2;\r
  outline-offset: 2px;\r
}\r
\r
.conversation-profile-avatar-button:disabled {\r
  opacity: 0.65;\r
  cursor: wait;\r
}\r
\r
.conversation-header-identity {\r
  flex: 1;\r
  min-width: 0;\r
}\r
\r
.conversation-header-identity:not(.has-subtitle) {\r
  transform: translateY(-7px);\r
}\r
\r
.conversation-header-name {\r
  display: flex;\r
  align-items: center;\r
  gap: 8px;\r
}\r
\r
.conversation-header-name strong {\r
  overflow: hidden;\r
  color: #1f2329;\r
  font-size: 16px;\r
  font-weight: 650;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
.conversation-title-edit {\r
  overflow: hidden;\r
  max-width: 100%;\r
  padding: 0;\r
  border: 0;\r
  background: transparent;\r
  color: #1f2329;\r
  font-size: 16px;\r
  font-weight: 650;\r
  text-align: left;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
.conversation-title-edit:hover,\r
.conversation-title-edit:focus-visible {\r
  color: #2c67d7;\r
  outline: none;\r
  text-decoration: underline;\r
}\r
\r
.conversation-rename {\r
  display: flex;\r
  align-items: center;\r
  min-width: 0;\r
  gap: 4px;\r
}\r
\r
.conversation-rename input {\r
  min-width: 60px;\r
  width: min(220px, 22vw);\r
  padding: 3px 6px;\r
  border: 1px solid #9bb8e2;\r
  border-radius: 5px;\r
  color: #1f2329;\r
  font: inherit;\r
}\r
\r
.conversation-rename button {\r
  flex: none;\r
  padding: 3px 5px;\r
  border: 0;\r
  border-radius: 5px;\r
  background: #eef3fa;\r
  font-size: 11px;\r
}\r
\r
.conversation-header-identity small {\r
  display: block;\r
  overflow: hidden;\r
  color: #9099a7;\r
  font-size: 11px;\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
}\r
\r
.conversation-rename-error {\r
  color: #b42318;\r
}\r
\r
.conversation-header-actions,\r
.conversation-action-icons {\r
  display: flex;\r
  align-items: center;\r
  gap: 15px;\r
  color: #626e7d;\r
}\r
\r
.conversation-header-actions {\r
  flex: none;\r
  margin-top: 8px;\r
  margin-left: auto;\r
}\r
\r
.conversation-action-icons svg {\r
  width: 16px;\r
  height: 16px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
  stroke-width: 1.8;\r
}\r
\r
.conversation-action-icons svg:last-child circle {\r
  fill: currentColor;\r
  stroke: none;\r
}\r
\r
.conversation-header-tabs {\r
  display: flex;\r
  position: absolute;\r
  bottom: 2px;\r
  left: 59px;\r
  align-items: center;\r
  gap: 5px;\r
  color: #384351;\r
  font-size: 13px;\r
  line-height: 19px;\r
}\r
\r
.conversation-header-tabs span {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 4px;\r
  padding: 2px 6px;\r
  white-space: nowrap;\r
}\r
\r
.conversation-header-tabs svg {\r
  flex: none;\r
  width: 12px;\r
  height: 12px;\r
}\r
\r
.conversation-header-tabs .conversation-tab-active {\r
  border-radius: 7px;\r
  background: #d9e3fa;\r
  color: #1456f0;\r
}\r
\r
.conversation-header-tabs .conversation-tab-add {\r
  color: #657080;\r
  font-size: 18px;\r
}\r
\r
.conversation-header .chapter-select {\r
  max-width: 150px;\r
  border-color: #d8dee8;\r
  background: #fff;\r
}\r
\r
.conversation-empty-body {\r
  display: grid;\r
  flex: 1;\r
  place-content: center;\r
  justify-items: center;\r
  min-height: 0;\r
  padding: 32px;\r
  text-align: center;\r
}\r
\r
.conversation-empty-symbol {\r
  display: grid;\r
  width: 72px;\r
  height: 72px;\r
  place-items: center;\r
  border: 1px solid #c8d8ed;\r
  border-radius: 18px;\r
  background: #edf2fb;\r
  color: #5d78aa;\r
  font-size: 12px;\r
  font-weight: 700;\r
}\r
\r
.conversation-empty-body h2 {\r
  margin: 17px 0 8px;\r
  color: #3e4c60;\r
  font-size: 23px;\r
}\r
\r
.conversation-empty-body p {\r
  margin: 0;\r
  color: #99a3b1;\r
  font-size: 14px;\r
}\r
\r
.conversation-composer {\r
  display: flex;\r
  flex: none;\r
  font-family: inherit;\r
  align-items: center;\r
  min-width: 0;\r
  width: 96.2cqw;\r
  max-width: 100%;\r
  height: clamp(32px, 6.04cqh, 88px);\r
  min-height: 0;\r
  margin: 0 auto clamp(12px, 3.45cqh, 44px);\r
  padding: clamp(4px, 0.9cqh, 12px) clamp(12px, 2.5cqw, 30px);\r
  border: 0.1cqh solid #bfc5ce;\r
  border-radius: 1.5cqh;\r
  background: #fff;\r
  pointer-events: auto;\r
  user-select: auto;\r
  align-self: center;\r
}\r
\r
.conversation-composer:focus-within {\r
  border-color: #aab2bd;\r
}\r
\r
.composer-input-row {\r
  display: flex;\r
  align-items: center;\r
  width: 100%;\r
  min-width: 0;\r
  pointer-events: auto;\r
}\r
\r
.composer-entry {\r
  position: relative;\r
  display: flex;\r
  flex: 1;\r
  align-items: center;\r
  min-width: 0;\r
  gap: 0;\r
  overflow: hidden;\r
  cursor: text;\r
  user-select: text;\r
  -webkit-user-select: text;\r
}\r
\r
.composer-voice-hint {\r
  display: inline-flex;\r
  flex: none;\r
  align-items: center;\r
  justify-content: center;\r
  width: clamp(100px, 17.5cqw, 210px);\r
  min-height: clamp(20px, 3.6cqh, 46px);\r
  padding: 0.3cqh 0.4cqw;\r
  border: 1px solid #e1e4e9;\r
  border-radius: 0.52cqh;\r
  color: #9298a0;\r
  font-size: clamp(11px, 1.9cqh, 24px);\r
  line-height: clamp(14px, 2.4cqh, 31px);\r
  box-sizing: border-box;\r
  white-space: nowrap;\r
  cursor: text;\r
}\r
\r
.composer-field {\r
  flex: 1;\r
  min-width: 0;\r
  min-height: clamp(16px, 2.65cqh, 34px);\r
  max-height: 5.2cqh;\r
  padding: 0;\r
  overflow-y: hidden;\r
  border: 0;\r
  outline: 0;\r
  resize: none;\r
  background: transparent;\r
  color: #1f2329;\r
  font: inherit;\r
  font-size: clamp(12px, 2.2cqh, 28px);\r
  line-height: clamp(16px, 2.65cqh, 34px);\r
  cursor: text;\r
  pointer-events: auto;\r
  user-select: text;\r
  -webkit-user-select: text;\r
}\r
\r
.composer-placeholder {\r
  position: absolute;\r
  inset: 0;\r
  display: flex;\r
  align-items: center;\r
  min-width: 0;\r
  padding-left: 1px;\r
  pointer-events: none;\r
}\r
\r
.composer-recipient-placeholder {\r
  display: block;\r
  flex: 1 1 auto;\r
  min-width: 0;\r
  margin: 0 1.3cqw;\r
  overflow: hidden;\r
  color: #8a929c;\r
  font-size: clamp(12px, 2.2cqh, 28px);\r
  line-height: clamp(16px, 2.65cqh, 34px);\r
  text-overflow: ellipsis;\r
  white-space: nowrap;\r
  cursor: text;\r
}\r
\r
.composer-field::placeholder {\r
  color: #8a929c;\r
  opacity: 1;\r
}\r
\r
.composer-field:disabled {\r
  cursor: not-allowed;\r
}\r
\r
.composer-tools {\r
  display: flex;\r
  flex: none;\r
  align-items: center;\r
  justify-content: space-between;\r
  width: 40cqw;\r
  margin-left: auto;\r
  color: #626c78;\r
  line-height: 1;\r
  pointer-events: auto;\r
}\r
\r
.composer-tool-decoration {\r
  display: inline-flex;\r
  flex: none;\r
  align-items: center;\r
  justify-content: center;\r
}\r
\r
.composer-tool-button {\r
  display: inline-grid;\r
  flex: none;\r
  place-items: center;\r
  width: clamp(22px, 3.8cqh, 48px);\r
  height: clamp(22px, 3.8cqh, 48px);\r
  padding: 0;\r
  border: 0;\r
  background: transparent;\r
  color: inherit;\r
}\r
\r
.composer-tool-button:focus-visible {\r
  border-radius: 0.807cqh;\r
  outline: 0.26918cqh solid #316bf2;\r
  outline-offset: 0.26918cqh;\r
}\r
\r
.composer-expand-button {\r
  cursor: pointer;\r
  pointer-events: auto;\r
}\r
\r
.composer-send-button {\r
  width: clamp(22px, 3.8cqh, 48px);\r
  height: clamp(22px, 3.8cqh, 48px);\r
}\r
\r
.composer-send-button:not(:disabled) {\r
  cursor: pointer;\r
}\r
\r
.composer-format {\r
  font-size: clamp(16px, 2.5cqh, 32px);\r
  font-weight: 500;\r
}\r
\r
.composer-mention {\r
  font-size: clamp(17px, 2.7cqh, 34px);\r
}\r
\r
.composer-clip {\r
  display: inline-flex;\r
  align-items: center;\r
}\r
\r
.composer-icon {\r
  flex: none;\r
  width: clamp(18px, 3cqh, 38px);\r
  height: clamp(18px, 3cqh, 38px);\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 1.8;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.composer-send {\r
  width: clamp(22px, 3.2cqh, 41px);\r
  height: clamp(22px, 3.2cqh, 41px);\r
  fill: #c0c5cc;\r
  stroke: none;\r
}\r
\r
.composer-send-button.is-active .composer-send {\r
  fill: #3478f6;\r
}\r
\r
.composer-send-group {\r
  display: flex;\r
  flex: none;\r
  align-items: center;\r
  gap: 0.75cqh;\r
}\r
\r
.composer-caret {\r
  flex: none;\r
  width: clamp(10px, 1.45cqh, 18px);\r
  height: clamp(10px, 1.45cqh, 18px);\r
  fill: none;\r
  stroke: #9ca5b0;\r
  stroke-width: 1.8;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
.composer-divider {\r
  width: 0.12cqh;\r
  height: 3cqh;\r
  background: #d4dae3;\r
}\r
\r
.conversation-composer.is-expanded {\r
  height: auto;\r
  min-height: clamp(56px, 10cqh, 128px);\r
}\r
\r
.conversation-composer.is-expanded .composer-field {\r
  max-height: clamp(40px, 10cqh, 128px);\r
}\r
\r
.conversation-composer.is-expanded .composer-input-row {\r
  align-items: flex-start;\r
}\r
\r
.conversation-composer.is-expanded .composer-voice-hint {\r
  margin-top: 2px;\r
}\r
\r
.reader .msg.local-sent-message {\r
  justify-content: flex-start;\r
}\r
\r
.reader {\r
  display: flex;\r
  flex-direction: column;\r
}\r
\r
.reader .message-stream {\r
  padding-top: 24px;\r
  padding-bottom: 18px;\r
}\r
\r
.msg.left .bubble {\r
  max-width: min(100%, 930px);\r
  padding: 0;\r
  border-radius: 0;\r
  background: transparent;\r
}\r
\r
.msg.right .bubble {\r
  max-width: min(46%, 310px);\r
  border-radius: 20px;\r
  background: #dee5f4;\r
}\r
\r
@container floating-panel (max-width: 900px) {\r
  .workspace-body {\r
    grid-template-columns: minmax(160px, min(var(--home-nav-width), 25vw)) 6px minmax(220px, min(var(--home-list-width), 40vw)) 4px minmax(0, 1fr);\r
  }\r
\r
  .conversation-action-icons svg:not(:last-child),\r
  .compact-conversation-preview {\r
    display: none;\r
  }\r
\r
  .message-list-header {\r
    padding-inline: 12px;\r
  }\r
}\r
\r
@container floating-panel (max-width: 680px) {\r
  .workspace-body {\r
    grid-template-columns: minmax(150px, min(var(--home-nav-width), 28vw)) 6px minmax(190px, min(var(--home-list-width), 40vw)) 4px minmax(0, 1fr);\r
  }\r
\r
  .nav-rail {\r
    padding-inline: 8px;\r
  }\r
\r
  .nav-item {\r
    gap: 7px;\r
    padding-inline: 8px;\r
  }\r
\r
  .message-list-header h2 {\r
    font-size: 18px;\r
  }\r
\r
}\r
\r
/* ---- 参考图的紧凑视觉基线 ---- */\r
\r
:host, .floating-root {\r
  --font-size-body: 14px;\r
  --font-size-sub: 12px;\r
}\r
\r
.floating-root {\r
  font-size: 14px;\r
  line-height: 1.45;\r
}\r
\r
.workspace-topbar {\r
  height: 32px;\r
  padding-inline: 14px;\r
  border-top: 0;\r
  border-bottom: 0;\r
}\r
\r
\r
.workspace-topbar-controls {\r
  position: relative;\r
  gap: 3px;\r
  font-size: 14px;\r
}\r
\r
.workspace-topbar {\r
  user-select: none;\r
}\r
\r
.window-action {\r
  display: grid;\r
  place-items: center;\r
  width: 32px;\r
  height: 28px;\r
  padding: 0;\r
  border: 0;\r
  border-radius: 4px;\r
  background: transparent;\r
  color: #52627c;\r
}\r
\r
.window-action:hover { background: #cdd8ed; }\r
.window-action:focus-visible { outline: 2px solid #4e6bae; }\r
.window-action:disabled { opacity: 0.4; cursor: default; }\r
.window-action[aria-pressed='true'] { background: #cdd8ed; }\r
.window-action-close:hover:not(:disabled) { background: #c63737; color: #fcfcfc; }\r
\r
.window-control-error {\r
  position: absolute;\r
  top: calc(100% + 6px);\r
  right: 0;\r
  z-index: 30;\r
  width: 230px;\r
  margin: 0;\r
  padding: 8px 10px;\r
  border: 1px solid #d8dee8;\r
  border-radius: 6px;\r
  background: #fcfcfc;\r
  color: #b42318;\r
  font-size: 12px;\r
}\r
\r
.nav-rail {\r
  padding: 22px 8px 10px;\r
}\r
\r
.nav-search {\r
  height: 32px;\r
  padding-inline: 5px;\r
  font-size: 12px;\r
}\r
\r
.nav-search input {\r
  font-size: 13px;\r
}\r
\r
.nav-functions {\r
  gap: 3px;\r
  margin-top: 12px;\r
}\r
\r
.nav-item {\r
  min-height: 32px;\r
  gap: 8px;\r
  padding-inline: 9px;\r
  font-size: 13px;\r
}\r
\r
.nav-icon {\r
  width: 18px;\r
  height: 18px;\r
  font-size: 15px;\r
}\r
\r
.nav-badge {\r
  min-width: 18px;\r
  height: 18px;\r
  font-size: 10px;\r
  line-height: 18px;\r
}\r
\r
.nav-settings {\r
  width: 32px;\r
  min-height: 32px;\r
  margin: auto 0 0 5px;\r
  padding: 0;\r
  justify-content: center;\r
  font-size: 0;\r
}\r
\r
.nav-settings .nav-icon {\r
  width: 18px;\r
  height: 18px;\r
  font-size: 14px;\r
}\r
\r
.message-list-header {\r
  min-height: 48px;\r
  padding: 14px 16px 8px;\r
}\r
\r
.message-list-header h2 {\r
  gap: 8px;\r
  font-size: 16px;\r
}\r
\r
.message-title-icon {\r
  flex: none;\r
  width: 18px;\r
  height: 18px;\r
  color: #313a45;\r
}\r
\r
.message-list {\r
  display: flex;\r
  flex-direction: column;\r
  gap: 7px;\r
  padding: 0 8px 12px;\r
}\r
\r
.message-row {\r
  min-height: 60px;\r
  gap: 12px;\r
  padding: 7px 8px;\r
  border-radius: 8px;\r
}\r
\r
.message-avatar {\r
  width: 40px;\r
  height: 40px;\r
  border-radius: 10px;\r
  font-size: 11px;\r
}\r
\r
.message-avatar-image {\r
  width: 40px;\r
  height: 40px;\r
}\r
\r
.message-name {\r
  font-size: 15px;\r
  font-weight: 400;\r
  line-height: 1.35;\r
}\r
\r
.message-time {\r
  font-size: 13px;\r
  line-height: 1.35;\r
}\r
\r
.message-preview {\r
  color: #999;\r
  font-size: 13px;\r
  line-height: 1.35;\r
}\r
\r
.message-list-empty {\r
  min-height: 140px;\r
  padding: 18px 12px;\r
  font-size: 13px;\r
}\r
\r
.message-list-empty .hint {\r
  font-size: 11px;\r
}\r
\r
.conversation-header {\r
  min-height: 60px;\r
  padding: 6px 14px 0;\r
}\r
\r
.header-glyph {\r
  font-size: 16px;\r
}\r
\r
.conversation-empty-body {\r
  gap: 10px;\r
  padding: 18px;\r
}\r
\r
.conversation-empty-body h2 {\r
  margin: 4px 0;\r
  font-size: 14px;\r
}\r
\r
.conversation-empty-body p {\r
  font-size: 12px;\r
}\r
\r
.compact-conversation-preview {\r
  width: min(620px, 100%);\r
  padding: 12px;\r
  border: 1px solid #d7dce6;\r
  border-radius: 8px;\r
  background: #fff;\r
}\r
\r
.compact-data-table {\r
  width: 100%;\r
  border-collapse: collapse;\r
  color: #566173;\r
  font-size: 12px;\r
}\r
\r
.compact-data-table th,\r
.compact-data-table td {\r
  padding: 7px 9px;\r
  border-bottom: 1px solid #e6e8ee;\r
  text-align: left;\r
}\r
\r
.compact-data-table th {\r
  color: #7c8798;\r
  font-weight: 600;\r
}\r
\r
.compact-chat-preview {\r
  display: grid;\r
  gap: 8px;\r
  padding-top: 12px;\r
}\r
\r
.compact-chat-line {\r
  max-width: 72%;\r
  padding: 7px 10px;\r
  border-radius: 10px;\r
  font-size: 12px;\r
  line-height: 1.5;\r
}\r
\r
.compact-chat-left {\r
  justify-self: start;\r
  background: #f1f2f5;\r
}\r
\r
.compact-chat-right {\r
  justify-self: end;\r
  background: #e7edf8;\r
}\r
\r
.reader .message-stream {\r
  padding: 14px min(5%, 36px) 12px;\r
}\r
\r
.reader .msg {\r
  align-items: flex-start;\r
  justify-content: flex-start;\r
  gap: 10px;\r
  margin: 12px 0;\r
}\r
\r
.reader .msg-avatar {\r
  flex: none;\r
  width: 34px;\r
  height: 34px;\r
  border-radius: 50%;\r
  object-fit: cover;\r
  background: #e4f1ff;\r
}\r
\r
.reader .msg.other .msg-avatar {\r
  filter: grayscale(0.6);\r
}\r
\r
.reader .msg .bubble {\r
  min-width: 0;\r
  max-width: min(86.2cqw, calc(100% - 44px));\r
  padding: 9px 15px 9px 12px;\r
  border-radius: 12px;\r
  color: #1f2329;\r
  font-size: var(--font-size-body);\r
  line-height: 1.6;\r
  text-align: left;\r
  text-indent: 0;\r
  white-space: normal;\r
}\r
\r
.reader .msg.self .bubble {\r
  background: #d1e3ff;\r
}\r
\r
.reader .msg.other .bubble {\r
  background: #ebeced;\r
}\r
\r
.msg {\r
  margin: 7px 0;\r
}\r
\r
.bubble {\r
  padding: 7px 10px;\r
  font-size: 14px;\r
  line-height: 1.55;\r
}\r
\r
.msg.left .bubble {\r
  max-width: min(100%, 820px);\r
}\r
\r
.msg.right .bubble {\r
  max-width: min(38%, 240px);\r
  border-radius: 13px;\r
}\r
\r
@container floating-panel (max-width: 900px) {\r
  .app-shell {\r
    grid-template-columns: minmax(200px, 240px) minmax(0, 1fr);\r
  }\r
\r
  .reader-header {\r
    flex-wrap: wrap;\r
  }\r
\r
  .reader-title {\r
    flex: 1 1 calc(100% - 52px);\r
  }\r
\r
  .chapter-select {\r
    max-width: min(100%, 240px);\r
  }\r
\r
  .message-stream {\r
    padding-inline: 20px;\r
  }\r
}\r
\r
@container floating-panel (max-width: 680px) {\r
  .app-shell {\r
    grid-template-columns: minmax(170px, 38vw) minmax(0, 1fr);\r
  }\r
\r
  .sidebar-header {\r
    padding-inline: 10px;\r
  }\r
\r
  .app-name {\r
    min-width: 0;\r
    overflow: hidden;\r
    text-overflow: ellipsis;\r
    white-space: nowrap;\r
  }\r
\r
  .conversation-item {\r
    gap: 8px;\r
    padding: 8px;\r
  }\r
\r
  .avatar {\r
    width: 32px;\r
    height: 32px;\r
  }\r
\r
  .bubble {\r
    max-width: 88%;\r
  }\r
\r
  .settings-page {\r
    padding: 22px 14px 48px;\r
  }\r
\r
  .settings-section {\r
    padding: 16px 14px;\r
  }\r
\r
  .session-management li,\r
  .setting-field {\r
    align-items: stretch;\r
    flex-direction: column;\r
  }\r
\r
  .profile-name-form {\r
    align-items: stretch;\r
    flex-direction: column;\r
  }\r
\r
  .payment-actions {\r
    flex-wrap: wrap;\r
  }\r
}\r
\r
@container floating-panel (max-height: 620px) {\r
  .guide-panel {\r
    padding: 18px;\r
  }\r
\r
  .guide-steps {\r
    gap: 10px;\r
    margin-block: 14px;\r
  }\r
\r
  .license-lock-layer {\r
    align-items: start;\r
    overflow-y: auto;\r
  }\r
}\r
\r
@media (prefers-contrast: more) {\r
  :host, .floating-root {\r
    --border: #6b7280;\r
    --text-3: #5f6670;\r
  }\r
}\r
\r
:host {\r
  all: initial;\r
  container: floating-panel / size;\r
  position: fixed;\r
  inset: 0;\r
  z-index: 2147483647;\r
  pointer-events: none;\r
}\r
\r
.floating-panel {\r
  position: absolute;\r
  container-type: size;\r
  display: flex;\r
  min-width: 720px;\r
  min-height: 520px;\r
  overflow: hidden;\r
  border: 1px solid rgba(133, 153, 188, 0.34);\r
  border-radius: 18px;\r
  background: #f7f9fc;\r
  box-shadow: 0 22px 70px rgba(37, 57, 91, 0.28);\r
  pointer-events: auto;\r
  user-select: none;\r
}\r
\r
.floating-panel.is-maximized {\r
  border-radius: 0;\r
  box-shadow: none;\r
}\r
\r
.floating-root {\r
  width: 100%;\r
  height: 100%;\r
  overflow: hidden;\r
}\r
\r
.floating-drag-handle {\r
  position: absolute;\r
  top: 0;\r
  right: 145px;\r
  left: 16px;\r
  z-index: 50;\r
  height: 32px;\r
  cursor: move;\r
}\r
\r
.floating-resize-handle {\r
  position: absolute;\r
  right: 0;\r
  bottom: 0;\r
  z-index: 51;\r
  width: 18px;\r
  height: 18px;\r
  cursor: nwse-resize;\r
  background: linear-gradient(135deg, transparent 42%, rgba(78, 107, 174, 0.45) 43%, rgba(78, 107, 174, 0.45) 52%, transparent 53%);\r
}\r
\r
.floating-panel-control {\r
  display: grid;\r
  place-items: center;\r
  width: 32px;\r
  height: 32px;\r
  padding: 0;\r
  border: 0;\r
  background: transparent;\r
  color: #52627c;\r
  cursor: pointer;\r
}\r
\r
.floating-panel-control:hover {\r
  background: #cdd8ed;\r
}\r
\r
.floating-panel-control:focus-visible {\r
  outline: 2px solid #4e6bae;\r
}\r
\r
.floating-panel-control svg {\r
  width: 16px;\r
  height: 16px;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 1.45;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
\r
@container composer-frame (max-width: 760px) {\r
  .composer-field,\r
  .composer-recipient-placeholder {\r
    font-size: clamp(12px, 2.2cqw, 18px);\r
    line-height: clamp(16px, 2.65cqw, 24px);\r
  }\r
\r
  .composer-voice-hint {\r
    width: max-content;\r
    max-width: 34cqw;\r
    padding-inline: clamp(6px, 0.8cqw, 10px);\r
    font-size: clamp(12px, 2cqw, 18px);\r
    line-height: clamp(16px, 2.4cqw, 22px);\r
  }\r
}\r
`,Ge=`focus-reading-floating-host`;function Ke(){document.getElementById(Ge)?.remove();let e=document.createElement(`div`);e.id=Ge,e.style.cssText=`position:fixed;inset:0;z-index:2147483647;pointer-events:none;`;let t=e.attachShadow({mode:`open`}),n=document.createElement(`style`);n.textContent=We;let r=document.createElement(`div`);t.append(n,r),document.documentElement.append(e);let i=(0,u.createRoot)(r);i.render((0,l.createElement)(Ue,{onClose:()=>{i.unmount(),e.remove()}}))}var qe=t({main:Ke}),Je={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(()=>{let e;try{e=qe.main(),e instanceof Promise&&(e=e.catch(e=>{throw Je.error(`The unlisted script "floating-unlisted" crashed on startup!`,e),e}))}catch(e){throw Je.error(`The unlisted script "floating-unlisted" crashed on startup!`,e),e}return e})()})();